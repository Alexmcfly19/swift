import SwiftUI
import MapTilerSDK
import CoreLocation

/// Displays a collection of `Voice` locations on a MapTiler map. This
/// view uses the `MapTilerSDK` to render an interactive map and
/// overlays markers for each voice at its latitude/longitude
/// coordinates. When the voices array changes the markers update
/// automatically. The map style can be customised via the
/// `referenceStyle` and `styleVariant` state properties.
struct VoiceMapWithAnnotationsView: View {
    /// The voices to display on the map. Each voice will appear as a
    /// marker at its associated coordinates.
    var voices: [Voice]

    /// The underlying MapTiler map view. Stored as a state property
    /// so that SwiftUI manages its lifecycle.
    @State private var map = MTMapView(options: MTMapOptions(zoom: 2.0))
    /// The reference style controls which base map is rendered (e.g.
    /// streets, satellite). Defaults to streets.
    @State private var referenceStyle: MTMapReferenceStyle = .streets
    /// Optional variant to select a different colour palette for the
    /// chosen style. Defaults to the default variant.
    // Use the pastel variant for a softer palette that better matches
    // the provided design. See MapTiler SDK docs for available
    // variants such as `.defaultVariant`, `.light`, `.dark`, `.pastel` and
    // others.  The pastel style reduces contrast and brightens the
    // map which helps avatar markers stand out.
    // Use the default style variant. Using specific variants (e.g., .pastel)
    // requires the appropriate MapTiler Cloud API key to be set. Without
    // a key the map may fail to load. Setting this to nil ensures the
    // default base style is used.
    @State private var styleVariant: MTMapStyleVariant? = nil

    var body: some View {
        // Render the MapTiler container directly and allow it to fill
        // all available space. Using an explicit frame with
        // maxWidth/maxHeight avoids a situation where the underlying
        // UIKit view collapses to a minimal height when embedded in
        // complex SwiftUI hierarchies. Dropping the GeometryReader
        // eliminates an extra layer of layout computation and
        // simplifies the view tree.
        MTMapViewContainer(map: map) {
            voices.map { voice in
                MTMarker(coordinates: CLLocationCoordinate2D(
                    latitude: voice.latitude,
                    longitude: voice.longitude
                ))
            }
        }
        .referenceStyle(referenceStyle)
        .styleVariant(styleVariant)
        // Expand to fill the parent. Without this the UIKit view may
        // default to an intrinsic size that doesn't match the host
        // container.
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        // Ignore safe areas so the map extends underneath the status
        // and tab bars. This ensures the attribution label sits at
        // the bottom of the screen and the map covers the available
        // viewport.
        .ignoresSafeArea()
        // Fly to a sensible centre when the view first appears. If
        // there are no voices we skip the animation so the map uses
        // its default camera position.
        .onAppear {
            guard !voices.isEmpty else { return }
            let totalLat = voices.map { $0.latitude }.reduce(0, +)
            let totalLon = voices.map { $0.longitude }.reduce(0, +)
            let centre = CLLocationCoordinate2D(
                latitude: totalLat / Double(voices.count),
                longitude: totalLon / Double(voices.count)
            )
            map.flyTo(centre, options: nil, animationOptions: nil)
        }
    }
}