//
//  ReChordApp.swift
//  ReChord
//
//  Created by Macvps on 9/1/25.
//

import SwiftUI
import MapTilerSDK

@main
struct ReChordApp: App {
    /// Initialise the app and configure the MapTiler SDK. The API key
    /// must be set before any map views are created. We call it in an
    /// asynchronous task to avoid blocking the main thread.
    init() {
        if !APIConfig.mapTilerKey.isEmpty {
            Task {
                await MTConfig.shared.setAPIKey(APIConfig.mapTilerKey)
            }
        }
    }
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(AppState.shared)
        }
    }
}
