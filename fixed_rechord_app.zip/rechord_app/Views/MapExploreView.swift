import SwiftUI
import MapKit
import CoreLocation
import AVFoundation

/// A simple data model representing a published voice with optional
/// associated metadata. The fields mirror common keys returned by the
/// ReChord API. If additional keys are present in responses they are
/// safely ignored when decoding into this type.
struct Voice: Identifiable {
    /// Primary identifier for the voice. Some APIs label this field
    /// differently so the parser in ``MapExploreView`` attempts to
    /// locate an integer id under a variety of common keys.
    var id: Int
    /// User‑supplied title or description of the voice. If absent
    /// "Untitled" is used instead.
    var title: String
    /// Geographic latitude where the voice was recorded.
    var latitude: Double
    /// Geographic longitude where the voice was recorded.
    var longitude: Double
    /// Optional URL pointing to an image associated with the voice. This
    /// could be a photo uploaded by the creator or a generated asset.
    var pictureURL: URL?
    /// Optional URL pointing to an audio file containing the voice.
    var voiceURL: URL?
    /// Number of likes the voice has received. If not present the
    /// default is zero.
    var likes: Int?
    /// Number of dislikes the voice has received. If not present the
    /// default is zero. This property allows the home page to display
    /// a dislike count alongside likes and shares.
    var dislikes: Int?
    /// Number of times the voice has been shared. If not present the
    /// default is zero.
    var shares: Int?

    /// Number of times the voice has been played back. Some API
    /// responses refer to this as `playbacks`, `play_count` or
    /// `views`. If unavailable the default is zero. This value is
    /// displayed on the home page alongside likes and dislikes to
    /// provide an indication of the voice's reach.
    var playCount: Int?
    /// Name of the creator of the voice. The API may label this
    /// property as `owner_name`, `client_name`, `full_name` or
    /// `username` depending on the endpoint.
    var ownerName: String?
    /// Number of comments left on the voice. Defaults to zero when
    /// unavailable.
    var commentsCount: Int?

    /// Identifier of the creator of the voice. Some endpoints may
    /// include this as `client_id`, `user_id` or `owner_id`. This is
    /// optional because not all API responses provide it. When
    /// available it can be used to filter voices by the current user.
    var ownerId: Int?
}

/// A helper object that manages location updates for the Explore view. It
/// publishes a region property that can be bound into a SwiftUI
/// ``MapTileOverlayView``. On initialisation it requests when‑in‑use
/// authorisation and begins updating the location. If the user has not
/// granted permission or a location cannot be determined the region
/// remains centred on zero and can be safely overridden by the caller.
final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 0, longitude: 0),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    private let manager = CLLocationManager()
    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        // Request permission to access location. The host application
        // should include the appropriate usage description keys in
        // its Info.plist to present a permission prompt.
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        DispatchQueue.main.async {
            self.region.center = location.coordinate
        }
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            manager.startUpdatingLocation()
        default:
            break
        }
    }
}

/// A ``UIViewRepresentable`` wrapper around ``MKMapView`` that
/// installs an OpenStreetMap tile overlay. Binding the region to the
/// parent SwiftUI view allows two‑way synchronisation between user
/// interactions on the map and programmatic changes when a card is
/// selected. An optional semi‑transparent overlay can be drawn on top
/// by the caller for visual styling.
struct MapTileOverlayView: UIViewRepresentable {
    @Binding var region: MKCoordinateRegion
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.delegate = context.coordinator
        mapView.setRegion(region, animated: false)
        // Configure a tile overlay. Prefer the MapTiler service when a
        // key is provided via ``APIConfig.mapTilerKey``; otherwise
        // fall back to OpenStreetMap tiles. Using the MapTiler tiles
        // allows the appearance of the map to match the rest of the
        // application and avoids rate limiting on the public OSM server.
        let key = APIConfig.mapTilerKey
        let template: String
        if !key.isEmpty {
            // Use the "basic" MapTiler style. You can choose other
            // styles (e.g. "streets", "topo", "satellite") by
            // adjusting the path below. See the MapTiler API docs for
            // available styles.
            template = "https://api.maptiler.com/maps/basic/256/{z}/{x}/{y}.png?key=\(key)"
        } else {
            // Default to OpenStreetMap if no MapTiler key is present.
            template = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        }
        let overlay = MKTileOverlay(urlTemplate: template)
        // Replace the built‑in base map imagery entirely with our tiles.
        overlay.canReplaceMapContent = true
        // For a tile overlay that replaces the map content the level
        // parameter is ignored, but we specify `.aboveLabels` for
        // completeness. This ensures the overlay sits beneath
        // annotation views and callouts.
        mapView.addOverlay(overlay, level: .aboveLabels)
        mapView.isPitchEnabled = false
        mapView.isRotateEnabled = false
        // Hide points of interest to reduce clutter behind the cards
        if #available(iOS 13.0, *) {
            mapView.pointOfInterestFilter = .excludingAll
        }
        return mapView
    }
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Only animate if the target differs significantly from the current
        let current = mapView.region.center
        let target = region.center
        if abs(current.latitude - target.latitude) > 0.0001 || abs(current.longitude - target.longitude) > 0.0001 {
            mapView.setRegion(region, animated: true)
        }
    }
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapTileOverlayView
        init(_ parent: MapTileOverlayView) { self.parent = parent }
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay {
                return MKTileOverlayRenderer(tileOverlay: tile)
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}

/// The main Explore screen showing a horizontally swipeable set of cards
/// overlaid on top of a live map. Each card represents a voice and
/// contains basic metadata along with simple audio playback controls.
struct MapExploreView: View {
    @EnvironmentObject private var app: AppState
    @StateObject private var locationManager = LocationManager()
    @State private var voices: [Voice] = []
    @State private var selectedIndex: Int = 0
    @State private var isLoading: Bool = false
    @State private var error: String?
    var body: some View {
        ZStack(alignment: .bottom) {
            // Render a blurred background derived from the current voice's image.
            // If no image is available, fall back to a bundled placeholder. This
            // replaces the map overlay from earlier designs.
            Group {
                if voices.indices.contains(selectedIndex), let url = voices[selectedIndex].pictureURL {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure(_):
                            Image("placeholder-bg").resizable().scaledToFill()
                        case .empty:
                            Image("placeholder-bg").resizable().scaledToFill()
                        @unknown default:
                            Image("placeholder-bg").resizable().scaledToFill()
                        }
                    }
                } else {
                    Image("placeholder-bg").resizable().scaledToFill()
                }
            }
            .ignoresSafeArea()
            .blur(radius: 20)
            // Semi‑transparent overlay to improve contrast
            Color.black.opacity(0.3).ignoresSafeArea()
            VStack {
                Spacer()
                if isLoading {
                    ProgressView()
                        .padding(.bottom, 140)
                } else if let error = error {
                    Text(error)
                        .foregroundStyle(.white)
                        .padding(.bottom, 140)
                } else if voices.isEmpty {
                    Text("No voices nearby")
                        .foregroundStyle(.white)
                        .padding(.bottom, 140)
                } else {
                    TabView(selection: $selectedIndex) {
                        ForEach(Array(voices.enumerated()), id: \.offset) { index, voice in
                            VoiceCardView(voice: voice)
                                .padding(.horizontal, 16)
                                .padding(.bottom, 32)
                                .tag(index)
                                .onAppear {
                                    // When a card becomes visible update the map
                                    locationManager.region.center = CLLocationCoordinate2D(latitude: voice.latitude, longitude: voice.longitude)
                                }
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .frame(height: 540)
                    .padding(.bottom, 60)
                }
            }
        }
        .onAppear {
            // Fetch voices once when the view first appears
            Task { await fetchVoices() }
        }
    }
    /// Pull a list of voices within a certain radius of the user's location.
    /// The server returns a heterogeneous payload so this method attempts
    /// to accommodate a variety of shapes and key names.
    private func fetchVoices() async {
        isLoading = true
        error = nil
        // Ensure the user is authenticated
        guard let token = app.token else {
            error = "Please sign in to load voices"
            isLoading = false
            return
        }
        // Determine the current location; if unknown fall back to Manhattan, New York
        let lat = locationManager.region.center.latitude
        let lon = locationManager.region.center.longitude
        let latitude = lat == 0 ? 40.7128 : lat
        let longitude = lon == 0 ? -74.0060 : lon
        // Use the logged in user's id if available; otherwise default to 0 (server will ignore)
        let userId = app.currentUserId ?? 0
        do {
            // Build the URL using the new API signature: voices/{lat}/{lon}/{userId}/Show
            let url = APIConfig.baseURL.appendingPathComponent("voices/\(latitude)/\(longitude)/\(userId)/Show")
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.addValue("application/json", forHTTPHeaderField: "Accept")
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
            if http.statusCode == 401 { throw APIError.unauthorized }
            // Parse the response into a collection of dictionaries
            let json = try JSONSerialization.jsonObject(with: data)
            var items: [[String: Any]] = []
            if let arr = json as? [[String: Any]] {
                items = arr
            } else if let dict = json as? [String: Any] {
                // Try common container keys for the voices array
                if let arr = dict["data"] as? [[String: Any]] {
                    items = arr
                } else if let arr = dict["voices"] as? [[String: Any]] {
                    items = arr
                } else {
                    // Some responses may wrap the array in another key
                    for value in dict.values {
                        if let arr = value as? [[String: Any]] {
                            items = arr
                            break
                        }
                    }
                }
            }
            var loaded: [Voice] = []
            loaded.reserveCapacity(items.count)
            // Helper to coerce arbitrary values into a Double
            func toDouble(_ value: Any?) -> Double? {
                if let d = value as? Double { return d }
                if let n = value as? NSNumber { return n.doubleValue }
                if let s = value as? String { return Double(s) }
                return nil
            }
            for item in items {
                // Determine the ID; handle multiple naming conventions
                let id = (item["id"] as? Int)
                    ?? (item["Voice_Id"] as? Int)
                    ?? (item["voice_id"] as? Int)
                    ?? (item["Voice_id"] as? Int)
                    ?? Int((item["id"] as? String) ?? "")
                guard let vid = id else { continue }
                // Title fallbacks
                let title = (item["title"] as? String)
                    ?? (item["Title"] as? String)
                    ?? "Untitled"
                // Extract coordinates. Prefer GeoCode array when available.
                var latVal: Any? = item["Position_X"] ?? item["position_x"] ?? item["latitude"] ?? item["lat"] ?? item["x"]
                var lonVal: Any? = item["Position_Y"] ?? item["position_y"] ?? item["longitude"] ?? item["lon"] ?? item["y"]
                if latVal == nil || lonVal == nil, let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
                    latVal = geo[0]
                    lonVal = geo[1]
                }
                guard let la = toDouble(latVal), let lo = toDouble(lonVal) else { continue }
                // Build URLs for picture and voice
                let picString = (item["Picture_Link"] as? String)
                    ?? (item["picture_link"] as? String)
                    ?? (item["image"] as? String)
                let pictureURL = picString.flatMap { URL(string: $0) }
                let voiceString = (item["Voice_Link"] as? String)
                    ?? (item["voice_link"] as? String)
                    ?? (item["voice"] as? String)
                let voiceURL = voiceString.flatMap { URL(string: $0) }
                // Likes and owner name variations
                let likesValue: Int? = {
                    if let v = item["LikesCount"] as? Int { return v }
                    if let v = item["likes"] as? Int { return v }
                    if let s = item["LikesCount"] as? String { return Int(s) }
                    if let s = item["likes"] as? String { return Int(s) }
                    return nil
                }()
                let name = (item["Owner"] as? String)
                    ?? (item["owner"] as? String)
                    ?? (item["owner_name"] as? String)
                    ?? (item["client_name"] as? String)
                    ?? (item["full_name"] as? String)
                    ?? (item["username"] as? String)
                let comments: Int? = {
                    if let v = item["comments_count"] as? Int { return v }
                    if let s = item["comments_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract dislikes from a variety of possible keys
                let dislikesValue: Int? = {
                    if let v = item["DislikesCount"] as? Int { return v }
                    if let v = item["dislikes"] as? Int { return v }
                    if let v = item["dislike_count"] as? Int { return v }
                    if let v = item["dislikes_count"] as? Int { return v }
                    if let s = item["DislikesCount"] as? String { return Int(s) }
                    if let s = item["dislikes"] as? String { return Int(s) }
                    if let s = item["dislike_count"] as? String { return Int(s) }
                    if let s = item["dislikes_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract shares count from possible keys
                let sharesValue: Int? = {
                    if let v = item["SharesCount"] as? Int { return v }
                    if let v = item["shares"] as? Int { return v }
                    if let v = item["share_count"] as? Int { return v }
                    if let v = item["shares_count"] as? Int { return v }
                    if let s = item["SharesCount"] as? String { return Int(s) }
                    if let s = item["shares"] as? String { return Int(s) }
                    if let s = item["share_count"] as? String { return Int(s) }
                    if let s = item["shares_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract an optional owner identifier from various possible keys
                let ownerIdValue: Int? = {
                    if let v = item["client_id"] as? Int { return v }
                    if let v = item["user_id"] as? Int { return v }
                    if let v = item["owner_id"] as? Int { return v }
                    if let s = item["client_id"] as? String { return Int(s) }
                    if let s = item["user_id"] as? String { return Int(s) }
                    if let s = item["owner_id"] as? String { return Int(s) }
                    return nil
                }()
                // Extract playback count (plays) from multiple possible keys.
                let playsValue: Int? = {
                    if let v = item["PlaybacksCount"] as? Int { return v }
                    if let v = item["playbacks"] as? Int { return v }
                    if let v = item["play_count"] as? Int { return v }
                    if let v = item["plays"] as? Int { return v }
                    if let v = item["views"] as? Int { return v }
                    if let v = item["playbacks_count"] as? Int { return v }
                    if let s = item["PlaybacksCount"] as? String { return Int(s) }
                    if let s = item["playbacks"] as? String { return Int(s) }
                    if let s = item["play_count"] as? String { return Int(s) }
                    if let s = item["plays"] as? String { return Int(s) }
                    if let s = item["views"] as? String { return Int(s) }
                    if let s = item["playbacks_count"] as? String { return Int(s) }
                    return nil
                }()
                loaded.append(Voice(id: vid,
                                   title: title,
                                   latitude: la,
                                   longitude: lo,
                                   pictureURL: pictureURL,
                                   voiceURL: voiceURL,
                                   likes: likesValue,
                                   dislikes: dislikesValue,
                                   shares: sharesValue,
                                   playCount: playsValue,
                                   ownerName: name,
                                   commentsCount: comments,
                                   ownerId: ownerIdValue))
            }
            DispatchQueue.main.async {
                self.voices = loaded
                self.isLoading = false
            }
        } catch {
            DispatchQueue.main.async {
                self.error = error.localizedDescription
                self.isLoading = false
            }
        }
    }
}

/// A card that displays the details of a single voice including its
/// background image, creator metadata, like/comment counters and a
/// minimal audio player. The card is rendered with rounded corners
/// similar to the design provided by the user.
struct VoiceCardView: View {
    var voice: Voice
    // Access the global app state for token and user id
    @EnvironmentObject private var app: AppState
    // Track whether the current user has liked this voice locally. There is no
    // server‑provided flag in the ``Voice`` model, so this state starts off
    // false and toggles whenever the heart button is pressed. Persisting
    // likes between sessions would require additional API support.
    @State private var isLiked: Bool = false
    // Keep an independent like counter so the UI can update instantly when
    // the user taps the button. Initialised from the ``Voice.likes`` field
    // in the custom initializer below.
    @State private var likeCount: Int

    init(voice: Voice) {
        self.voice = voice
        // Initialise the @State likeCount from the voice's likes property
        _likeCount = State(initialValue: voice.likes ?? 0)
    }
    var body: some View {
        ZStack(alignment: .bottom) {
            // Image or placeholder
            Group {
                if let url = voice.pictureURL {
                    // AsyncImage lazily loads the picture; a gray box is
                    // displayed while loading.
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure(_):
                            Color.gray.opacity(0.3)
                        case .empty:
                            Color.gray.opacity(0.3)
                        @unknown default:
                            Color.gray.opacity(0.3)
                        }
                    }
                } else {
                    Color.gray.opacity(0.3)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .clipped()
            // Fade from transparent to black at the bottom for readability
            LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.8)]),
                startPoint: .center,
                endPoint: .bottom
            )
            VStack(alignment: .leading, spacing: 8) {
                Spacer()
                // Owner and title
                if let name = voice.ownerName {
                    HStack(spacing: 8) {
                        Image("placeholder-avatar")
                            .resizable()
                        .frame(width: 36, height: 36)
                        .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text(name)
                                .font(.subheadline)
                                .bold()
                            Text(voice.title)
                                .font(.caption)
                        }
                        .foregroundStyle(.white)
                        Spacer()
                    }
                } else {
                    Text(voice.title)
                        .font(.headline)
                        .foregroundStyle(.white)
                }
                // Likes and comments row
                HStack(spacing: 24) {
                    // Like button. When tapped it toggles the local like state
                    // and fires off an async request to the server. The heart
                    // icon fills and changes colour when liked.
                    Button(action: toggleLike) {
                        HStack(spacing: 4) {
                            Image(systemName: isLiked ? "heart.fill" : "heart")
                                .foregroundColor(isLiked ? .red : .white)
                            Text("\(likeCount)")
                                .foregroundStyle(.white)
                                .font(.footnote)
                        }
                    }
                    // Comments count is read‑only for now
                    HStack(spacing: 4) {
                        Image(systemName: "bubble.left")
                            .foregroundColor(.white)
                        Text("\(voice.commentsCount ?? 0)")
                            .foregroundStyle(.white)
                            .font(.footnote)
                    }
                    Spacer()
                }
                // Audio controls if available
                if voice.voiceURL != nil {
                    VoiceAudioPlayer(url: voice.voiceURL)
                }
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.opacity(0.3))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    /// Toggles the like state. When toggling on, the like count is
    /// incremented and the API's like endpoint is called. When toggling off
    /// the count is decremented and the unlike endpoint is invoked. Errors
    /// are silently ignored; a production app would display feedback.
    private func toggleLike() {
        guard let token = app.token, let clientId = app.currentUserId else {
            // If the user is not authenticated we simply return without
            // updating the server. The count still toggles for immediate UI
            // feedback.
            if isLiked {
                likeCount = max(0, likeCount - 1)
            } else {
                likeCount += 1
            }
            isLiked.toggle()
            return
        }
        if isLiked {
            // Unlike
            likeCount = max(0, likeCount - 1)
            isLiked = false
            Task {
                try? await APIClient.shared.unlikeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        } else {
            likeCount += 1
            isLiked = true
            Task {
                try? await APIClient.shared.likeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        }
    }
}

/// A simple audio player view with play/pause and a progress slider. It
/// loads its AVPlayer lazily when the view appears. Progress updates
/// during playback but is not persisted between pages. Scrubbing the
/// slider seeks within the current track. The slider is styled to
/// contrast against the dark card background.
struct VoiceAudioPlayer: View {
    let url: URL?
    @State private var player: AVPlayer?
    @State private var isPlaying = false
    // A timer that periodically updates the progress binding. Using a
    // publisher here keeps the view lightweight without requiring a
    // dedicated Combine subject. It fires twice per second.
    private let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    var body: some View {
        HStack {
            Button(action: toggle) {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(.white)
            }
            Slider(value: Binding(
                get: {
                    guard let player = player,
                          let currentItem = player.currentItem,
                          currentItem.duration.seconds.isFinite,
                          currentItem.duration.seconds > 0 else { return 0 }
                    return player.currentTime().seconds / currentItem.duration.seconds
                },
                set: { newValue in
                    guard let player = player,
                          let duration = player.currentItem?.duration.seconds,
                          duration.isFinite,
                          duration > 0 else { return }
                    let time = newValue * duration
                    player.seek(to: CMTime(seconds: time, preferredTimescale: 600))
                }
            ), in: 0...1)
            .accentColor(.white)
        }
        .onAppear {
            // Lazily instantiate the player; if the url is nil the view
            // remains inert.
            if let url = url {
                player = AVPlayer(url: url)
            }
        }
        .onReceive(timer) { _ in
            // Force a view update so the slider refreshes while playing
            _ = player?.currentTime()
        }
    }
    private func toggle() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
        } else {
            player.play()
        }
        isPlaying.toggle()
    }
}