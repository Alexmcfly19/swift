//
//  ReChordApp.swift
//  ReChord
//
//  Created by Macvps on 9/1/25.
//

import SwiftUI

@main
struct ReChordApp: App {
    /// Initialise the app and configure the MapTiler SDK. The API key
    /// must be set before any map views are created. We call it in an
    /// asynchronous task to avoid blocking the main thread.
    init() {
        // No MapTiler configuration is required because the app now
        // uses MapKit with an optional tile overlay. This initializer
        // remains in place for future extension.
    }
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(AppState.shared)
        }
    }
}
