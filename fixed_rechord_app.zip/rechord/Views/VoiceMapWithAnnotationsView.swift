import SwiftUI
import MapKit

/// Displays a collection of `Voice` locations on a map using the
/// built‑in MapKit framework. The underlying map is configured with
/// a tile overlay pointing either at MapTiler tiles (when
/// ``APIConfig.mapTilerKey`` is provided) or OpenStreetMap tiles as a
/// fallback. Markers are added for each voice and the camera
/// automatically adjusts to fit the annotations whenever the list of
/// voices changes.
struct VoiceMapWithAnnotationsView: UIViewRepresentable {
    /// The voices to display on the map. Each voice will appear as a
    /// marker at its associated coordinates.
    var voices: [Voice]

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        // Provide our coordinator as the delegate so we can supply
        // renderers for the tile overlay.
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = false
        mapView.isPitchEnabled = false
        mapView.isRotateEnabled = false
        // Hide points of interest to reduce clutter behind the overlay
        if #available(iOS 13.0, *) {
            mapView.pointOfInterestFilter = .excludingAll
        }
        // Configure a tile overlay using MapTiler when an API key is
        // available. Otherwise fall back to OpenStreetMap tiles. This
        // mirrors the logic used elsewhere in the app so the map's
        // appearance remains consistent.
        let key = APIConfig.mapTilerKey
        let template: String
        if !key.isEmpty {
            template = "https://api.maptiler.com/maps/basic/256/{z}/{x}/{y}.png?key=\(key)"
        } else {
            template = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        }
        let overlay = MKTileOverlay(urlTemplate: template)
        overlay.canReplaceMapContent = true
        mapView.addOverlay(overlay, level: .aboveLabels)
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Remove existing annotations except for the user location
        let toRemove = mapView.annotations.filter { !($0 is MKUserLocation) }
        mapView.removeAnnotations(toRemove)
        // Add a marker for each voice
        for voice in voices {
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2D(latitude: voice.latitude, longitude: voice.longitude)
            annotation.title = voice.title
            mapView.addAnnotation(annotation)
        }
        // Adjust the camera to show all voices when there are any
        guard !voices.isEmpty else { return }
        // Compute the bounding region of all voices
        var minLat = voices[0].latitude
        var maxLat = voices[0].latitude
        var minLon = voices[0].longitude
        var maxLon = voices[0].longitude
        for voice in voices {
            minLat = min(minLat, voice.latitude)
            maxLat = max(maxLat, voice.latitude)
            minLon = min(minLon, voice.longitude)
            maxLon = max(maxLon, voice.longitude)
        }
        let span = MKCoordinateSpan(
            latitudeDelta: max(0.02, (maxLat - minLat) * 1.5),
            longitudeDelta: max(0.02, (maxLon - minLon) * 1.5)
        )
        let center = CLLocationCoordinate2D(
            latitude: (minLat + maxLat) / 2,
            longitude: (minLon + maxLon) / 2
        )
        let region = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(region, animated: true)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    /// Coordinator acts as the delegate for the MKMapView. It supplies a
    /// renderer for tile overlays so that the correct tile provider is
    /// used when drawing the map.
    class Coordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay {
                return MKTileOverlayRenderer(tileOverlay: tile)
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}