import SwiftUI
import MapKit
import UIKit

/// A wrapper around `MKMapView` that installs a MapTiler tile overlay and
/// displays a collection of voices as circular annotation views. Each
/// annotation shows either the voice's associated picture or a
/// placeholder avatar. The region binding allows two‑way
/// synchronisation between the SwiftUI state and the underlying
/// `MKMapView`. When the set of voices changes the annotations are
/// updated accordingly.
struct VoiceMapWithAnnotationsView: UIViewRepresentable {
    /// The voices to display on the map. Each voice will appear as a
    /// custom annotation at its latitude/longitude coordinates.
    var voices: [Voice]
    /// A binding to the visible region of the map. Updating this
    /// property animates the map to the new centre and span.
    @Binding var region: MKCoordinateRegion

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.delegate = context.coordinator
        // Configure the initial region
        mapView.setRegion(region, animated: false)
        // Set up MapTiler tile overlay. Replace `YOUR_MAPTILER_KEY` with a
        // valid key. Without a key the overlay will still attempt to
        // render but may not load tiles correctly.
        let key = APIConfig.mapTilerKey
        let template: String
        if !key.isEmpty {
            template = "https://api.maptiler.com/maps/basic/256/{z}/{x}/{y}.png?key=\(key)"
        } else {
            // Fallback to OpenStreetMap tiles if no MapTiler key is set
            template = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        }
        let overlay = MKTileOverlay(urlTemplate: template)
        overlay.canReplaceMapContent = true
        mapView.addOverlay(overlay, level: .aboveLabels)
        mapView.showsCompass = false
        mapView.showsScale = false
        mapView.showsUserLocation = false
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Only adjust the region if it differs significantly from the
        // current map region. This avoids jarring animations when
        // updating annotations.
        let current = mapView.region
        if abs(current.center.latitude - region.center.latitude) > 0.001 ||
            abs(current.center.longitude - region.center.longitude) > 0.001 ||
            abs(current.span.latitudeDelta - region.span.latitudeDelta) > 0.001 ||
            abs(current.span.longitudeDelta - region.span.longitudeDelta) > 0.001 {
            mapView.setRegion(region, animated: true)
        }
        // Remove existing annotations and add new ones for the current voices
        mapView.removeAnnotations(mapView.annotations)
        let annotations = voices.map { VoiceAnnotation(voice: $0) }
        mapView.addAnnotations(annotations)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    /// Coordinator acts as the delegate for the underlying MKMapView,
    /// providing tile renderer and custom annotation views.
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: VoiceMapWithAnnotationsView
        init(_ parent: VoiceMapWithAnnotationsView) {
            self.parent = parent
        }
        // Render the tile overlay using MKTileOverlayRenderer
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay {
                return MKTileOverlayRenderer(tileOverlay: tile)
            }
            return MKOverlayRenderer(overlay: overlay)
        }
        // Provide a custom view for each Voice annotation. The view is
        // circular and uses the voice's picture if available.
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard let voiceAnnotation = annotation as? VoiceAnnotation else {
                return nil
            }
            let identifier = "VoiceAnnotation"
            var view = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            if view == nil {
                view = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                // Size of the avatar on the map. Increase for a more prominent marker.
                let size: CGFloat = 48
                view?.frame = CGRect(x: 0, y: 0, width: size, height: size)
                view?.layer.cornerRadius = size / 2
                view?.layer.masksToBounds = true
            } else {
                view?.annotation = annotation
            }
            // Attempt to load the picture synchronously. For small
            // collections and small images this is acceptable; a more
            // robust implementation would cache images or load them
            // asynchronously.
            if let url = voiceAnnotation.voice.pictureURL,
               let data = try? Data(contentsOf: url),
               let uiImage = UIImage(data: data) {
                view?.image = uiImage
            } else {
                view?.image = UIImage(named: "placeholder-avatar")
            }
            return view
        }
    }
}

/// A simple `MKAnnotation` that carries a `Voice`. It uses the voice's
/// coordinates for placement on the map.
final class VoiceAnnotation: NSObject, MKAnnotation {
    let voice: Voice
    dynamic var coordinate: CLLocationCoordinate2D
    init(voice: Voice) {
        self.voice = voice
        self.coordinate = CLLocationCoordinate2D(latitude: voice.latitude, longitude: voice.longitude)
        super.init()
    }
}