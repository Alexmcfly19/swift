//
//  ReChordApp.swift
//  ReChord
//
//  Created by Macvps on 9/1/25.
//

import SwiftUI

@main
struct ReChordApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(AppState.shared)
        }
    }
}
