import SwiftUI
import MapKit
import PhotosUI
import AVFoundation

/// A view that allows the user to enter metadata for a new voice
/// recording. It displays the user's current location on a map with a
/// marker and presents a card at the bottom where details such as
/// description, cover image, privacy settings and a place name can be
/// entered. A simple audio bar shows the selected voice file and
/// includes a delete button. When the user has finished entering
/// information they can dismiss the view via the built‑in dismiss
/// gesture; in a future iteration a dedicated upload button could be
/// added.
struct AddVoiceMetadataView: View {
    /// The URL of the voice recording selected by the user. This is
    /// passed in from the file importer and used to initialise the
    /// audio player. If nil the audio bar remains inert.
    var voiceURL: URL?
    @EnvironmentObject private var app: AppState
    @Environment(\.dismiss) private var dismiss
    // Location manager to determine the user's current location. A
    // separate instance is used here rather than sharing the one from
    // FeedView or MapExploreView to avoid side effects.
    @StateObject private var locationManager = LocationManager()
    // Metadata fields
    @State private var descriptionText: String = ""
    @State private var placeName: String = ""
    @State private var isPrivate: Bool = false
    @State private var isPrecise: Bool = true
    // Photo selection state. We use PhotosPicker from PhotosUI to
    // select an image and then convert it into a UIImage for preview.
    @State private var selectedPhoto: PhotosPickerItem? = nil
    @State private var coverImage: UIImage? = nil
    @State private var showImagePreview: Bool = false
    // Audio playback state
    @State private var player: AVPlayer? = nil
    @State private var isPlaying: Bool = false
    // Timer to update progress
    private let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack(alignment: .bottom) {
            // Map showing current region with a marker at the centre
            Map(coordinateRegion: $locationManager.region, annotationItems: [MarkerItem(coordinate: locationManager.region.center)]) { item in
                MapAnnotation(coordinate: item.coordinate) {
                    Image(systemName: "mappin.circle.fill")
                        .resizable()
                        .foregroundColor(.red)
                        .frame(width: 32, height: 32)
                        .shadow(radius: 3)
                }
            }
            .ignoresSafeArea()
            // Darken the background slightly to improve contrast with the overlay
            Color.black.opacity(0.2).ignoresSafeArea()
            // Overlay card containing metadata fields
            VStack(spacing: 16) {
                // Description
                TextField("About this record", text: $descriptionText)
                    .padding(.horizontal, 16)
                    .frame(height: 44)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.white.opacity(0.3))
                    )
                // Row for cover button and privacy toggle. When a cover is
                // selected the button text changes to "Change cover".
                HStack(spacing: 12) {
                    // Use PhotosPicker directly as the button so that the
                    // system photo picker is presented automatically when
                    // tapped. The label replicates the design with a
                    // camera icon and descriptive text. When a cover
                    // image has already been selected the text changes to
                    // "change cover" and tapping will allow picking a new
                    // image.
                    PhotosPicker(selection: $selectedPhoto, matching: .images) {
                        HStack {
                            Image(systemName: "camera.fill")
                            Text(coverImage == nil ? "add a cover" : "change cover")
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .foregroundColor(.white)
                        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(hex: 0x0F4D8A)))
                    }
                    .onChange(of: selectedPhoto) { newValue in
                        // Load the selected image asynchronously. If the
                        // user cancels selection the value will be nil and
                        // nothing happens. When an image is chosen we
                        // convert it into a UIImage for preview and show
                        // the full screen preview.
                        Task {
                            if let newValue,
                               let data = try? await newValue.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                coverImage = uiImage
                                showImagePreview = true
                            }
                        }
                    }
                    Spacer()
                    // Privacy / Precise toggle. When toggled on, it
                    // displays "Private"; otherwise the location is
                    // considered public. The tint colour matches the
                    // design's green accent.
                    Toggle(isOn: $isPrivate) {
                        Text(isPrivate ? "Private" : "Precise Location")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Color.green))
                }
                // Row for place name and precision toggle. A separate
                // toggle indicates whether the place name should be
                // precise. This replicates the second screenshot where
                // "Precise" appears alongside the place field.
                HStack(spacing: 12) {
                    TextField("Name this place", text: $placeName)
                        .padding(.horizontal, 16)
                        .frame(height: 44)
                        .background(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(Color.white.opacity(0.3))
                        )
                    Toggle(isOn: $isPrecise) {
                        Text("Precise")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Color.green))
                }
                // Audio bar with play/pause and delete. If no voice URL
                // exists the play button is disabled. Progress is
                // displayed as a series of bars similar to the home page
                // design.
                HStack(spacing: 12) {
                    Button(action: togglePlay) {
                        Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(size: 36))
                            .foregroundColor(Color(hex: 0x0F4D8A))
                    }
                    .disabled(voiceURL == nil)
                    HStack(spacing: 2) {
                        ForEach(0..<30, id: \.self) { index in
                            Capsule()
                                .fill(Double(index) / 30.0 < progress ? Color(hex: 0x0F4D8A) : Color.white.opacity(0.6))
                                .frame(width: 3, height: heightForBar(index))
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: 24)
                    Button(action: {
                        // Clear the audio selection. In a full
                        // implementation this would allow the user to
                        // re-record or pick another file.
                        player = nil
                        isPlaying = false
                    }) {
                        Image(systemName: "trash")
                            .font(.system(size: 24))
                            .foregroundColor(.red)
                    }
                }
                .onAppear {
                    // Set up the player from the provided URL
                    if let url = voiceURL {
                        player = AVPlayer(url: url)
                    }
                }
                .onReceive(timer) { _ in
                    // Trigger a view update so the progress bar
                    // animates while playing
                    _ = player?.currentTime()
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(.ultraThinMaterial)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .stroke(Color.white.opacity(0.4), lineWidth: 1)
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .fullScreenCover(isPresented: $showImagePreview) {
            // Display the selected cover image in a full-screen
            // overlay. The user can tap Done to dismiss the preview.
            if let image = coverImage {
                ZStack(alignment: .topLeading) {
                    Color.black.opacity(0.8).ignoresSafeArea()
                    VStack {
                        HStack {
                            Button(action: { showImagePreview = false }) {
                                Image(systemName: "xmark")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Circle().fill(Color.black.opacity(0.6)))
                            }
                            Spacer()
                            // A placeholder for a rotate action; currently
                            // does nothing but mirrors the design's
                            // second icon.
                            Button(action: {}) {
                                Image(systemName: "arrow.clockwise")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Circle().fill(Color.black.opacity(0.6)))
                            }
                            Spacer()
                            Button(action: { showImagePreview = false }) {
                                Text("Done")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.vertical, 6)
                                    .padding(.horizontal, 20)
                                    .background(
                                        Capsule().fill(Color.green)
                                    )
                            }
                        }
                        .padding(.horizontal)
                        Spacer()
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(24)
                            .padding()
                        Spacer()
                    }
                }
            }
        }
    }
    // The current playback progress, computed from the player's
    // currentTime and duration. Returns 0 when no player exists.
    private var progress: Double {
        guard let player = player,
              let currentItem = player.currentItem,
              currentItem.duration.seconds.isFinite,
              currentItem.duration.seconds > 0 else { return 0 }
        return player.currentTime().seconds / currentItem.duration.seconds
    }
    /// Toggle playback of the audio sample. Creates the player if
    /// necessary and toggles play/pause when the button is tapped.
    private func togglePlay() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
        } else {
            player.play()
        }
        isPlaying.toggle()
    }
    /// Compute a bar height for the faux waveform. Uses a sinusoid to
    /// vary heights between 6 and 24 points.
    private func heightForBar(_ index: Int) -> CGFloat {
        let amplitude: Double = 9
        let base: Double = 15
        let value = sin(Double(index) / 30.0 * .pi) * amplitude + base
        return CGFloat(value)
    }
}

/// A lightweight struct to wrap a coordinate in an identifiable
/// container. This allows the map view to display a marker at the
/// user's current location when used with `annotationItems`.
private struct MarkerItem: Identifiable {
    let id = UUID()
    var coordinate: CLLocationCoordinate2D
}