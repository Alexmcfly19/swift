# ReChord Swift Kit (Views + Networking)

This is **not** a full Xcode project. Drop these files into your SwiftUI app target.
It implements the exact flow you requested: Splash (3s) → Login/Sign up → OTP (activation) → Home (Tab bar) → Profile with avatar & voice upload.

## How to use
1. Create a new **iOS App (SwiftUI)** in Xcode (iOS 15+).
2. Drag the `Sources` folder into your app target (check “Copy items if needed”).
3. Add the placeholder images in `Assets.xcassets` or keep the included PNGs and reference them from your asset catalog.
4. In your `App` entry, set `RootView()` as the content view, e.g.:
   ```swift
   var body: some Scene {
       WindowGroup { RootView() }
   }
   ```
5. Set your Signing/Capabilities as usual.

## Endpoints used
- POST `/clients` (register)
- POST `/clients/login` (login)
- POST `/clients/activation` (request OTP, e.g. during login if user ignored earlier)
- POST `/clients/activate` (activate account by email after OTP verified on client)
- POST `/clients/[id]` (update client profile fields)
- POST `/avatar` (upload avatar)
- POST `/voiceupload` (upload voice file)

Base URL is configurable in `APIClient.swift` (default: `https://be.rechord.life/public/api`).

## Notes
- Multipart/form-data helper is included for file uploads.
- OTP is checked locally as per your spec. For safety, you can move validation server-side later.
- Token is stored in `UserDefaults` under `rechord.jwt` for quick demo wiring.
- Styling is tuned to match your screenshots; swap placeholder images with your real assets to get a pixel-perfect match.
