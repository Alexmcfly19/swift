import SwiftUI

struct SplashView: View {
    @EnvironmentObject var app: AppState
    @State private var showLogo = true
    
    var body: some View {
        ZStack {
            Image("bg-earth-1")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            VStack {
                Image("logo-rechord")
                    .resizable()
                    .frame(width: 140, height: 140)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                Text("ReChord")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(.top, 12)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 3_000_000_000) // 3s
            app.isAuthenticated = false
        }
        .onAppear {
            // After splash, show login
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                // Move to Login
                UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: AnyView(LoginOrRegister()))
            }
        }
    }
}

private struct LoginOrRegister: View {
    var body: some View { LoginView() }
}