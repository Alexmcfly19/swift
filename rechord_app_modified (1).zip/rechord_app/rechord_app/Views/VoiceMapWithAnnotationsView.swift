import SwiftUI
import MapKit
import CoreLocation

/// Displays a collection of `Voice` locations on a native MapKit map. This view
/// uses SwiftUI's `Map` to render an interactive map and overlays a simple
/// circular annotation for each voice at its latitude/longitude coordinates.
/// When the voices array changes the annotations update automatically. The map
/// region is centred on the average of all voice coordinates on first
/// appearance. No API keys are required because MapKit is bundled with iOS.
struct VoiceMapWithAnnotationsView: View {
    /// The voices to display on the map. Each voice will appear as a marker at
    /// its associated coordinates.
    var voices: [Voice]
    /// Optionally highlight a selected voice. When this value is
    /// provided the corresponding annotation grows and gains a coloured
    /// ring to match the provided design. The default value of
    /// `nil` renders all annotations uniformly.
    var selectedVoice: Voice? = nil
    /// Optional closure invoked when a voice annotation is tapped. When
    /// provided, the map will wrap each annotation in a `Button` that
    /// triggers this closure. This enables the parent view to respond to
    /// selection events (e.g. by presenting a modal with the voice’s
    /// details). The default value (`nil`) results in annotations that do
    /// nothing when tapped.
    var onSelect: ((Voice) -> Void)? = nil
    /// The visible region of the map. Binding the region allows the map to
    /// update its centre and span programmatically. It is initialised with a
    /// broad span covering much of North America but will be updated to centre
    /// on the provided voices when the view appears.
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060),
        span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5)
    )
    var body: some View {
        // Render the Map using the region state. The annotationItems
        // parameter binds the voices array to MapKit's annotation system. A
        // MapAnnotation is provided for each voice. It draws either an
        // asynchronous image (when a `pictureURL` exists) clipped to a
        // circle or a default coloured circle when no image is provided. If
        // an `onSelect` closure is supplied the annotation content is
        // wrapped in a button that calls this closure with the tapped
        // voice. Otherwise it is a passive marker.
        Map(coordinateRegion: $region, annotationItems: voices) { voice in
            MapAnnotation(coordinate: CLLocationCoordinate2D(
                latitude: voice.latitude,
                longitude: voice.longitude
            )) {
                // Determine if this annotation should appear selected.
                let isSelected = selectedVoice?.id == voice.id
                // Choose sizes based on selection state. Selected
                // annotations are larger to draw attention.
                let size: CGFloat = isSelected ? 60 : 40
                Group {
                    if let picture = voice.pictureURL {
                        AsyncImage(url: picture) { phase in
                            switch phase {
                            case .success(let image):
                                image.resizable().scaledToFill()
                            default:
                                Color.white
                            }
                        }
                        .frame(width: size, height: size)
                        .clipShape(Circle())
                        // White border to stand out against the map
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                        // Additional coloured ring when selected
                        .overlay(
                            Circle()
                                .stroke(isSelected ? Color(hex: 0x0F4D8A) : Color.clear, lineWidth: isSelected ? 4 : 0)
                        )
                        .shadow(radius: 3)
                    } else {
                        // Fallback when no picture is available. Use a
                        // coloured circle with a coloured ring when
                        // selected.
                        Circle()
                            .fill(isSelected ? Color(hex: 0x0F4D8A) : Color.red)
                            .frame(width: size * 0.6, height: size * 0.6)
                            .overlay(
                                Circle().stroke(Color.white, lineWidth: 2)
                            )
                            .overlay(
                                Circle()
                                    .stroke(isSelected ? Color(hex: 0x0F4D8A) : Color.clear, lineWidth: isSelected ? 4 : 0)
                            )
                            .shadow(radius: 3)
                    }
                }
                .onTapGesture {
                    onSelect?(voice)
                }
            }
        }
        // Expand to fill the parent. Without this the Map may default to an
        // intrinsic size that doesn't match the host container when used in
        // complex SwiftUI hierarchies like a TabView.
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        // Ignore safe areas so the map extends under the status and tab bars.
        // This ensures the map covers the entire viewport.
        .ignoresSafeArea()
        // Centre the map on the average coordinate of the provided voices when
        // the view appears. If no voices are present the map retains its
        // initial region. Updating the region state causes the Map to
        // animate smoothly to the new centre.
        .onAppear {
            guard !voices.isEmpty else { return }
            let totalLat = voices.map { $0.latitude }.reduce(0, +)
            let totalLon = voices.map { $0.longitude }.reduce(0, +)
            let centre = CLLocationCoordinate2D(
                latitude: totalLat / Double(voices.count),
                longitude: totalLon / Double(voices.count)
            )
            region.center = centre
        }
    }
}