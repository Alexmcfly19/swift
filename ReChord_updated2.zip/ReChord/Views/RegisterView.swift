import SwiftUI

struct RegisterView: View {
    @EnvironmentObject var app: AppState
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var fullName: String = ""
    @State private var username: String = ""
    @State private var isLoading = false
    @State private var error: String?
    
    var body: some View {
        ZStack {
            Image("bg-earth-2").resizable().scaledToFill().ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 18) {
                    Spacer().frame(height: 40)
                    Image("logo-rechord").resizable().frame(width: 110, height: 110).clipShape(RoundedRectangle(cornerRadius: 28))
                    Text("ReChord").font(.system(size: 34, weight: .bold)).foregroundStyle(.white)
                    Text("welcome").font(.title3).foregroundStyle(.white.opacity(0.9))
                    
                    VStack(spacing: 12) {
                        ReField(text: $email, placeholder: "Please Enter Your Email").keyboardType(.emailAddress)
                        SecureReField(text: $password, placeholder: "Enter your Password")
                        ReField(text: $fullName, placeholder: "Full Name")
                        ReField(text: $username, placeholder: "Choose a Username for Yourself")
                    }.padding(.horizontal, 24)
                    
                    Button { Task { await register() } } label: { PrimaryButtonLabel("Continue") }
                    .disabled(isLoading)
                    .padding(.horizontal, 24)
                    
                    Spacer().frame(height: 24)
                }
            }
            if let e = error { ToastView(text: e) }
        }
    }
    
    private func register() async {
        isLoading = true; defer { isLoading = false }
        do {
            let otp = try await APIClient.shared.register(email: email, password: password, fullName: fullName, username: username)
            app.currentEmail = email
            app.pendingOTP = otp
            
            UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: AnyView(OTPView(mode: .registration).environmentObject(app)))
        } catch {
            self.error = error.localizedDescription
        }
    }
}
