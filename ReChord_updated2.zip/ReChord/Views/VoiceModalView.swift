import SwiftUI
import AVFoundation

/// A detailed modal view presented when a voice annotation is tapped on the
/// map. This view mirrors the larger card shown in the provided design:
/// it displays the voice’s image, title and owner information, a close
/// button, vertical like/comment/play counters and an audio bar for
/// playback. The modal takes up most of the screen width but leaves
/// comfortable margins on either side, ensuring it aligns visually with
/// the bottom navigation bar. Audio playback is handled by the
/// ``PostAudioBar`` component used elsewhere in the app.
struct VoiceModalView: View {
    var voice: Voice
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var app: AppState
    @State private var isLiked: Bool = false
    @State private var likeCount: Int
    @State private var commentCount: Int
    @State private var playCount: Int

    init(voice: Voice) {
        self.voice = voice
        _likeCount = State(initialValue: voice.likes ?? 0)
        _commentCount = State(initialValue: voice.commentsCount ?? 0)
        _playCount = State(initialValue: voice.playCount ?? 0)
    }

    var body: some View {
        ZStack(alignment: .topTrailing) {
            // Card background with rounded corners. Apply a subtle
            // translucency to blend with the map behind when this
            // modal is presented over the map.
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(.systemBackground).opacity(0.9))
                .shadow(radius: 10)
            VStack(spacing: 0) {
                // Top section: image with overlayed title and owner
                ZStack(alignment: .topLeading) {
                    Group {
                        if let url = voice.pictureURL {
                            AsyncImage(url: url) { phase in
                                switch phase {
                                case .success(let image):
                                    image.resizable().scaledToFill()
                                default:
                                    Color.gray.opacity(0.3)
                                }
                            }
                        } else {
                            Color.gray.opacity(0.3)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: 350)
                    .clipped()
                    // Fade gradient at the bottom of the image for legibility
                    LinearGradient(
                        gradient: Gradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.8)]),
                        startPoint: .center,
                        endPoint: .bottom
                    )
                    HStack(spacing: 8) {
                        // Avatar placeholder
                        if let url = voice.pictureURL {
                            AsyncImage(url: url) { phase in
                                switch phase {
                                case .success(let image):
                                    image.resizable().scaledToFill()
                                default:
                                    Color.gray
                                }
                            }
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                        } else {
                            Circle().fill(Color.gray).frame(width: 40, height: 40)
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text(voice.title)
                                .font(.headline)
                                .bold()
                            if let name = voice.ownerName {
                                Text(name)
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        .foregroundStyle(.white)
                        Spacer()
                    }
                    .padding(.top, 16)
                    .padding(.leading, 16)
                    // Vertical like/comment/play icons anchored to the right
                    VStack(spacing: 18) {
                        Button(action: toggleLike) {
                            VStack(spacing: 4) {
                                Image(systemName: isLiked ? "heart.fill" : "heart")
                                    .foregroundColor(isLiked ? .red : .white)
                                    .font(.title2)
                                Text(formattedCount(likeCount))
                                    .foregroundColor(.white)
                                    .font(.footnote)
                            }
                        }
                        Button(action: toggleComment) {
                            VStack(spacing: 4) {
                                Image(systemName: "bubble.right")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                Text(formattedCount(commentCount))
                                    .foregroundColor(.white)
                                    .font(.footnote)
                            }
                        }
                        Button(action: {}) {
                            VStack(spacing: 4) {
                                Image(systemName: "play.circle")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                Text(formattedCount(playCount))
                                    .foregroundColor(.white)
                                    .font(.footnote)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                    .padding(.trailing, 16)
                    .padding(.bottom, 16)
                }
                // Bottom section: location and audio bar
                VStack(alignment: .leading, spacing: 8) {
                    if voice.latitude != 0 || voice.longitude != 0 {
                        HStack(spacing: 4) {
                            Image(systemName: "mappin.and.ellipse")
                                .foregroundColor(.secondary)
                            Text(String(format: "%.4f, %.4f", voice.latitude, voice.longitude))
                                .foregroundColor(.secondary)
                                .font(.caption)
                            Spacer()
                        }
                    }
                    if voice.voiceURL != nil {
                        PostAudioBar(url: voice.voiceURL)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            }
            // Close button at the top right
            Button(action: { dismiss() }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white)
                    .shadow(radius: 4)
            }
            .padding(12)
        }
        // Constrain the modal width to leave margins on either side. This
        // ensures the card width aligns visually with the bottom
        // navigation bar and prevents it from stretching edge to edge on
        // large devices.
        .frame(maxWidth: 360)
        .padding(.horizontal, 24)
        .padding(.vertical, 40)
        .background(
            // Dim the area behind the card slightly when the modal is
            // presented. This is achieved by placing a semi‑transparent
            // black overlay behind the card but within the sheet. The
            // `ignoresSafeArea` ensures it covers the entire sheet.
            Color.black.opacity(0.3)
                .ignoresSafeArea()
        )
    }

    /// Convert an integer count into a compact string representation.
    private func formattedCount(_ count: Int) -> String {
        guard count >= 0 else { return "0" }
        if count >= 1_000_000 {
            let m = Double(count) / 1_000_000
            let rounded = (m * 10).rounded() / 10
            if rounded.truncatingRemainder(dividingBy: 1) == 0 {
                return String(format: "%.0fM", rounded)
            }
            return String(format: "%.1fM", rounded)
        } else if count >= 1_000 {
            let k = Double(count) / 1_000
            let rounded = (k * 10).rounded() / 10
            if rounded.truncatingRemainder(dividingBy: 1) == 0 {
                return String(format: "%.0fK", rounded)
            }
            return String(format: "%.1fK", rounded)
        } else {
            return String(count)
        }
    }

    /// Handle tapping the like button. The behaviour mirrors that of
    /// ``PostCardView``: counts update immediately and API requests
    /// dispatch asynchronously if a token is available.
    private func toggleLike() {
        guard let token = app.token, let clientId = app.currentUserId else {
            if isLiked {
                likeCount = max(0, likeCount - 1)
            } else {
                likeCount += 1
            }
            isLiked.toggle()
            return
        }
        if isLiked {
            likeCount = max(0, likeCount - 1)
            isLiked = false
            Task {
                try? await APIClient.shared.unlikeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        } else {
            likeCount += 1
            isLiked = true
            Task {
                try? await APIClient.shared.likeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        }
    }

    /// Toggle the comment count locally. As with the home page this is a
    /// placeholder to demonstrate how tapping the comment button can
    /// update the UI. Future work would present a comment composer or
    /// fetch existing comments.
    private func toggleComment() {
        if commentCount > 0 {
            commentCount -= 1
        } else {
            commentCount += 1
        }
    }
}