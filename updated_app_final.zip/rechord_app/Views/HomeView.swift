import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

struct HomeView: View {
    @EnvironmentObject var app: AppState
    @State private var tab = 2 // center record by default
    
    var body: some View {
        TabView(selection: $tab) {
            // New post feed modelled after the provided screenshot. This
            // appears as the left‑most tab and allows users to browse
            // through voices in a full‑screen feed. See
            // PostFeedView.swift for details.
            PostFeedView()
                .tabItem { Label("Home", systemImage: "house.fill") }
                .tag(0)
            // Map exploration tab showing voices on a map.  This uses
            // the FeedView rather than the old card‑based explore view.
            // FeedView presents a full‑screen map backed by a MapTiler
            // tile overlay and a segmented control to switch between
            // all voices and the current user's voices.  See
            // FeedView.swift for implementation details.  The change
            // from MapExploreView to FeedView aligns the explore page
            // with the provided design which shows avatars on a map
            // with a filter control.
            FeedView()
                .tabItem { Label("Explore", systemImage: "globe") }
                .tag(1)
            // Central record button for uploading a new voice
            RecorderView()
                .tabItem { Label("Record", systemImage: "mic.circle.fill") }
                .tag(2)
            // Notifications tab shows likes and comments along with the
            // user's own ReChords
            NotificationView()
                .tabItem { Label("@", systemImage: "at") }
                .tag(3)
            // Profile tab
            ProfileView()
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
                .tag(4)
        }
    }
}

struct ExploreView: View { var body: some View { Color.clear.overlay(Text("Explore")) } }
// The FeedView implementation has been moved to its own file (FeedView.swift).
struct MentionsView: View { var body: some View { Color.clear.overlay(Text("Mentions")) } }

struct RecorderView: View {
    @EnvironmentObject var app: AppState
    @State private var showPicker = false
    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Button {
                showPicker = true
            } label: {
                Image(systemName: "record.circle.fill").font(.system(size: 96))
            }
            Text("Tap to pick a voice file to upload").foregroundStyle(.secondary)
            Spacer()
        }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [.audio]) { result in
            switch result {
            case .success(let url):
                if let data = try? Data(contentsOf: url), let token = app.token {
                    Task {
                        try? await APIClient.shared.uploadVoice(voiceData: data, token: token)
                    }
                }
            case .failure:
                break
            }
        }
    }
}
