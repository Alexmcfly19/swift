//
//  ReChordApp.swift
//  ReChord
//
//  Created by Macvps on 9/1/25.
//

import SwiftUI
import MapTilerSDK

@main
struct ReChordApp: App {
    /// Initialise the app and configure the MapTiler SDK. The API key
    /// must be set once before any `MTMapView` instances are
    /// created. By using `Task` here we ensure the call is made on
    /// launch without blocking the main thread.
    init() {
        // Only attempt to set the API key if one has been provided.
        if !APIConfig.mapTilerKey.isEmpty {
            Task {
                await MTConfig.shared.setAPIKey(APIConfig.mapTilerKey)
            }
        }
    }
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(AppState.shared)
        }
    }
}
