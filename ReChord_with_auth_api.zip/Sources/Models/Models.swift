
import Foundation

struct User: Codable, Identifiable, Equatable {
    var id: String
    var fullName: String
    var username: String
    var email: String
    var phone: String? = nil
    var website: String? = nil
    var languages: [String] = ["English"]
    var isPrivate: Bool = false
    var locationPermission: Bool = false
}

struct RegisterResponse: Codable {
    let success: Bool
    let message: String
    let email: String
    let otp: String          // NEW: backend returns OTP as requested
    let user_id: String      // NEW: useful for correlating activation
}

struct ActivateResponse: Codable {
    let activated: Bool
    let message: String
}

struct LoginResponse: Codable {
    let token: String
    let user: User
}
