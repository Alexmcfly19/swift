
import SwiftUI

struct OTPView: View {
    @EnvironmentObject var auth: AuthViewModel
    let email: String

    var body: some View {
        VStack(spacing: 24) {
            Text("Enter the 6‑digit code")
                .font(.title2).bold()
                .foregroundColor(.white)
            Text("We sent a code to \(email).")
                .foregroundColor(.white.opacity(0.8))

            TextField("••••••", text: $auth.otpCode)
                .keyboardType(.numberPad)
                .textContentType(.oneTimeCode)
                .multilineTextAlignment(.center)
                .font(.title)
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(12)

            if let err = auth.error {
                Text(err).foregroundColor(.red.opacity(0.9))
            }

            Button {
                Task { await auth.submitOTP() }
            } label: {
                Text(auth.isLoading ? "Verifying..." : "Verify & Activate")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .disabled(auth.otpCode.count != 6 || auth.isLoading)

            Spacer()
        }
        .padding(.horizontal, 24)
        .background(Theme.background.ignoresSafeArea())
    }
}
