
import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 24) {
                Image(systemName: "play.rectangle.on.rectangle.circle")
                    .resizable().scaledToFit().frame(width: 96, height: 96)
                Text("ReChord").font(.system(size: 48, weight: .bold)).foregroundColor(.white)
            }
        }
    }
}
