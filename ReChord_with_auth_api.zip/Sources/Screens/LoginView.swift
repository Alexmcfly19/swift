
import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthViewModel
    @State private var identifier: String = ""
    @State private var password: String = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer().frame(height: 40)
                LogoBlock()
                VStack(spacing: 16) {
                    TextField("Enter your email or phone number", text: $identifier)
                        .textContentType(.username)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .textFieldIcon("envelope")
                        .foregroundColor(.white)

                    SecureField("Please enter your Password", text: $password)
                        .textFieldIcon("lock")
                        .foregroundColor(.white)

                    if let error = auth.error {
                        Text(error).foregroundColor(.red).font(.subheadline)
                    }

                    PrimaryButton(title: auth.isLoading ? "Signing in..." : "Continue") {
                        Task { await auth.login(identifier: identifier, password: password) }
                    }
                    .disabled(auth.isLoading || identifier.isEmpty || password.isEmpty)

                    Button("Forget your password?") { }
                        .foregroundColor(.white.opacity(0.8))

                    HStack(spacing: 6) {
                        Text("Don't have an account,").foregroundColor(.white.opacity(0.8))
                        Button("sign up") { auth.goToRegister() }
                    }
                }
                .padding(.horizontal, 24)
                Spacer()
            }
        }
        .background(Theme.background.ignoresSafeArea())
    }
}

private struct LogoBlock: View {
    var body: some View {
        VStack(spacing: 10) {
            Text("ReChord")
                .font(.system(size: 44, weight: .bold))
                .foregroundColor(.white)
        }.padding(.bottom, 16)
    }
}
