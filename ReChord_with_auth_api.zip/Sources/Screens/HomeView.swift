
import SwiftUI

struct HomeView: View {
    @EnvironmentObject var auth: AuthViewModel

    var body: some View {
        TabView {
            FeedView()
                .tabItem { Image(systemName: "waveform"); Text("Feed") }
            ExploreView()
                .tabItem { Image(systemName: "globe"); Text("Explore") }
            MessagesView()
                .tabItem { Image(systemName: "at"); Text("Mentions") }
            ProfileView()
                .tabItem { Image(systemName: "person.crop.circle"); Text("Profile") }
        }
        .accentColor(Theme.brand)
    }
}

private struct FeedView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                Text("Home Feed").foregroundColor(.white)
            }.navigationTitle("ReChord")
        }
    }
}

private struct ExploreView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            Text("Explore").foregroundColor(.white)
        }
    }
}

private struct MessagesView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            Text("Mentions / Messages").foregroundColor(.white)
        }
    }
}
