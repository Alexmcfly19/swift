
import SwiftUI

enum Theme {
    static let brand = Color.blue
    static let brandDark = Color.indigo

    static let background = LinearGradient(
        gradient: Gradient(colors: [Color.black, Color(red: 0.04, green: 0.06, blue: 0.12)]),
        startPoint: .top,
        endPoint: .bottom
    )

    static let card = Color.white.opacity(0.12)
    static let fieldBG = Color.white.opacity(0.08)
}
