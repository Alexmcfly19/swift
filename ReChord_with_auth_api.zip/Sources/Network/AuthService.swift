
import Foundation

protocol AuthServicing {
    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse
    func activate(email: String) async throws -> ActivateResponse
    func login(identifier: String, password: String) async throws -> LoginResponse
}

final class AuthService: AuthServicing {
    private let client = APIClient()

    // MARK: - Public API
    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse {
        struct Body: Encodable {
            let username: String
            let full_name: String
            let email: String
            let password: String
        }
        let body = Body(username: username, full_name: fullName, email: email, password: password)
        let res = try await client.postJSON("/api/register", body: body, type: RegisterResponse.self)
        return res
    }

    func activate(email: String) async throws -> ActivateResponse {
        struct Body: Encodable { let email: String }
        return try await client.postJSON("/api/activate", body: Body(email: email), type: ActivateResponse.self)
    }

    // Demo login (no backend in this sample)
    func login(identifier: String, password: String) async throws -> LoginResponse {
        // Simple local demo: accept demo/demo or any email registered via /api/register with any password
        if identifier.lowercased() == "demo", password == "demo" {
            let user = User(id: UUID().uuidString, fullName: "Demo User", username: "demo", email: "demo@rechord.app")
            return LoginResponse(token: UUID().uuidString, user: user)
        }
        // Fallback
        throw APIError(message: "Invalid credentials")
    }
}
