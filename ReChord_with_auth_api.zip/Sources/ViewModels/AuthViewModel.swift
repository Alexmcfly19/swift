
import Foundation
import SwiftUI

@MainActor
final class AuthViewModel: ObservableObject {
    enum ScreenState {
        case splash
        case login
        case register
        case otp(email: String)
        case home
    }
    @Published var state: ScreenState = .login
    @Published var isLoading = false
    @Published var error: String? = nil

    @Published var email: String = ""
    @Published var password: String = ""
    @Published var fullName: String = ""
    @Published var username: String = ""

    @Published var otpCode: String = ""

    // NEW: expected OTP returned from /api/register
    private var expectedOTP: String? = nil
    private var registeredEmail: String? = nil

    private let service: AuthServicing = AuthService()

    @Published var token: String? = nil
    @Published var currentUser: User? = nil

    func goToRegister() { state = .register }
    func goToLogin() { state = .login }

    func register() async {
        isLoading = true
        error = nil
        do {
            let res = try await service.register(email: email, password: password, fullName: fullName, username: username)
            // Store OTP locally as requested; now navigate to OTP screen
            expectedOTP = res.otp
            registeredEmail = res.email
            state = .otp(email: res.email)
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func submitOTP() async {
        guard let expected = expectedOTP, let mail = registeredEmail else {
            error = "No pending registration"; return
        }
        guard otpCode == expected else {
            error = "Invalid code"; return
        }
        isLoading = true
        error = nil
        do {
            let _ = try await service.activate(email: mail)
            // After activation, send user to login
            self.state = .login
            self.otpCode = ""
            self.expectedOTP = nil
            self.registeredEmail = nil
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func login() async {
        isLoading = true
        error = nil
        do {
            let res = try await service.login(identifier: email, password: password)
            token = res.token
            currentUser = res.user
            state = .home
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func logout() {
        token = nil
        currentUser = nil
        state = .login
    }
}
