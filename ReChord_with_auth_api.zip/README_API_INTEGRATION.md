
# OTP Registration Flow Changes

This update implements the requested flow:
1. **Register** endpoint returns an **OTP** along with email and user id.
2. App compares the returned OTP **locally** with user input.
3. On match, the app calls **Activation** endpoint to activate the account.

## Client updates (SwiftUI)
- `Sources/Models/Models.swift`: `RegisterResponse` now includes `otp` and `user_id`. New `ActivateResponse`.
- `Sources/Network/APIClient.swift`: default base URL set to `http://localhost:8000`.
- `Sources/Network/AuthService.swift`: new `activate(email:)` and simplified `login`.
- `Sources/ViewModels/AuthViewModel.swift`: stores `expectedOTP`, compares with `otpCode`, and calls `activate`.
- `Sources/Screens/OTPView.swift`: button triggers `submitOTP()` which validates then activates.

## Server (FastAPI)
Located in `AuthAPI/`. Run locally:
```
cd AuthAPI
pip install fastapi uvicorn pydantic[email]
uvicorn main:app --reload --port 8000
```
