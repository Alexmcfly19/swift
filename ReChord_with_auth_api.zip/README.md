
# ReChord (SwiftUI)

A lightweight SwiftUI sample implementing the flow you described:

- **Splash** (3 seconds) → **Login**
- **Registration** → shows **OTP** screen, verifies, then returns to Login
- **Login** (mock or real API) → **Home** (Tab bar)
- **Profile** tab matches the provided design

> This project is 100% SwiftUI using no external dependencies.

## How to open

1. Open Xcode (15+ recommended).
2. Create a new **iOS App** named `ReChord` with SwiftUI & Swift.
3. Quit Xcode.
4. Replace the auto‑generated files in the new project with the contents of this folder (keep the `.xcodeproj` that Xcode created).
5. Reopen the project and build/run on iOS 17+ simulator.

Alternatively, you can drag the `Sources` files into an existing SwiftUI app target.

## Network Notes

- `APIClient` is written for real HTTP endpoints (set your `baseURL`), but by default the `AuthService` uses a **MockBackend** that simulates registration, OTP delivery/verification, and login.
- To switch to real API calls, set `useMock = false` in `AuthService` and implement the three endpoints (`/auth/register`, `/auth/verify-otp`, `/auth/login`).

## Assets

- The UI uses SF Symbols and SwiftUI gradients. You can drop in your own background image (`earth.jpg`) inside Assets if you want the same look as the mockups.

## Structure

```
ReChord/
  README.md
  Sources/
    ReChordApp.swift
    AppRouter.swift
    Theme.swift
    Utils/Validators.swift
    Network/APIClient.swift
    Network/AuthService.swift
    Models/Models.swift
    ViewModels/AuthViewModel.swift
    Screens/
      RootView.swift
      SplashView.swift
      LoginView.swift
      RegistrationView.swift
      OTPView.swift
      HomeView.swift
      ProfileView.swift
    Components/
      PrimaryButton.swift
      TextFieldIcon.swift
      OTPCells.swift
```

Enjoy! ✨
