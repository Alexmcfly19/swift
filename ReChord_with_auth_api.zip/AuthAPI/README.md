
# ReChord Auth API (FastAPI)

Local dev:

```bash
pip install fastapi uvicorn pydantic[email]
uvicorn main:app --reload --port 8000
```

Endpoints:
- `POST /api/register` body: `{ "username": "...", "full_name": "...", "email": "...", "password": "..." }`
  - returns: `{ success, message, email, otp, user_id }`
- `POST /api/activate` body: `{ "email": "..." }`
  - returns: `{ activated, message }`
