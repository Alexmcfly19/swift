
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
from typing import Dict
import secrets, string

app = FastAPI(title="ReChord Auth API", version="1.0.0")

# In-memory "database"
USERS: Dict[str, dict] = {}
ACTIVE: Dict[str, bool] = {}

def gen_otp(n: int = 6) -> str:
    return ''.join(secrets.choice(string.digits) for _ in range(n))

class RegisterIn(BaseModel):
    username: str
    full_name: str
    email: EmailStr
    password: str

class RegisterOut(BaseModel):
    success: bool
    message: str
    email: EmailStr
    otp: str
    user_id: str

class ActivateIn(BaseModel):
    email: EmailStr

class ActivateOut(BaseModel):
    activated: bool
    message: str

@app.post("/api/register", response_model=RegisterOut)
def register(payload: RegisterIn):
    if payload.email in USERS:
        raise HTTPException(status_code=409, detail="Email already registered")
    user_id = secrets.token_hex(8)
    otp = gen_otp()
    USERS[payload.email] = {
        "id": user_id,
        "username": payload.username,
        "full_name": payload.full_name,
        "email": payload.email,
        "password": payload.password,
        "otp": otp,
        "activated": False,
    }
    ACTIVE[payload.email] = False
    # In production you'd send the OTP via email/SMS. Here we return it as requested.
    return RegisterOut(success=True, message="Registered. Verify OTP then activate.", email=payload.email, otp=otp, user_id=user_id)

@app.post("/api/activate", response_model=ActivateOut)
def activate(payload: ActivateIn):
    user = USERS.get(payload.email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user["activated"] = True
    ACTIVE[payload.email] = True
    return ActivateOut(activated=True, message="Account activated")
