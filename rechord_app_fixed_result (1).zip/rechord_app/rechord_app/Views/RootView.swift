import SwiftUI

public struct RootView: View {
    @StateObject private var app = AppState.shared
    
    public init() {}
    
    public var body: some View {
        Group {
            if app.isAuthenticated {
                HomeView()
            } else {
                SplashView()
            }
        }
        .environmentObject(app)
    }
}