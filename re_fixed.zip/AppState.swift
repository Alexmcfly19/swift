import Foundation
import SwiftUI
import Combine

final class AppState: ObservableObject {
    static let shared = AppState()
    @Published var isAuthenticated: Bool = false
    @Published var token: String? 
    @Published var currentEmail: String = ""
    @Published var currentUserId: Int?
    @Published var pendingOTP: String?          // OTP returned from /clients or /clients/activation
    @Published var needsActivation: Bool = false
    
    private init() {
        if let t = UserDefaults.standard.string(forKey: "rechord.jwt") {
            token = t
            isAuthenticated = true
        }
    }
    
    func signOut() {
        token = nil
        isAuthenticated = false
        currentUserId = nil
        currentEmail = ""
        pendingOTP = nil
        needsActivation = false
    }
}
