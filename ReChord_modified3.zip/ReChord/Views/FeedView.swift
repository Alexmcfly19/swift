import SwiftUI
internal import MapKit
import CoreLocation

/// Displays a map with voice markers and a segmented control to
/// optionally filter voices to those created by the current user. The
/// map uses MapKit to render an interactive map and shows each voice as a
/// circular annotation. Because MapKit is bundled with iOS, no API key is
/// required. Selecting the second segment filters the list to only
/// voices whose `ownerId` matches the logged‑in user.
struct FeedView: View {
    @EnvironmentObject private var app: AppState
    @StateObject private var locationManager = LocationManager()
    @State private var voices: [Voice] = []
    @State private var isLoading: Bool = false
    @State private var error: String? = nil
    @State private var filterIndex: Int = 0

    // The map view handles camera positioning internally by
    // centring on the average coordinate of the loaded voices. A helper
    // like `updateMapRegion` is no longer needed because the map view
    // automatically updates its region when the view appears (see
    // `VoiceMapWithAnnotationsView`).

    /// Filter the loaded voices based on the selected segment. When
    /// `filterIndex` is 1 the current user's voices are returned. For any
    /// other value all voices are returned.
    private var filteredVoices: [Voice] {
        if filterIndex == 1, let currentId = app.currentUserId {
            return voices.filter { voice in
                if let ownerId = voice.ownerId { return ownerId == currentId }
                return false
            }
        }
        return voices
    }

    // The voice selected by tapping on a map annotation. When this
    // value becomes non-nil a compact overlay is presented at the
    // bottom of the screen showing a preview of the voice along with
    // minimal playback and reaction controls. Clearing this value
    // hides the overlay.
    @State private var selectedVoice: Voice?

    var body: some View {
        // Use a ZStack to layer the interactive map beneath the overlaying
        // controls. Placing the map at the bottom of the ZStack and
        // ignoring safe areas ensures it fills the entire screen. The
        // overlaying VStack sits on top and provides a place for the
        // title, segmented picker and status indicators. This layout
        // avoids collapsing the map when embedded in other view
        // hierarchies (e.g. a `TabView`) and gives explicit control
        // over the layering order.
        ZStack(alignment: .top) {
            // Base map layer. Pass a closure to handle selection of an
            // annotation. When an annotation is tapped the selected
            // voice is stored in state which triggers the modal to
            // present.
            VoiceMapWithAnnotationsView(voices: filteredVoices, selectedVoice: selectedVoice) { voice in
                // Assign the tapped voice to selectedVoice. This triggers
                // the mini overlay to appear. If the same voice is
                // tapped twice the overlay will simply update its
                // contents.
                selectedVoice = voice
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .ignoresSafeArea()

            // Overlay containing the title, picker and indicators. It
            // uses a material background to keep the text legible
            // against the map. By placing this overlay inside the
            // ZStack it will always appear above the map.
            VStack(spacing: 8) {
                // App title
                Text("ReChord")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .shadow(radius: 6)
                // Segmented control: 0 = all voices, 1 = my voices
                Picker(selection: $filterIndex, label: EmptyView()) {
                    Image(systemName: "mappin.and.ellipse").tag(0)
                    Image(systemName: "person.circle").tag(1)
                }
                .pickerStyle(.segmented)
                .frame(width: 200)
                .padding(.vertical, 4)
                // Loading or error indicators
                if isLoading {
                    ProgressView().padding(.top, 8)
                } else if let err = error {
                    Text(err)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .padding(.top, 8)
                }
            }
            .padding(.horizontal)
            .padding(.top, 10)
            // Remove the frosted material and rounded rectangle to allow
            // the header to appear fully transparent. Keeping only the
            // padding ensures the "ReChord" title and segmented picker
            // float directly above the map without an enclosing card.
            .padding(.top, 8)
        }
        // Present a mini overlay at the bottom when a voice is
        // selected. The overlay binds to a Boolean that reflects
        // whether selectedVoice is non-nil. When the user taps the
        // close button inside the overlay the binding sets
        // selectedVoice back to nil, hiding the overlay. A move
        // transition animates the overlay's entrance and exit.
        .overlay(
            Group {
                if let voice = selectedVoice {
                    MiniVoiceOverlayView(
                        voice: voice,
                        isPresented: Binding(
                            get: { self.selectedVoice != nil },
                            set: { newValue in
                                if !newValue {
                                    self.selectedVoice = nil
                                }
                            }
                        )
                    )
                    .environmentObject(app)
                    .transition(.move(edge: .bottom))
                }
            }, alignment: .bottom
        )
        .onAppear {
            // Only fetch once when the view appears
            if voices.isEmpty {
                Task { await fetchVoices() }
            }
        }
    }

    /// Fetch voices within a radius of the user's current location. The
    /// implementation mirrors ``MapExploreView`` but is duplicated here to
    /// keep the map page self‑contained. Upon success the voices array
    /// and map region are updated on the main thread.
    private func fetchVoices() async {
        isLoading = true
        error = nil
        guard let token = app.token else {
            error = "Please sign in to load voices"
            isLoading = false
            return
        }
        let lat = locationManager.region.center.latitude
        let lon = locationManager.region.center.longitude
        let latitude = lat == 0 ? 40.7128 : lat
        let longitude = lon == 0 ? -74.0060 : lon
        let userId = app.currentUserId ?? 0
        do {
            let url = APIConfig.baseURL.appendingPathComponent("voices/\(latitude)/\(longitude)/\(userId)/Show")
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.addValue("application/json", forHTTPHeaderField: "Accept")
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
            if http.statusCode == 401 { throw APIError.unauthorized }
            let json = try JSONSerialization.jsonObject(with: data)
            var items: [[String: Any]] = []
            if let arr = json as? [[String: Any]] {
                items = arr
            } else if let dict = json as? [String: Any] {
                if let arr = dict["data"] as? [[String: Any]] {
                    items = arr
                } else if let arr = dict["voices"] as? [[String: Any]] {
                    items = arr
                } else {
                    for value in dict.values {
                        if let arr = value as? [[String: Any]] {
                            items = arr
                            break
                        }
                    }
                }
            }
            var loaded: [Voice] = []
            loaded.reserveCapacity(items.count)
            func toDouble(_ value: Any?) -> Double? {
                if let d = value as? Double { return d }
                if let n = value as? NSNumber { return n.doubleValue }
                if let s = value as? String { return Double(s) }
                return nil
            }
            for item in items {
                let id = (item["id"] as? Int)
                    ?? (item["Voice_Id"] as? Int)
                    ?? (item["voice_id"] as? Int)
                    ?? (item["Voice_id"] as? Int)
                    ?? Int((item["id"] as? String) ?? "")
                guard let vid = id else { continue }
                let title = (item["title"] as? String)
                    ?? (item["Title"] as? String)
                    ?? "Untitled"
                var latVal: Any? = item["Position_X"] ?? item["position_x"] ?? item["latitude"] ?? item["lat"] ?? item["x"]
                var lonVal: Any? = item["Position_Y"] ?? item["position_y"] ?? item["longitude"] ?? item["lon"] ?? item["y"]
                if latVal == nil || lonVal == nil, let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
                    latVal = geo[0]
                    lonVal = geo[1]
                }
                guard let la = toDouble(latVal), let lo = toDouble(lonVal) else { continue }
                let picString = (item["Picture_Link"] as? String)
                    ?? (item["picture_link"] as? String)
                    ?? (item["image"] as? String)
                let pictureURL = picString.flatMap { URL(string: $0) }
                let voiceString = (item["Voice_Link"] as? String)
                    ?? (item["voice_link"] as? String)
                    ?? (item["voice"] as? String)
                let voiceURL = voiceString.flatMap { URL(string: $0) }
                let likesValue: Int? = {
                    if let v = item["LikesCount"] as? Int { return v }
                    if let v = item["likes"] as? Int { return v }
                    if let s = item["LikesCount"] as? String { return Int(s) }
                    if let s = item["likes"] as? String { return Int(s) }
                    return nil
                }()
                let name = (item["Owner"] as? String)
                    ?? (item["owner"] as? String)
                    ?? (item["owner_name"] as? String)
                    ?? (item["client_name"] as? String)
                    ?? (item["full_name"] as? String)
                    ?? (item["username"] as? String)
                let comments: Int? = {
                    if let v = item["comments_count"] as? Int { return v }
                    if let s = item["comments_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract dislikes count using a variety of expected keys
                let dislikesValue: Int? = {
                    if let v = item["DislikesCount"] as? Int { return v }
                    if let v = item["dislikes"] as? Int { return v }
                    if let v = item["dislike_count"] as? Int { return v }
                    if let v = item["dislikes_count"] as? Int { return v }
                    if let s = item["DislikesCount"] as? String { return Int(s) }
                    if let s = item["dislikes"] as? String { return Int(s) }
                    if let s = item["dislike_count"] as? String { return Int(s) }
                    if let s = item["dislikes_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract shares count using common naming conventions
                let sharesValue: Int? = {
                    if let v = item["SharesCount"] as? Int { return v }
                    if let v = item["shares"] as? Int { return v }
                    if let v = item["share_count"] as? Int { return v }
                    if let v = item["shares_count"] as? Int { return v }
                    if let s = item["SharesCount"] as? String { return Int(s) }
                    if let s = item["shares"] as? String { return Int(s) }
                    if let s = item["share_count"] as? String { return Int(s) }
                    if let s = item["shares_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract playback count using multiple potential key names
                let playsValue: Int? = {
                    if let v = item["PlaybacksCount"] as? Int { return v }
                    if let v = item["playbacks"] as? Int { return v }
                    if let v = item["play_count"] as? Int { return v }
                    if let v = item["plays"] as? Int { return v }
                    if let v = item["views"] as? Int { return v }
                    if let v = item["playbacks_count"] as? Int { return v }
                    if let s = item["PlaybacksCount"] as? String { return Int(s) }
                    if let s = item["playbacks"] as? String { return Int(s) }
                    if let s = item["play_count"] as? String { return Int(s) }
                    if let s = item["plays"] as? String { return Int(s) }
                    if let s = item["views"] as? String { return Int(s) }
                    if let s = item["playbacks_count"] as? String { return Int(s) }
                    return nil
                }()
                let ownerIdValue: Int? = {
                    if let v = item["client_id"] as? Int { return v }
                    if let v = item["user_id"] as? Int { return v }
                    if let v = item["owner_id"] as? Int { return v }
                    if let s = item["client_id"] as? String { return Int(s) }
                    if let s = item["user_id"] as? String { return Int(s) }
                    if let s = item["owner_id"] as? String { return Int(s) }
                    return nil
                }()
                loaded.append(
                    Voice(
                        id: vid,
                        title: title,
                        latitude: la,
                        longitude: lo,
                        pictureURL: pictureURL,
                        voiceURL: voiceURL,
                        likes: likesValue,
                        dislikes: dislikesValue,
                        shares: sharesValue,
                        playCount: playsValue,
                        ownerName: name,
                        commentsCount: comments,
                        ownerId: ownerIdValue
                    )
                )
            }
            DispatchQueue.main.async {
                self.voices = loaded
                self.isLoading = false
                // No need to explicitly update a map region because
                // the MapTiler map view will automatically fly to a
                // sensible centre when voices change (see
                // `VoiceMapWithAnnotationsView`).
            }
        } catch {
            DispatchQueue.main.async {
                self.error = error.localizedDescription
                self.isLoading = false
            }
        }
    }
}
