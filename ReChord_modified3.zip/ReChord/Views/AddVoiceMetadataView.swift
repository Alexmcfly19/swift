import SwiftUI
internal import MapKit
import PhotosUI
import AVFoundation
import Combine

/// This view is presented as an overlay when the user is creating a new
/// voice. It allows entry of textual metadata, location and an optional
/// cover image. The actual recording logic and state (e.g. current
/// recording, playback and sending) is handled by an external
/// ``RecorderManager`` which is injected via the environment. This
/// separation allows the bottom navigation bar to control recording
/// without duplicating buttons inside the modal.

/// A view that allows the user to enter metadata for a new voice
/// recording. It displays the user's current location on a map with a
/// marker and presents a card at the bottom where details such as
/// description, cover image, privacy settings and a place name can be
/// entered. A simple audio bar shows the selected voice file and
/// includes a delete button. When the user has finished entering
/// information they can dismiss the view via the built‑in dismiss
/// gesture; in a future iteration a dedicated upload button could be
/// added.
struct AddVoiceMetadataView: View {
    /// Injected recorder manager which owns the recording state,
    /// playback and uploading logic. All audio related actions are
    /// forwarded to this manager. Metadata fields bound to this view
    /// update the manager's properties directly.
    @EnvironmentObject private var recorder: RecorderManager
    // The shared application state is injected but unused in this view.
    // Uploading is handled by the recorder manager.
    @EnvironmentObject private var app: AppState
    @Environment(\.dismiss) private var dismiss
    // Location manager to determine the user's current location. A
    // separate instance is used here rather than sharing the one from
    // FeedView or MapExploreView to avoid side effects.
    @StateObject private var locationManager = LocationManager()
    // Photo selection state. We use PhotosPicker from PhotosUI to
    // select an image and then convert it into a UIImage for preview.
    @State private var selectedPhoto: PhotosPickerItem? = nil
    @State private var showImagePreview: Bool = false
    // Timer to update progress
    private let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack(alignment: .bottom) {
            // Map showing current region with a marker at the centre
            Map(coordinateRegion: $locationManager.region, annotationItems: [MarkerItem(coordinate: locationManager.region.center)]) { item in
                MapAnnotation(coordinate: item.coordinate) {
                    Image(systemName: "mappin.circle.fill")
                        .resizable()
                        .foregroundColor(.red)
                        .frame(width: 32, height: 32)
                        .shadow(radius: 3)
                }
            }
            .ignoresSafeArea()
            // Darken the background slightly to improve contrast with the overlay
            Color.black.opacity(0.2).ignoresSafeArea()
            // Overlay card containing metadata fields
            VStack(spacing: 16) {
                // Description
                TextField("About this record", text: $recorder.descriptionText)
                    .padding(.horizontal, 16)
                    .frame(height: 44)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.white.opacity(0.3))
                    )
                // Row for cover button and privacy toggle.
                HStack(spacing: 12) {
                    PhotosPicker(selection: $selectedPhoto, matching: .images) {
                        HStack {
                            Image(systemName: "camera.fill")
                            Text(recorder.coverImage == nil ? "add a cover" : "change cover")
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .foregroundColor(.white)
                        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(hex: 0x0F4D8A)))
                    }
                    .onChange(of: selectedPhoto) { newValue in
                        // Load the selected image asynchronously. When selected,
                        // assign to the manager and show preview.
                        Task {
                            if let newValue,
                               let data = try? await newValue.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                recorder.coverImage = uiImage
                                showImagePreview = true
                            }
                        }
                    }
                    Spacer()
                    Toggle(isOn: $recorder.isPrivate) {
                        Text(recorder.isPrivate ? "Private" : "Precise Location")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Color.green))
                }
                // Row for place name and precision toggle.
                HStack(spacing: 12) {
                    TextField("Name this place", text: $recorder.placeName)
                        .padding(.horizontal, 16)
                        .frame(height: 44)
                        .background(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(Color.white.opacity(0.3))
                        )
                    Toggle(isOn: $recorder.isPrecise) {
                        Text("Precise")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Color.green))
                }
                // Audio bar with play/pause and delete.
                HStack(spacing: 12) {
                    Button(action: { recorder.togglePlay() }) {
                        Image(systemName: recorder.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(size: 36))
                            .foregroundColor(Color(hex: 0x0F4D8A))
                    }
                    .disabled(recorder.voiceURL == nil)
                    // Faux waveform progress bar
                    HStack(spacing: 2) {
                        ForEach(0..<30, id: \.self) { index in
                            Capsule()
                                .fill(Double(index) / 30.0 < recorder.progress ? Color(hex: 0x0F4D8A) : Color.white.opacity(0.6))
                                .frame(width: 3, height: heightForBar(index))
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: 24)
                    // Delete button
                    Button(action: {
                        recorder.deleteRecording()
                    }) {
                        Image(systemName: "trash")
                            .font(.system(size: 24))
                            .foregroundColor(.red)
                    }
                    .disabled(recorder.voiceURL == nil)
                }
                // Keep progress updating by pinging the player's current time.
                .onReceive(timer) { _ in
                    _ = recorder.player?.currentTime()
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(.ultraThinMaterial)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .stroke(Color.white.opacity(0.4), lineWidth: 1)
            )
            .padding(.horizontal, 16)
            // Increase bottom padding to create space for the underlying navigation bar
            .padding(.bottom, 90)
        }
        .onAppear {
            // When the view appears, update the recorder's player if a voice exists.
            if recorder.player == nil, let url = recorder.voiceURL {
                recorder.player = AVPlayer(url: url)
            }
        }
        .fullScreenCover(isPresented: $showImagePreview) {
            if let image = recorder.coverImage {
                ZStack {
                    Color.black.opacity(0.8).ignoresSafeArea()
                    VStack {
                        Spacer()
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(24)
                            .padding()
                        Spacer()
                        HStack {
                            Button(action: { showImagePreview = false }) {
                                Image(systemName: "xmark")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .padding(12)
                                    .background(Circle().fill(Color.black.opacity(0.6)))
                            }
                            Spacer()
                            // Placeholder rotate button
                            Button(action: {}) {
                                Image(systemName: "arrow.clockwise")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .padding(12)
                                    .background(Circle().fill(Color.black.opacity(0.6)))
                            }
                            Spacer()
                            Button(action: { showImagePreview = false }) {
                                Text("Done")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 24)
                                    .background(Capsule().fill(Color.green))
                            }
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 32)
                    }
                }
            }
        }
    }
    /// Compute a bar height for the faux waveform. Uses a sinusoid to
    /// vary heights between 6 and 24 points. This helper remains
    /// unchanged from the previous implementation.
    private func heightForBar(_ index: Int) -> CGFloat {
        let amplitude: Double = 9
        let base: Double = 15
        let value = sin(Double(index) / 30.0 * .pi) * amplitude + base
        return CGFloat(value)
    }
}

/// A lightweight struct to wrap a coordinate in an identifiable
/// container. This allows the map view to display a marker at the
/// user's current location when used with `annotationItems`.
private struct MarkerItem: Identifiable {
    let id = UUID()
    var coordinate: CLLocationCoordinate2D
}
