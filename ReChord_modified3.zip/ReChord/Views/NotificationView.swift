import SwiftUI

/// A view that presents user notifications and their own published ReChords in a two‑tab interface.
///
/// The first tab shows likes and comments on the user's ReChords by consuming the
/// `/clients/{id}/notifications` endpoint. The second tab lists the user's own
/// ReChords by calling the `/voices/{id}/{page}/ShowUserVoices` endpoint.
///
/// This view relies on ``AppState`` to obtain the current user's identifier and
/// authentication token. On first appearance it will automatically fetch
/// notifications and ReChords in parallel. If either request fails the error
/// message is displayed at the bottom of the list. You can pull down to
/// refresh either tab.
struct NotificationView: View {
    @EnvironmentObject private var app: AppState
    @State private var selectedTab: Int = 0
    @State private var notifications: [[String: Any]] = []
    @State private var myVoices: [[String: Any]] = []
    @State private var isLoading: Bool = false
    @State private var error: String?

    // State used to drive presentation of a map sheet. When a user taps
    // the map icon on a row in the "My ReChords" list we store the
    // associated voice here and toggle this flag to `true`. A sheet
    // bound to this flag will present a map centred on the selected
    // voice's coordinates. When the sheet is dismissed the state resets.
    @State private var showVoiceMap: Bool = false
    @State private var selectedVoiceForMap: Voice? = nil
    
    private enum Tab: Int, CaseIterable {
        case notifications = 0
        case voices = 1
        
        var title: String {
            switch self {
            case .notifications: return "Notifications"
            case .voices: return "My ReChords"
            }
        }
    }
    
    var body: some View {
        ZStack {
            // Background imagery to match the rest of the app
            Image("bg-earth-2")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.25))
            
            VStack(spacing: 16) {
                // Title
                
                
                // Segmented control for tabs
                Picker(selection: $selectedTab) {
                    // Iterate over tabs by their case; use `.self` for id since
                    // `Tab` conforms to `Hashable` via `CaseIterable`.
                    ForEach(Tab.allCases, id: \.self) { tab in
                        Text(tab.title).tag(tab.rawValue)
                    }
                } label: {
                    EmptyView()
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .onChange(of: selectedTab) { _ in
                    Task { await refreshCurrentTab() }
                }
                
                // List contents
                if selectedTab == Tab.notifications.rawValue {
                    notificationList
                } else {
                    voiceList
                }
                
                // Error / loading indicator
                if isLoading {
                    ProgressView().padding()
                }
                if let error = error {
                    Text(error)
                        .foregroundStyle(.red)
                        .font(.footnote)
                        .padding(.horizontal)
                }
            }
        }
        .onAppear {
            // Only load once when the view appears
            if notifications.isEmpty && myVoices.isEmpty {
                Task { await refreshAll() }
            }
        }
    }
    
    // MARK: - Subviews
    private var notificationList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(notifications.indices, id: \.self) { index in
                    let item = notifications[index]
                    NotificationRow(item: item)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
    }
    
    private var voiceList: some View {
        // A scrollable list of the user's own voices. Each row includes
        // buttons to view the voice on a map and to delete the voice.
        // Deletion triggers a network request to remove the voice from
        // the server and updates the local list on success.
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(myVoices.indices, id: \.self) { index in
                    let voice = myVoices[index]
                    VoiceRow(
                        item: voice,
                        onMapTap: { tappedVoice in
                            // Store the selected voice and present the map sheet
                            self.selectedVoiceForMap = tappedVoice
                            self.showVoiceMap = true
                        },
                        onDelete: { voiceId in
                            Task {
                                guard let token = app.token else { return }
                                do {
                                    try await APIClient.shared.deleteVoice(voiceId: voiceId, token: token)
                                    await MainActor.run {
                                        self.myVoices.removeAll { item in
                                            let matchId: Int? = {
                                                if let id = item["id"] as? Int { return id }
                                                if let id = item["voice_id"] as? Int { return id }
                                                if let id = item["Voice_Id"] as? Int { return id }
                                                if let s = item["id"] as? String, let i = Int(s) { return i }
                                                if let s = item["voice_id"] as? String, let i = Int(s) { return i }
                                                if let s = item["Voice_Id"] as? String, let i = Int(s) { return i }
                                                return nil
                                            }()
                                            return matchId == voiceId
                                        }
                                    }
                                } catch {
                                    await MainActor.run {
                                        self.error = error.localizedDescription
                                    }
                                }
                            }
                        }
                    )
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .sheet(isPresented: $showVoiceMap) {
            if let voice = selectedVoiceForMap {
                VoiceMapWithAnnotationsView(voices: [voice], selectedVoice: voice)
            }
        }
    }
    
    // MARK: - Networking
    /// Reload both tabs simultaneously
    private func refreshAll() async {
        isLoading = true
        error = nil
        async let n = fetchNotifications()
        async let v = fetchVoices()
        do {
            notifications = try await n
            myVoices = try await v
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }
    
    /// Reload only the currently visible tab
    private func refreshCurrentTab() async {
        isLoading = true
        error = nil
        switch Tab(rawValue: selectedTab) {
        case .notifications:
            do { notifications = try await fetchNotifications() } catch { self.error = error.localizedDescription }
        case .voices:
            do { myVoices = try await fetchVoices() } catch { self.error = error.localizedDescription }
        case .none:
            break
        }
        isLoading = false
    }
    
    private func fetchNotifications() async throws -> [[String: Any]] {
        guard let token = app.token else { throw APIError.missingToken }
        guard let id = app.currentUserId else { return [] }
        return try await APIClient.shared.fetchNotifications(clientId: id, token: token)
    }
    
    private func fetchVoices() async throws -> [[String: Any]] {
        guard let token = app.token else { throw APIError.missingToken }
        guard let id = app.currentUserId else { return [] }
        return try await APIClient.shared.fetchUserVoices(clientId: id, page: 1, token: token)
    }
}

// MARK: - Row Views


private struct NotificationRow: View {
    var item: [String: Any]
    
    private var primaryText: String {
        
        if let message = item["message"] as? String {
            return message
        }
        if let text = item["text"] as? String {
            return text
        }
        if let title = item["title"] as? String {
            return title
        }
        // Fallback: construct a descriptive string from arbitrary keys
        return item.map { "\($0.key): \($0.value)" }.joined(separator: ", ")
    }
    
    private var subtitleText: String? {
        // For comments and likes, there may be a sender or voice title
        if let sender = item["sender"] as? String {
            return sender
        }
        if let author = item["author"] as? String {
            return author
        }
        return nil
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Placeholder avatar; if the API supplies an avatar URL you could
            // replace this with AsyncImage to fetch it from the network
            Circle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 42, height: 42)
                .overlay(
                    Text(initials(from: subtitleText ?? primaryText))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(primaryText)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                if let subtitle = subtitleText {
                    Text(subtitle)
                        .font(.system(size: 13))
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            Spacer()
        }
        .padding()
        .background(.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

/// A single row representing one of the user's ReChords. Displays a
/// thumbnail (if provided), a title or description, and accessory icons.
private struct VoiceRow: View {
    var item: [String: Any]
    /// Callback invoked when the map icon is tapped. When provided,
    /// this closure receives a ``Voice`` describing the tapped row and
    /// can be used to present a map view. Defaults to `nil` to allow
    /// the row to be reused in contexts where no map navigation is needed.
    var onMapTap: ((Voice) -> Void)? = nil
    /// Callback invoked when the trash icon is tapped. When provided,
    /// this closure receives the identifier of the voice to be deleted
    /// and can be used to perform an API call and update the list.
    var onDelete: ((Int) -> Void)? = nil
    
    private var titleText: String {
        if let t = item["Title"] as? String { return t }
        if let desc = item["description"] as? String { return desc }
        if let name = item["name"] as? String { return name }
        return "Untitled ReChord"
    }
    
    /// Determine whether this voice has a valid location. We attempt to
    /// parse latitude and longitude from a variety of common keys. Both
    /// values must be present for the map button to appear. If either
    /// coordinate is unavailable the row behaves as if no location is
    /// attached.
    private var locationEnabled: Bool {
        return latitude != nil && longitude != nil
    }

    /// Convert arbitrary JSON values into a `Double`. Accepts numeric
    /// types and strings and returns `nil` for anything else. This
    /// helper centralises type coercion for latitude and longitude.
    private func toDouble(_ value: Any?) -> Double? {
        if let d = value as? Double { return d }
        if let n = value as? NSNumber { return n.doubleValue }
        if let s = value as? String { return Double(s) }
        return nil
    }

    /// Attempt to extract a numeric latitude from the item. Supports
    /// multiple key names and string coercion. Returns `nil` when no
    /// coordinate is available. Some API endpoints use `Position_X` or
    /// `position_x` instead of `latitude`, and occasionally the
    /// coordinate is contained in a `GeoCode` array. This parser
    /// normalises all these possibilities into a single value.
    private var latitude: Double? {
        // Common keys for latitude
        let latKeys = ["latitude", "lat", "Latitude", "Lat", "Position_X", "position_x", "x"]
        for key in latKeys {
            if let value = item[key] {
                if let d = toDouble(value) { return d }
            }
        }
        // GeoCode array [lat, lon]
        if let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
            return toDouble(geo[0])
        }
        return nil
    }

    /// Attempt to extract a numeric longitude from the item. Supports
    /// multiple key names and string coercion. Returns `nil` when no
    /// coordinate is available. Some API endpoints use `Position_Y` or
    /// `position_y` instead of `longitude`, and occasionally the
    /// coordinate is contained in a `GeoCode` array. This parser
    /// normalises all these possibilities into a single value.
    private var longitude: Double? {
        // Common keys for longitude
        let lonKeys = ["longitude", "lng", "lon", "Longitude", "Lng", "Lon", "Position_Y", "position_y", "y"]
        for key in lonKeys {
            if let value = item[key] {
                if let d = toDouble(value) { return d }
            }
        }
        // GeoCode array [lat, lon]
        if let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
            return toDouble(geo[1])
        }
        return nil
    }

    /// Attempt to read the identifier for this voice. Falls back to a random
    /// value when the id fields are missing or cannot be parsed. Some API
    /// responses label the voice id as `voice_id` or similar; those are
    /// handled here as well.
    private var idValue: Int {
        if let id = item["id"] as? Int { return id }
        if let vid = item["voice_id"] as? Int { return vid }
        if let vid = item["Voice_Id"] as? Int { return vid }
        if let s = (item["id"] as? String) ?? (item["voice_id"] as? String) ?? (item["Voice_Id"] as? String), let i = Int(s) {
            return i
        }
        return Int.random(in: 0..<10_000)
    }

    /// Attempt to read the number of likes from various possible keys. Returns 0 if absent.
    private var likeCount: Int {
        if let c = item["likes"] as? Int { return c }
        if let c = item["LikesCount"] as? Int { return c }
        if let c = item["like_count"] as? Int { return c }
        if let s = item["likes"] as? String, let i = Int(s) { return i }
        if let s = item["like_count"] as? String, let i = Int(s) { return i }
        if let s = item["LikesCount"] as? String, let i = Int(s) { return i }
        return 0
    }

    /// Attempt to read the number of playbacks from various possible keys. Returns 0 if absent.
    private var playbackCount: Int {
        if let c = item["playback"] as? Int { return c }
        if let c = item["Number_Of_Playbacks"] as? Int { return c }
        if let c = item["play_count"] as? Int { return c }
        if let c = item["playback_count"] as? Int { return c }
        if let s = item["playback"] as? String, let i = Int(s) { return i }
        if let s = item["playbacks"] as? String, let i = Int(s) { return i }
        if let s = item["play_count"] as? String, let i = Int(s) { return i }
        if let s = item["Number_Of_Playbacks"] as? String, let i = Int(s) { return i }
        return 0
    }
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                // Thumbnail placeholder; if the API supplies an image URL you
                // could replace this with AsyncImage to fetch it from the network
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 70, height: 70)
                Image(systemName: "play.circle.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text(titleText)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                // Row with location and metrics
                HStack(spacing: 12) {
                    if locationEnabled {
                        Image(systemName: "mappin.and.ellipse")
                            .foregroundColor(.white.opacity(0.8))
                    }
                    // Likes count
                    HStack(spacing: 4) {
                        Image(systemName: "heart")
                        Text(String(likeCount))
                    }
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.8))
                    // Playbacks count
                    HStack(spacing: 4) {
                        Image(systemName: "play.fill")
                        Text(String(playbackCount))
                    }
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.8))
                }
            }
            Spacer()
            // Show a map button when the voice has valid coordinates. Tapping
            // this button constructs a Voice model and invokes the callback.
            if let lat = latitude, let lon = longitude {
                Button(action: {
                    // Construct a lightweight Voice from the dictionary
                    let voice = Voice(
                        id: idValue,
                        title: titleText,
                        latitude: lat,
                        longitude: lon,
                        pictureURL: nil,
                        voiceURL: nil,
                        likes: nil,
                        dislikes: nil,
                        shares: nil,
                        playCount: nil,
                        ownerName: nil,
                        commentsCount: nil,
                        ownerId: nil
                    )
                    onMapTap?(voice)
                }) {
                    Image(systemName: "map.fill")
                        .foregroundColor(.white.opacity(0.8))
                }
            }
            // Provide a delete button if a callback is supplied. Tapping
            // this icon invokes the deletion handler with the voice's id.
            if let onDelete = onDelete {
                Button(action: {
                    onDelete(idValue)
                }) {
                    Image(systemName: "trash")
                        .foregroundColor(.white.opacity(0.8))
                }
            }
        }
        .padding()
        .background(.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - Helpers
/// Extract the initials from a string for use in placeholder avatars.
private func initials(from string: String) -> String {
    let comps = string.split(separator: " ").map { String($0) }
    let initials = comps.prefix(2).compactMap { $0.first }.map { String($0) }.joined()
    return initials.isEmpty ? "?" : initials
}
