import SwiftUI
import AVFoundation
import Combine
internal import MapKit

/// A vertically paging feed of ReChord voices modelled after the post
/// screen in the provided screenshot. Each page displays a single voice
/// with its associated image, title, owner, like/comment counts and an
/// audio player. Swipe horizontally to browse through voices. The
/// background of the feed is blurred from the currently visible
/// post's picture. New posts are loaded from the same API used by
/// ``MapExploreView`` and ``FeedView``.
struct PostFeedView: View {
    @EnvironmentObject private var app: AppState
    @StateObject private var locationManager = LocationManager()
    @State private var voices: [Voice] = []
    @State private var selectedIndex: Int = 0
    @State private var isLoading: Bool = false
    @State private var error: String?

    var body: some View {
        ZStack(alignment: .bottom) {
            // Blurred background derived from the current voice's image.
            Group {
                if voices.indices.contains(selectedIndex),
                   let url = voices[selectedIndex].pictureURL {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure(_):
                            Image("placeholder-bg").resizable().scaledToFill()
                        case .empty:
                            Image("placeholder-bg").resizable().scaledToFill()
                        @unknown default:
                            Image("placeholder-bg").resizable().scaledToFill()
                        }
                    }
                } else {
                    Image("placeholder-bg").resizable().scaledToFill()
                }
            }
            .ignoresSafeArea()
            .blur(radius: 20)
            // Semi‑transparent overlay to improve contrast
            Color.black.opacity(0.3).ignoresSafeArea()
            VStack {
                // Top title
                // Display the title centered at the top. A spacer on either
                // side ensures the label stays centered regardless of
                // surrounding content.
                HStack {
                    Spacer()
                    Text("ReChord")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .shadow(radius: 6)
                    Spacer()
                }
                .padding([.top, .horizontal], 16)
                // Removed spacer to allow the feed content to extend
                // upward, positioning the post cards closer to the header.
                // Loading or error indicators
                if isLoading {
                    ProgressView()
                        .padding(.bottom, 160)
                } else if let error = error {
                    Text(error)
                        .foregroundStyle(.white)
                        .padding(.bottom, 160)
                } else if voices.isEmpty {
                    Text("No posts")
                        .foregroundStyle(.white)
                        .padding(.bottom, 160)
                } else {
                    // Limit the height of the feed to avoid the pictures
                    // overwhelming the screen. By constraining the
                    // TabView's height we leave room above and below for
                    // contextual UI while still showing each post clearly.
                    // Rotate the TabView by 90 degrees to achieve vertical
                    // paging. Each card is rotated back within the loop so it
                    // appears upright. Additional vertical padding inside the
                    // rotated card creates space for adjacent posts to peek
                    // from the top and bottom, matching the provided design.
                    GeometryReader { proxy in
                        TabView(selection: $selectedIndex) {
                            ForEach(0..<voices.count, id: \.self) { index in
                                let voice = voices[index]
                                PostCardView(voice: voice)
                                    // Rotate each card so that when the parent
                                    // TabView is rotated back it displays upright.
                                    .rotationEffect(.degrees(90))
                                    // Assign a size that allows some of the next
                                    // and previous posts to peek vertically. The
                                    // width becomes the height of the available
                                    // space due to rotation and the height is
                                    // reduced to leave vertical margins.
                                    // Expand the card size so that it stretches closer
                                    // to the "ReChord" title. The width reduction is
                                    // lessened and the height is increased to 90% of
                                    // the container width. Reduce the vertical
                                    // padding to allow posts to peek slightly while
                                    // providing more room for the current card.
                                    .frame(width: proxy.size.height - 80, height: proxy.size.width * 0.9)
                                    .padding(.vertical, 20)
                                    .tag(index)
                            }
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        // Rotate the entire TabView to change the paging
                        // direction from horizontal to vertical.
                        .rotationEffect(.degrees(-90))
                        // Swap the frame dimensions to account for rotation and
                        // cap the height to prevent the cards from becoming
                        // excessively tall on large screens.
                        // Increase the height cap from 650 to 750 so that the
                        // TabView can occupy more vertical space on larger
                        // screens, bringing the post cards closer to the
                        // header. On smaller devices the height will still
                        // respect the available screen space.
                        .frame(width: proxy.size.width, height: min(proxy.size.height, 750))
                    }
                    // Add bottom padding to avoid overlapping the navigation bar.
                    .padding(.bottom, 60)
                }
            }
        }
        .onAppear {
            // Fetch posts once when the view appears
            if voices.isEmpty {
                Task { await fetchVoices() }
            }
        }
    }

    /// Fetch voices using the same API call as ``MapExploreView``. The
    /// voices are sorted as returned by the server. Errors are
    /// surfaced in the ``error`` state and a loading spinner is
    /// displayed while the request is outstanding.
    private func fetchVoices() async {
        isLoading = true
        error = nil
        guard let token = app.token else {
            error = "Please sign in to load posts"
            isLoading = false
            return
        }
        let lat = locationManager.region.center.latitude
        let lon = locationManager.region.center.longitude
        let latitude = lat == 0 ? 40.7128 : lat
        let longitude = lon == 0 ? -74.0060 : lon
        let userId = app.currentUserId ?? 0
        do {
            let url = APIConfig.baseURL.appendingPathComponent("voices/\(latitude)/\(longitude)/\(userId)/Show")
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.addValue("application/json", forHTTPHeaderField: "Accept")
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
            if http.statusCode == 401 { throw APIError.unauthorized }
            // Parse the response into an array of dictionaries
            let json = try JSONSerialization.jsonObject(with: data)
            var items: [[String: Any]] = []
            if let arr = json as? [[String: Any]] {
                items = arr
            } else if let dict = json as? [String: Any] {
                if let arr = dict["data"] as? [[String: Any]] {
                    items = arr
                } else if let arr = dict["voices"] as? [[String: Any]] {
                    items = arr
                } else {
                    for value in dict.values {
                        if let arr = value as? [[String: Any]] {
                            items = arr
                            break
                        }
                    }
                }
            }
            var loaded: [Voice] = []
            loaded.reserveCapacity(items.count)
            func toDouble(_ value: Any?) -> Double? {
                if let d = value as? Double { return d }
                if let n = value as? NSNumber { return n.doubleValue }
                if let s = value as? String { return Double(s) }
                return nil
            }
            for item in items {
                let id = (item["id"] as? Int)
                    ?? (item["Voice_Id"] as? Int)
                    ?? (item["voice_id"] as? Int)
                    ?? (item["Voice_id"] as? Int)
                    ?? Int((item["id"] as? String) ?? "")
                guard let vid = id else { continue }
                let title = (item["title"] as? String)
                    ?? (item["Title"] as? String)
                    ?? "Untitled"
                var latVal: Any? = item["Position_X"] ?? item["position_x"] ?? item["latitude"] ?? item["lat"] ?? item["x"]
                var lonVal: Any? = item["Position_Y"] ?? item["position_y"] ?? item["longitude"] ?? item["lon"] ?? item["y"]
                if latVal == nil || lonVal == nil, let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
                    latVal = geo[0]
                    lonVal = geo[1]
                }
                guard let la = toDouble(latVal), let lo = toDouble(lonVal) else { continue }
                let picString = (item["Picture_Link"] as? String)
                    ?? (item["picture_link"] as? String)
                    ?? (item["image"] as? String)
                let pictureURL = picString.flatMap { URL(string: $0) }
                let voiceString = (item["Voice_Link"] as? String)
                    ?? (item["voice_link"] as? String)
                    ?? (item["voice"] as? String)
                let voiceURL = voiceString.flatMap { URL(string: $0) }
                let likesValue: Int? = {
                    if let v = item["LikesCount"] as? Int { return v }
                    if let v = item["likes"] as? Int { return v }
                    if let s = item["LikesCount"] as? String { return Int(s) }
                    if let s = item["likes"] as? String { return Int(s) }
                    return nil
                }()
                let name = (item["Owner"] as? String)
                    ?? (item["owner"] as? String)
                    ?? (item["owner_name"] as? String)
                    ?? (item["client_name"] as? String)
                    ?? (item["full_name"] as? String)
                    ?? (item["username"] as? String)
                let comments: Int? = {
                    if let v = item["comments_count"] as? Int { return v }
                    if let s = item["comments_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract dislikes count similar to likes. Accept a variety of key names.
                let dislikesValue: Int? = {
                    if let v = item["DislikesCount"] as? Int { return v }
                    if let v = item["dislikes"] as? Int { return v }
                    if let v = item["dislike_count"] as? Int { return v }
                    if let v = item["dislikes_count"] as? Int { return v }
                    if let s = item["DislikesCount"] as? String { return Int(s) }
                    if let s = item["dislikes"] as? String { return Int(s) }
                    if let s = item["dislike_count"] as? String { return Int(s) }
                    if let s = item["dislikes_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract shares count from possible keys
                let sharesValue: Int? = {
                    if let v = item["SharesCount"] as? Int { return v }
                    if let v = item["shares"] as? Int { return v }
                    if let v = item["share_count"] as? Int { return v }
                    if let v = item["shares_count"] as? Int { return v }
                    if let s = item["SharesCount"] as? String { return Int(s) }
                    if let s = item["shares"] as? String { return Int(s) }
                    if let s = item["share_count"] as? String { return Int(s) }
                    if let s = item["shares_count"] as? String { return Int(s) }
                    return nil
                }()

                // Extract play count from various key names. Some
                // endpoints may label this as `playbacks`, `views`,
                // `play_count`, `playbacks_count` or `plays`. If none
                // of these keys exist the value defaults to nil and
                // will be treated as zero by the UI.
                let playsValue: Int? = {
                    if let v = item["PlaybacksCount"] as? Int { return v }
                    if let v = item["playbacks"] as? Int { return v }
                    if let v = item["play_count"] as? Int { return v }
                    if let v = item["plays"] as? Int { return v }
                    if let v = item["views"] as? Int { return v }
                    if let v = item["playbacks_count"] as? Int { return v }
                    if let s = item["PlaybacksCount"] as? String { return Int(s) }
                    if let s = item["playbacks"] as? String { return Int(s) }
                    if let s = item["play_count"] as? String { return Int(s) }
                    if let s = item["plays"] as? String { return Int(s) }
                    if let s = item["views"] as? String { return Int(s) }
                    if let s = item["playbacks_count"] as? String { return Int(s) }
                    return nil
                }()
                let ownerIdValue: Int? = {
                    if let v = item["client_id"] as? Int { return v }
                    if let v = item["user_id"] as? Int { return v }
                    if let v = item["owner_id"] as? Int { return v }
                    if let s = item["client_id"] as? String { return Int(s) }
                    if let s = item["user_id"] as? String { return Int(s) }
                    if let s = item["owner_id"] as? String { return Int(s) }
                    return nil
                }()
                loaded.append(Voice(
                    id: vid,
                    title: title,
                    latitude: la,
                    longitude: lo,
                    pictureURL: pictureURL,
                    voiceURL: voiceURL,
                    likes: likesValue,
                    dislikes: dislikesValue,
                    shares: sharesValue,
                    playCount: playsValue,
                    ownerName: name,
                    commentsCount: comments,
                    ownerId: ownerIdValue
                ))
            }
            DispatchQueue.main.async {
                self.voices = loaded
                self.isLoading = false
            }
        } catch {
            DispatchQueue.main.async {
                self.error = error.localizedDescription
                self.isLoading = false
            }
        }
    }
}

/// A single post card that displays the details of a voice. The layout
/// mirrors the provided screenshot: an image fills the card, overlaid
/// with the voice title, owner information, like/comment/share buttons,
/// a location indicator and an audio player with a play button and a
/// record icon. Likes are toggled locally and synced with the server
/// when possible.
struct PostCardView: View {
    var voice: Voice
    @EnvironmentObject private var app: AppState
    @State private var isLiked: Bool = false
    @State private var likeCount: Int
    // Hold the number of comments associated with this post. Defaults
    // to zero when no value is provided by the API. Displaying the
    // comment count aligns the home page with the provided design
    // which shows a comment bubble and corresponding count. Tapping
    // the comment button could in the future present a comments
    // screen; for now it simply toggles a placeholder state.
    @State private var commentCount: Int
    // The playback count tracks how many times this voice has been
    // played. Some API responses label this field as `playbacks`,
    // `play_count`, `views` or `plays`. When absent it defaults to
    // zero. Displaying the playback count gives users an
    // indication of the voice’s reach.
    @State private var playCount: Int

    init(voice: Voice) {
        self.voice = voice
        // Initialise state counts from the voice model. When these fields
        // are nil they default to zero.
        _likeCount = State(initialValue: voice.likes ?? 0)
        // Comments default to zero when nil
        _commentCount = State(initialValue: voice.commentsCount ?? 0)
        _playCount = State(initialValue: voice.playCount ?? 0)
    }

    var body: some View {
        // Limit the size of the post image by constraining the top section height
        // and structuring the card into two vertical sections: a top image
        // container with overlays and a bottom container for location and
        // audio controls. This prevents the picture from overwhelming the
        // screen and more closely matches the provided design.
        // Increase the image height slightly so that the post card takes up
        // more vertical space on the home feed. This change works in
        // conjunction with the taller TabView frame in `PostFeedView` to
        // give each card a more prominent presence.
        let imageHeight: CGFloat = 420
        VStack(spacing: 0) {
            // Top section containing the image, gradient, profile info and
            // action buttons. Constrain its height to imageHeight.
            ZStack(alignment: .topLeading) {
                // Background image or placeholder
                Group {
                    if let url = voice.pictureURL {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .success(let image):
                                image.resizable().scaledToFill()
                            case .failure(_):
                                Color.gray.opacity(0.3)
                            case .empty:
                                Color.gray.opacity(0.3)
                            @unknown default:
                                Color.gray.opacity(0.3)
                            }
                        }
                    } else {
                        Color.gray.opacity(0.3)
                    }
                }
                // Constrain the image group height to the same
                // `imageHeight` as the parent ZStack. Using a fixed
                // height (rather than only a maximum) ensures the
                // view always occupies the same space before and after
                // the async image loads, preventing the card from
                // collapsing or expanding during loading.
                .frame(maxWidth: .infinity)
                .frame(height: imageHeight)
                .clipped()
                // Fade gradient at the bottom for readability
                LinearGradient(
                    gradient: Gradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.8)]),
                    startPoint: .center,
                    endPoint: .bottom
                )
                // Profile picture, title and owner on the top-left
                HStack(spacing: 8) {
                    Image("placeholder-avatar")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text(voice.title)
                            .font(.subheadline)
                            .bold()
                        if let name = voice.ownerName {
                            Text(name)
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.8))
                        }
                    }
                    .foregroundStyle(.white)
                    Spacer()
                }
                .padding(.top, 16)
                .padding(.leading, 16)
                // Vertical action buttons anchored to the bottom trailing edge.
                // Aligning these buttons to the bottom right of the card
                // matches the provided designs where the like, comment and
                // playback counters appear near the lower right of the
                // image. The spacing between buttons is kept minimal to
                // conserve vertical space and ensure the group sits above
                // the audio bar when present.
                VStack(spacing: 18) {
                    Button(action: toggleLike) {
                        VStack(spacing: 4) {
                            Image(systemName: isLiked ? "heart.fill" : "heart")
                                .foregroundColor(isLiked ? .red : .white)
                                .font(.title2)
                            Text(formattedCount(likeCount))
                                .foregroundColor(.white)
                                .font(.footnote)
                        }
                    }
                    // Comment button. In a future iteration this could
                    // present a comments view. For now it simply
                    // increments/decrements the comment count locally to
                    // demonstrate the interaction. A speech bubble icon
                    // communicates the purpose of this button clearly.
                    Button(action: toggleComment) {
                        VStack(spacing: 4) {
                            Image(systemName: "bubble.right")
                                .foregroundColor(.white)
                                .font(.title2)
                            Text(formattedCount(commentCount))
                                .foregroundColor(.white)
                                .font(.footnote)
                        }
                    }
                    // Playback count display. This is not an active
                    // button—tapping it does nothing—but it mirrors
                    // the provided design which shows the number of
                    // playbacks beneath a play icon. To adhere to SwiftUI’s
                    // requirement that interactive controls be obvious,
                    // the button action is left empty.
                    Button(action: {}) {
                        VStack(spacing: 4) {
                            Image(systemName: "play.circle")
                                .foregroundColor(.white)
                                .font(.title2)
                            Text(formattedCount(playCount))
                                .foregroundColor(.white)
                                .font(.footnote)
                        }
                    }
                }
                // Position the stack at the bottom right of the image
                // container. Additional padding keeps it from hugging
                // the edges too closely.
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                .padding(.trailing, 16)
                .padding(.bottom, 16)
            }
            .frame(height: imageHeight)
            .clipped()
            // Bottom section containing location information and audio controls
            VStack(alignment: .leading, spacing: 8) {
                if voice.latitude != 0 || voice.longitude != 0 {
                    HStack(spacing: 4) {
                        Image(systemName: "mappin.and.ellipse")
                            .foregroundColor(.white)
                        Text(String(format: "%.4f, %.4f", voice.latitude, voice.longitude))
                            .foregroundColor(.white)
                            .font(.caption)
                        Spacer()
                    }
                }
                if voice.voiceURL != nil {
                    PostAudioBar(url: voice.voiceURL)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        // Apply a subtle white background and border to match the provided design.
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color.white.opacity(0.25))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.white.opacity(0.4), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    /// Convert a raw integer count into a human friendly string. Values
    /// below 1000 are returned as‑is. Values above 1K are abbreviated to
    /// "K" and above 1M to "M" using one decimal place when needed.
    private func formattedCount(_ count: Int) -> String {
        guard count >= 0 else { return "0" }
        if count >= 1_000_000 {
            let m = Double(count) / 1_000_000
            let rounded = (m * 10).rounded() / 10
            if rounded.truncatingRemainder(dividingBy: 1) == 0 {
                return String(format: "%.0fM", rounded)
            }
            return String(format: "%.1fM", rounded)
        } else if count >= 1_000 {
            let k = Double(count) / 1_000
            let rounded = (k * 10).rounded() / 10
            if rounded.truncatingRemainder(dividingBy: 1) == 0 {
                return String(format: "%.0fK", rounded)
            }
            return String(format: "%.1fK", rounded)
        } else {
            return String(count)
        }
    }

    // The dislike toggle and associated state have been removed. If in
    // future iterations a dislike feature needs to be reintroduced
    // please restore the function and state properties accordingly.


    /// Toggle the like state for this post. When liking or unliking the
    /// voice the local count updates instantly and the API request is
    /// dispatched asynchronously. If no user is authenticated the like
    /// toggles locally without contacting the server.
    private func toggleLike() {
        guard let token = app.token, let clientId = app.currentUserId else {
            // Update local state only
            if isLiked {
                likeCount = max(0, likeCount - 1)
            } else {
                likeCount += 1
            }
            isLiked.toggle()
            return
        }
        if isLiked {
            likeCount = max(0, likeCount - 1)
            isLiked = false
            Task {
                try? await APIClient.shared.unlikeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        } else {
            likeCount += 1
            isLiked = true
            Task {
                try? await APIClient.shared.likeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        }
    }

    /// Increment or decrement the comment count. This stub method
    /// toggles between adding and removing a comment locally. In a
    /// complete application this would present a comment composer or
    /// fetch comments from the server. Including this demonstrates
    /// how the UI updates when the comment button is tapped.
    private func toggleComment() {
        if commentCount > 0 {
            commentCount -= 1
        } else {
            commentCount += 1
        }
    }
}

/// A custom audio bar with play/pause and a stylised waveform along with
/// a record icon. The waveform is represented by a series of capsules
/// whose colour fills as playback progresses. Tapping the play icon
/// toggles audio playback. The record icon is present for visual
/// fidelity but does not perform any action.
struct PostAudioBar: View {
    let url: URL?
    @State private var player: AVPlayer?
    @State private var isPlaying: Bool = false
    @State private var currentTime: Double = 0
    @State private var duration: Double = 1
    // Update twice per second
    private let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    private let barCount: Int = 30

    // Compute playback progress between 0 and 1
    private var progress: Double {
        guard duration > 0 else { return 0 }
        return min(max(currentTime / duration, 0), 1)
    }

    var body: some View {
        HStack(spacing: 12) {
            Button(action: toggle) {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.blue)
            }
            HStack(spacing: 2) {
                ForEach(0..<barCount, id: \.self) { index in
                    Capsule()
                        .fill(Double(index) / Double(barCount) < progress ? Color.blue : Color.white.opacity(0.6))
                        .frame(width: 3, height: heightForIndex(index))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: 24)
            // Mic button for decorative purposes
            Button(action: {}) {
                Image(systemName: "mic.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.red)
            }
        }
        .padding(12)
        // Remove the separate background on the audio bar so that it blends
        // seamlessly with the rest of the post card. This makes the
        // bottom portion of the card feel like one continuous container,
        // preventing the appearance of separate sections.
        .onAppear {
            if let url = url {
                player = AVPlayer(url: url)
                if let item = player?.currentItem {
                    let d = item.asset.duration.seconds
                    if d.isFinite && d > 0 {
                        duration = d
                    }
                }
            }
        }
        .onReceive(timer) { _ in
            guard let player = player,
                  let currentItem = player.currentItem else { return }
            if currentItem.duration.seconds.isFinite && currentItem.duration.seconds > 0 {
                duration = currentItem.duration.seconds
                currentTime = player.currentTime().seconds
            }
        }
    }

    /// Toggle playback for the underlying AVPlayer. When playing the
    /// waveform animates as progress increases.
    private func toggle() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    /// Compute a pseudo‑waveform height for the given index. This uses a
    /// sinusoidal function to vary the heights, giving a pleasing
    /// alternation reminiscent of a waveform.
    private func heightForIndex(_ index: Int) -> CGFloat {
        // Produce values between 6 and 24 points
        let amplitude: Double = 9
        let base: Double = 15
        let value = sin(Double(index) / Double(barCount) * .pi) * amplitude + base
        return CGFloat(value)
    }
}
