
import Foundation

enum Validators {
    static func isValidEmail(_ s: String) -> Bool {
        let pattern = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        return s.range(of: pattern, options: [.regularExpression, .caseInsensitive]) != nil
    }
    static func isValidPhone(_ s: String) -> Bool {
        let pattern = #"^[0-9+\-() ]{6,}$"#
        return s.range(of: pattern, options: [.regularExpression]) != nil
    }
    static func isStrongPassword(_ s: String) -> Bool {
        s.count >= 6
    }
}
