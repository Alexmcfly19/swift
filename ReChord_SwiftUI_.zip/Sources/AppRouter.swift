
import SwiftUI
import Combine

final class AppRouter: ObservableObject {
    @Published var showSplash: Bool = true
    func endSplash(after seconds: Double = 3.0) {
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
            self?.showSplash = false
        }
    }
}
