
import SwiftUI

struct RootView: View {
    @EnvironmentObject var router: AppRouter
    @EnvironmentObject var auth: AuthViewModel

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            switch auth.state {
            case .splash:
                SplashView()
                    .onAppear { router.endSplash(after: 3); DispatchQueue.main.asyncAfter(deadline: .now() + 3) { auth.goToLogin() } }
            case .login:
                LoginView()
            case .register:
                RegistrationView()
            case .otp(let email):
                OTPView(email: email)
            case .home:
                HomeView()
            }
        }
    }
}
