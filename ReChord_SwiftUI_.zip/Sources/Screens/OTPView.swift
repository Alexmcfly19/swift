
import SwiftUI

struct OTPView: View {
    @EnvironmentObject var auth: AuthViewModel
    let email: String
    @State private var code: String = ""

    var body: some View {
        VStack(spacing: 24) {
            Spacer().frame(height: 36)
            Text("ReChord").font(.system(size: 44, weight: .bold)).foregroundColor(.white)

            Text("Please enter 6 digit number we sent to you")
                .foregroundColor(.white.opacity(0.9))
                .padding(.top, 8)

            OTPCells(code: $code, length: 6)
                .padding(.top, 8)

            if let error = auth.error { Text(error).foregroundColor(.red) }

            PrimaryButton(title: auth.isLoading ? "Verifying..." : "Continue") {
                Task { await auth.verifyOTP(email: email, code: code) }
            }.disabled(code.count != 6 || auth.isLoading)

            Button(action: {}, label: {
                Text("Didn't get the code, we can ").foregroundColor(.white.opacity(0.8)) +
                Text("resend it").underline().foregroundColor(.white)
            })
            .padding(.top, 12)

            Spacer()
        }
        .padding(.horizontal, 24)
        .background(Theme.background.ignoresSafeArea())
    }
}
