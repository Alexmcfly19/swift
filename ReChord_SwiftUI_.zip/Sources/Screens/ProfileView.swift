
import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var auth: AuthViewModel
    @State private var phone: String = "+44 234 11 2455"
    @State private var email: String = "p.rout@gmail.com"
    @State private var website: String = "rout.philipaa"
    @State private var languages: [String] = ["English", "Latin"]
    @State private var isPrivate: Bool = true
    @State private var locationPermission: Bool = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header
                aboutMe
                contactOptions
                languagePref
                toggles
            }
            .padding()
        }
        .background(
            Image(uiImage: UIImage(named: "profile-bg") ?? UIImage())
                .resizable()
                .scaledToFill()
                .opacity(0.2)
                .overlay(Theme.background)
                .ignoresSafeArea()
        )
        .navigationTitle("ReChord")
    }

    var header: some View {
        RoundedRectangle(cornerRadius: 16)
            .fill(.ultraThinMaterial)
            .overlay(
                HStack(alignment: .center, spacing: 12) {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable().frame(width: 64, height: 64).foregroundColor(.white)
                    VStack(spacing: 8) {
                        HStack {
                            Image(systemName: "person")
                            TextField("Full Name", text: .constant("Philipa Rout"))
                        }
                        .padding(10).background(Theme.fieldBG).cornerRadius(12).foregroundColor(.white)

                        HStack {
                            Image(systemName: "at")
                            TextField("@username", text: .constant("Philirout"))
                        }
                        .padding(10).background(Theme.fieldBG).cornerRadius(12).foregroundColor(.white)
                    }
                }.padding()
            )
            .frame(maxWidth: .infinity, minHeight: 120)
    }

    var aboutMe: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("About me").foregroundColor(.white).font(.headline)
            RoundedRectangle(cornerRadius: 16).fill(Theme.card)
                .overlay(
                    HStack {
                        Circle().fill(Color.white.opacity(0.15)).frame(width: 40, height: 40).overlay(Image(systemName: "play.fill").foregroundColor(.white))
                        RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.2)).frame(height: 16).overlay(
                            HStack(spacing: 3) { ForEach(0..<24, id: \.self) { _ in Capsule().fill(Color.white.opacity(0.6)).frame(width: 4, height: .random(in: 4...16)) } }
                        )
                        Spacer()
                        Circle().fill(Color.white.opacity(0.15)).frame(width: 40, height: 40).overlay(Image(systemName: "mic.fill").foregroundColor(.red))
                    }.padding()
                )
                .frame(height: 68)
        }
    }

    var contactOptions: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Contact Options").foregroundColor(.white).font(.headline)
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "phone")
                    TextField("Phone", text: $phone)
                }.padding(12).background(Theme.fieldBG).cornerRadius(12).foregroundColor(.white)

                HStack {
                    Image(systemName: "envelope")
                    TextField("Email", text: $email)
                }.padding(12).background(Theme.fieldBG).cornerRadius(12).foregroundColor(.white)

                HStack {
                    Image(systemName: "link")
                    TextField("Website", text: $website)
                }.padding(12).background(Theme.fieldBG).cornerRadius(12).foregroundColor(.white)
            }
        }
    }

    var languagePref: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Language Preference").foregroundColor(.white).font(.headline)
            WrapTags(tags: $languages)
                .padding(.vertical, 6)
        }
    }

    var toggles: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("Private Account", isOn: $isPrivate)
                .toggleStyle(SwitchToggleStyle(tint: Theme.brand))
                .foregroundColor(.white)
            Toggle("Location Permission", isOn: $locationPermission)
                .toggleStyle(SwitchToggleStyle(tint: Theme.brand))
                .foregroundColor(.white)
            Button("Log out") { auth.logout() }.foregroundColor(.red)
        }
        .padding(.top, 8)
    }
}

struct WrapTags: View {
    @Binding var tags: [String]
    var body: some View {
        FlowLayout(alignment: .leading, spacing: 8) {
            ForEach(tags, id: \.self) { tag in
                HStack(spacing: 6) {
                    Text(tag)
                    Image(systemName: "xmark")
                        .onTapGesture { if let idx = tags.firstIndex(of: tag) { tags.remove(at: idx) } }
                }
                .padding(.vertical, 6).padding(.horizontal, 10)
                .background(RoundedRectangle(cornerRadius: 12).fill(Theme.fieldBG))
                .foregroundColor(.white)
            }
        }
    }
}

struct FlowLayout<Content: View>: View {
    let alignment: HorizontalAlignment
    let spacing: CGFloat
    @ViewBuilder var content: () -> Content

    init(alignment: HorizontalAlignment = .leading, spacing: CGFloat = 8, @ViewBuilder content: @escaping () -> Content) {
        self.alignment = alignment
        self.spacing = spacing
        self.content = content
    }

    var body: some View {
        GeometryReader { geo in
            self.generateContent(in: geo)
        }
        .frame(minHeight: 10)
    }

    func generateContent(in geo: GeometryProxy) -> some View {
        var width = CGFloat.zero
        var rows: [CGFloat] = [0]
        return ZStack(alignment: .topLeading) {
            content()
                .alignmentGuide(.leading) { d in
                    if (abs(width - d.width) > geo.size.width) {
                        width = 0
                        rows.append(d.height + spacing)
                    }
                    let result = width
                    if tag { width -= d.width + spacing } else { width += d.width + spacing }
                    return result
                }
                .alignmentGuide(.top) { d in
                    return -rows.dropLast().reduce(0, +)
                }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var tag: Bool { false }
}
