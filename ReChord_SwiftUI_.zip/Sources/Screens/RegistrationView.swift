
import SwiftUI

struct RegistrationView: View {
    @EnvironmentObject var auth: AuthViewModel
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var fullName: String = ""
    @State private var username: String = ""

    var isValid: Bool {
        Validators.isValidEmail(email) && Validators.isStrongPassword(password) && !fullName.isEmpty && !username.isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer().frame(height: 36)
                Text("ReChord").font(.system(size: 44, weight: .bold)).foregroundColor(.white)
                Text("welcome").font(.title3).foregroundColor(.white.opacity(0.9))
                VStack(spacing: 16) {
                    TextField("Please Enter Your Email", text: $email)
                        .textFieldIcon("envelope").foregroundColor(.white)
                    SecureField("Enter your Password", text: $password)
                        .textFieldIcon("lock").foregroundColor(.white)
                    TextField("Full Name", text: $fullName)
                        .textFieldIcon("person").foregroundColor(.white)
                    TextField("Choose a Username for Yourself", text: $username)
                        .textFieldIcon("at").foregroundColor(.white)

                    if let error = auth.error { Text(error).foregroundColor(.red) }

                    PrimaryButton(title: auth.isLoading ? "Creating..." : "Continue") {
                        Task { await auth.register(email: email, password: password, fullName: fullName, username: username) }
                    }
                    .disabled(!isValid || auth.isLoading)
                }
                .padding(.horizontal, 24)

                Button("Back to Login") { auth.goToLogin() }.foregroundColor(.white.opacity(0.9))
                Spacer()
            }
        }
        .background(Theme.background.ignoresSafeArea())
    }
}
