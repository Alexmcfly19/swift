
import Foundation
import SwiftUI

@MainActor
final class AuthViewModel: ObservableObject {
    enum ScreenState {
        case splash
        case login
        case register
        case otp(email: String)
        case home
    }
    @Published var state: ScreenState = .splash
    @Published var isLoading = false
    @Published var error: String? = nil

    @Published var currentUser: User? = nil
    @Published var token: String? = nil

    private let service: AuthServicing

    init(service: AuthServicing) {
        self.service = service
    }

    func start() {
        state = .splash
    }

    func goToLogin() { state = .login }
    func goToRegister() { state = .register }

    func register(email: String, password: String, fullName: String, username: String) async {
        isLoading = true; error = nil
        do {
            let res = try await service.register(email: email, password: password, fullName: fullName, username: username)
            if res.success {
                state = .otp(email: res.email)
            }
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func verifyOTP(email: String, code: String) async {
        isLoading = true; error = nil
        do {
            let res = try await service.verifyOTP(email: email, code: code)
            if res.verified {
                // Back to login
                state = .login
            }
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func login(identifier: String, password: String) async {
        isLoading = true; error = nil
        do {
            let res = try await service.login(identifier: identifier, password: password)
            self.token = res.token
            self.currentUser = res.user
            self.state = .home
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func logout() {
        token = nil
        currentUser = nil
        state = .login
    }
}
