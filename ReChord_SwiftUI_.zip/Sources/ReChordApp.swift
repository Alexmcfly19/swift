
import SwiftUI

@main
struct ReChordApp: App {
    @StateObject private var router = AppRouter()
    @StateObject private var auth = AuthViewModel(service: AuthService())

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(router)
                .environmentObject(auth)
        }
    }
}
