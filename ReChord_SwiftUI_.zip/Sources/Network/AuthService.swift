
import Foundation

protocol AuthServicing {
    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse
    func verifyOTP(email: String, code: String) async throws -> VerifyResponse
    func login(identifier: String, password: String) async throws -> LoginResponse
}

final class AuthService: AuthServicing {
    // Switch to false when hooking up real APIClient
    var useMock = true
    private let client = APIClient()
    private let mock = MockBackend()

    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse {
        if useMock {
            return try await mock.register(email: email, password: password, fullName: fullName, username: username)
        } else {
            struct Body: Encodable { let email, password, fullName, username: String }
            return try await client.postJSON("/auth/register", body: Body(email: email, password: password, fullName: fullName, username: username), type: RegisterResponse.self)
        }
    }

    func verifyOTP(email: String, code: String) async throws -> VerifyResponse {
        if useMock {
            return try await mock.verifyOTP(email: email, code: code)
        } else {
            struct Body: Encodable { let email, code: String }
            return try await client.postJSON("/auth/verify-otp", body: Body(email: email, code: code), type: VerifyResponse.self)
        }
    }

    func login(identifier: String, password: String) async throws -> LoginResponse {
        if useMock {
            return try await mock.login(identifier: identifier, password: password)
        } else {
            struct Body: Encodable { let identifier, password: String }
            return try await client.postJSON("/auth/login", body: Body(identifier: identifier, password: password), type: LoginResponse.self)
        }
    }
}

// MARK: - Mock Backend

actor MockBackend {
    private var pendingCodes: [String: String] = [:] // email -> code
    private var users: [String: String] = [:] // email -> password
    private var usernames: Set<String> = []

    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse {
        guard Validators.isValidEmail(email) else { throw APIError(message: "Invalid email") }
        guard !usernames.contains(username) else { throw APIError(message: "Username already taken") }
        users[email] = password
        usernames.insert(username)

        // generate OTP
        let code = String(format: "%06d", Int.random(in: 0...999_999))
        pendingCodes[email] = code
        print("[Mock OTP for \(email)]: \(code)")
        return RegisterResponse(success: true, message: "OTP sent to email", email: email)
    }

    func verifyOTP(email: String, code: String) async throws -> VerifyResponse {
        guard pendingCodes[email] == code else { throw APIError(message: "Invalid code") }
        pendingCodes[email] = nil
        return VerifyResponse(verified: true, message: "Verified")
    }

    func login(identifier: String, password: String) async throws -> LoginResponse {
        if let stored = users[identifier], stored == password {
            return LoginResponse(token: UUID().uuidString, user: User(id: UUID().uuidString, fullName: "User", username: "user", email: identifier))
        }
        // also allow username == "demo", password "demo"
        if identifier.lowercased() == "demo", password == "demo" {
            return LoginResponse(token: UUID().uuidString, user: User(id: UUID().uuidString, fullName: "Demo User", username: "demo", email: "demo@rechord.app"))
        }
        throw APIError(message: "Invalid credentials")
    }
}
