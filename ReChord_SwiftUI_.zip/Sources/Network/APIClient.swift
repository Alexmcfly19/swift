
import Foundation

struct APIError: Error, LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

final class APIClient {
    var baseURL: URL
    var session: URLSession

    init(baseURL: URL = URL(string: "https://api.yourbackend.com")!,
         session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    func postJSON<T: Encodable, U: Decodable>(_ path: String, body: T, type: U.Type) async throws -> U {
        var req = URLRequest(url: baseURL.appendingPathComponent(path))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONEncoder().encode(body)

        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError(message: "Network error")
        }
        return try JSONDecoder().decode(U.self, from: data)
    }
}
