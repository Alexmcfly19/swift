
import SwiftUI

struct OTPCells: View {
    @Binding var code: String
    let length: Int

    var body: some View {
        HStack(spacing: 12) {
            ForEach(0..<length, id: \.self) { i in
                ZStack {
                    RoundedRectangle(cornerRadius: 10).fill(Theme.fieldBG)
                    Text(char(at: i)).font(.title).foregroundColor(.white)
                }
                .frame(width: 44, height: 56)
            }
        }
        .overlay(
            TextField("", text: $code)
                .keyboardType(.numberPad)
                .textContentType(.oneTimeCode)
                .foregroundColor(.clear)
                .accentColor(.clear)
                .disableAutocorrection(true)
                .background(Color.clear)
                .frame(width: 0, height: 0)
        )
        .contentShape(Rectangle())
        .onTapGesture {
            // bring keyboard by focusing hidden field? SwiftUI 5 focusless workaround
        }
    }

    private func char(at index: Int) -> String {
        if index < code.count {
            let idx = code.index(code.startIndex, offsetBy: index)
            return String(code[idx])
        } else { return "" }
    }
}
