
import SwiftUI

struct PrimaryButton: View {
    var title: String
    var action: () -> Void
    var disabled: Bool = false

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(disabled ? Color.gray : Theme.brand)
                .cornerRadius(12)
        }
        .disabled(disabled)
    }
}
