
import SwiftUI

struct TextFieldIcon: ViewModifier {
    let systemName: String
    func body(content: Content) -> some View {
        HStack {
            Image(systemName: systemName).foregroundColor(.white.opacity(0.7))
            content
        }
        .padding()
        .background(Theme.fieldBG)
        .cornerRadius(12)
    }
}

extension View {
    func textFieldIcon(_ name: String) -> some View {
        modifier(TextFieldIcon(systemName: name))
    }
}
