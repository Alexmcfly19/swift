import SwiftUI
import AVFoundation

/// The main container view presented after authentication. This view
/// manages the bottom navigation bar and orchestrates presentation of
/// the feed, explore map, notifications, profile and the recording
/// overlay. A custom tab bar is implemented instead of relying on
/// ``TabView`` so that the central record button can respond to
/// repeated taps and display different icons and colours based on
/// recording state.
struct HomeView: View {
    @EnvironmentObject var app: AppState
    /// Shared recorder manager that controls audio capture, playback
    /// and uploading. Injected into subviews via the environment.
    @StateObject private var recorder = RecorderManager()
    /// Currently selected tab index. Values correspond to: 0 = Home
    /// feed, 1 = Explore, 3 = Notifications, 4 = Profile. The record
    /// button sits in the middle and does not have a dedicated tab
    /// page.
    @State private var selectedTab: Int = 0
    /// Flag controlling presentation of the metadata overlay. When
    /// `true` the ``AddVoiceMetadataView`` is shown on top of the
    /// current content. The overlay is automatically dismissed after
    /// sending a voice or when the user navigates away.
    @State private var showOverlay: Bool = false

    var body: some View {
        ZStack(alignment: .bottom) {
            // Main content driven by the selected tab. The record tab
            // (index 2) does not render content; instead tapping the
            // record button triggers recording actions.
            Group {
                switch selectedTab {
                case 0:
                    PostFeedView()
                case 1:
                    FeedView()
                case 3:
                    NotificationView()
                case 4:
                    ProfileView()
                default:
                    PostFeedView()
                }
            }
            // Extend content behind the safe area to match the design.
            .ignoresSafeArea(edges: .bottom)
            // Overlay for metadata entry. This sits above the content
            // and below the navigation bar so that the bar remains
            // visible while entering details.
            if showOverlay {
                // Present the metadata overlay above the main content but
                // below the navigation bar. By assigning a lower zIndex
                // than the tab bar the overlay slides up from the bottom
                // without hiding the bar, preserving the liquid glass
                // effect while the record icon changes state.
                AddVoiceMetadataView()
                    .environmentObject(app)
                    .environmentObject(recorder)
                    .transition(.move(edge: .bottom))
                    .zIndex(0)
            }
            // Custom bottom navigation bar. The record button in the
            // centre uses the recorder state to adjust its icon and
            // colour.
            VStack(spacing: 0) {
                Divider().background(Color.clear)
                HStack {
                    tabBarButton(icon: "house.fill", index: 0)
                    Spacer()
                    tabBarButton(icon: "globe", index: 1)
                    Spacer()
                    recordButton()
                    Spacer()
                    tabBarButton(icon: "at", index: 3)
                    Spacer()
                    tabBarButton(icon: "person.crop.circle", index: 4)
                }
                .padding(.horizontal, 24)
                .frame(height: 60)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .padding(.horizontal)
            }
            // Ensure the tab bar always sits above the overlay by
            // explicitly assigning a higher zIndex. Without this the
            // overlay would obscure the bar when presented.
            .zIndex(1)
        }
        // Provide the recorder manager to children via environment.
        .environmentObject(recorder)
    }

    /// Construct a standard tab bar button. When tapped the
    /// ``selectedTab`` is updated. The icon tint changes to indicate
    /// selection. Tabs outside of the record button use this helper.
    private func tabBarButton(icon: String, index: Int) -> some View {
        Button {
            selectedTab = index
            // Dismiss the overlay if navigating away from record
            if showOverlay { showOverlay = false }
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.title2)
                // Hide text labels to match the provided design; icons
                // alone serve as tab indicators.
            }
        }
        .foregroundColor(selectedTab == index ? Color(hex: 0x0F4D8A) : .primary)
    }

    /// Build the central record button. The appearance and behaviour
    /// change depending on the ``RecorderManager.recordingState``. When
    /// idle a microphone icon is shown. During recording the icon
    /// becomes a stop square and the colour changes to red. After
    /// recording the button turns green with a paper plane icon to
    /// indicate sending. Tapping cycles through these actions.
    private func recordButton() -> some View {
        Button {
            handleRecordTap()
        } label: {
            ZStack {
                Circle()
                    .fill(colorForState())
                    .frame(width: 64, height: 64)
                    .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
                switch recorder.recordingState {
                case .recording:
                    // Display a white square to indicate stop
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(Color.white)
                        .frame(width: 28, height: 28)
                case .recorded:
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                case .idle:
                    Image(systemName: "mic.fill")
                        .font(.system(size: 32))
                        .foregroundColor(.white)
                }
            }
        }
        // Lift the record button slightly above the bar to match the design
        .offset(y: -20)
    }

    /// Determine the background colour of the record button based on
    /// the current recording state.
    private func colorForState() -> Color {
        switch recorder.recordingState {
        case .idle:
            return Color(hex: 0x0F4D8A)
        case .recording:
            return .red
        case .recorded:
            return .green
        }
    }

    /// Handle taps on the record button. The logic mirrors the state
    /// transitions of ``RecorderManager``:
    /// - When idle a new recording begins and the metadata overlay is
    ///   presented.
    /// - When recording the recording stops.
    /// - When recorded the voice and metadata are sent to the server.
    private func handleRecordTap() {
        switch recorder.recordingState {
        case .idle:
            // Start recording and show the overlay
            showOverlay = true
            recorder.startRecording()
        case .recording:
            // Stop the recording
            recorder.stopRecording()
        case .recorded:
            // Send the voice. Dismiss the overlay on success.
            Task {
                await recorder.sendVoice(app: app)
                showOverlay = false
                // Return to the home feed after sending
                selectedTab = 0
            }
        }
    }
}

// Preview support
#if DEBUG
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        let appState = AppState.shared
        appState.isAuthenticated = true
        return HomeView()
            .environmentObject(appState)
    }
}
#endif