import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            Image("SplashBackground").resizable().scaledToFill().ignoresSafeArea()
            VStack(spacing: 12) {
                Image("ReChordLogo").resizable().scaledToFit().frame(width: 140)
                Text("ReChord").font(.system(size: 42, weight: .bold)).foregroundStyle(.white)
            }
        }
    }
}
