import SwiftUI

struct LoginView: View {
    @EnvironmentObject var session: AppSession
    let onRegisterTap: () -> Void
    @State private var email = ""
    @State private var password = ""
    @State private var error: String?
    @State private var loading = false

    var body: some View {
        ZStack {
            Image("EarthBackground").resizable().scaledToFill().ignoresSafeArea()
            VStack(spacing: 16) {
                Spacer()
                Image("ReChordLogo").resizable().scaledToFit().frame(width: 180)
                Text("ReChord").font(.largeTitle).foregroundStyle(.white).bold()
                VStack(spacing: 12) {
                    RoundedTextField("Enter your email or phone number", text: $email, isSecure: false)
                    RoundedTextField("Please enter your Password", text: $password, isSecure: true)
                }.padding(.horizontal, 24)
                Button(action: login) {
                    Text(loading ? "..." : "Continue").font(.headline).frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white).cornerRadius(12)
                }.padding(.horizontal, 24).disabled(loading)
                HStack {
                    Text("Don't have an account,")
                    Button("sign up") { onRegisterTap() }
                }.foregroundStyle(.white.opacity(0.9))
                Spacer()
            }
        }
        .alert("Error", isPresented: Binding(get: { error != nil }, set: { _ in error = nil })) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(error ?? "")
        }
    }

    func login() {
        loading = true
        Task {
            do {
                let (token, client, isActive) = try await APIClient.shared.login(email: email, password: password)
                session.token = token
                session.currentUser = client
                if isActive {
                    session.goToMain()
                } else {
                    // ask backend to (re)send otp and go to otp screen using the email from login
                    let otp = try? await APIClient.shared.resendActivation(email: email)
                    session.requireOTP(email: email, expected: otp)
                }
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }
}

struct RoundedTextField: View {
    let placeholder: String
    @Binding var text: String
    var isSecure: Bool = false
    var body: some View {
        Group {
            if isSecure {
                SecureField(placeholder, text: $text)
                    .textContentType(.password)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            } else {
                TextField(placeholder, text: $text)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.emailAddress)
                    .autocorrectionDisabled()
            }
        }
        .padding()
        .background(.white.opacity(0.9))
        .cornerRadius(12)
    }
}
