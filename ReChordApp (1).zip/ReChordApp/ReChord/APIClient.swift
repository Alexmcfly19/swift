import Foundation
import UIKit

struct APIClient {
    static let shared = APIClient()
    let base = URL(string: "https://be.rechord.life/public/api")!

    func postForm(_ path: String, fields: [String:String], token: String? = nil) async throws -> [String:Any] {
        var request = URLRequest(url: base.appendingPathComponent(path))
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        if let token { request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        var body = Data()
        for (k,v) in fields {
            body.appendString("--\(boundary)\r\n")
            body.appendString("Content-Disposition: form-data; name=\"\(k)\"\r\n\r\n")
            body.appendString("\(v)\r\n")
        }
        body.appendString("--\(boundary)--\r\n")
        request.httpBody = body

        let (data, resp) = try await URLSession.shared.data(for: request)
        guard let http = resp as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        if http.statusCode >= 400 {
            throw NSError(domain: "rechord", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: String(data: data, encoding: .utf8) ?? "Server error"])
        }
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String:Any] ?? [:]
        return json
    }

    func upload(_ path: String, fields: [String:String], fileField: String, fileName: String, mime: String, data: Data, token: String) async throws -> [String:Any] {
        var request = URLRequest(url: base.appendingPathComponent(path))
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        var body = Data()
        for (k,v) in fields {
            body.appendString("--\(boundary)\r\n")
            body.appendString("Content-Disposition: form-data; name=\"\(k)\"\r\n\r\n")
            body.appendString("\(v)\r\n")
        }
        body.appendString("--\(boundary)\r\n")
        body.appendString("Content-Disposition: form-data; name=\"\(fileField)\"; filename=\"\(fileName)\"\r\n")
        body.appendString("Content-Type: \(mime)\r\n\r\n")
        body.append(data)
        body.appendString("\r\n--\(boundary)--\r\n")
        request.httpBody = body

        let (data, resp) = try await URLSession.shared.data(for: request)
        guard let http = resp as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        if http.statusCode >= 400 {
            throw NSError(domain: "rechord", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: String(data: data, encoding: .utf8) ?? "Server error"])
        }
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String:Any] ?? [:]
        return json
    }

    // MARK: Endpoints
    func register(email: String, password: String, fullName: String, username: String) async throws -> (email: String, otp: String?) {
        let json = try await postForm("clients", fields: [
            "email": email, "password": password, "full_name": fullName, "username": username
        ])
        let otp = (json["otp"] as? String) ?? (json["code"] as? String)
        return (email, otp)
    }
    func login(email: String, password: String) async throws -> (token: String, client: Client, isActive: Bool) {
        let json = try await postForm("clients/login", fields: ["email": email, "password": password])
        let token = (json["token"] as? String) ?? (json["access_token"] as? String) ?? ""
        var client = Client()
        if let c = json["client"] as? [String:Any] {
            client.id = (c["id"] as? Int) ?? Int((c["id"] as? String) ?? "")
            client.email = c["email"] as? String
            client.username = c["username"] as? String
            client.full_name = c["full_name"] as? String
            client.is_active = (c["is_active"] as? Bool) ?? ((c["is_active"] as? Int).map{ $0 != 0 })
        }
        let isActive = client.is_active ?? ((json["is_active"] as? Bool) ?? false)
        return (token, client, isActive)
    }
    func resendActivation(email: String) async throws -> String? {
        let json = try await postForm("clients/activation", fields: ["email": email])
        return (json["otp"] as? String) ?? (json["code"] as? String)
    }
    func activate(email: String) async throws {
        _ = try await postForm("clients/activate", fields: ["email": email])
    }
    func updateClient(id: Int, fields: [String:String], token: String) async throws {
        _ = try await postForm("clients/\(id)", fields: fields, token: token)
    }
    func uploadAvatar(clientId: Int, imageData: Data, token: String) async throws {
        _ = try await upload("avatar", fields: ["client_id": String(clientId)], fileField: "avatar", fileName: "avatar.jpg", mime: "image/jpeg", data: imageData, token: token)
    }
    func uploadVoice(audioData: Data, token: String) async throws {
        _ = try await upload("voiceupload", fields: [:], fileField: "voice", fileName: "voice.m4a", mime: "audio/m4a", data: audioData, token: token)
    }
}

fileprivate extension Data {
    mutating func appendString(_ s: String) { self.append(s.data(using: .utf8)!) }
}
