import Foundation
import SwiftUI

final class AppSession: ObservableObject {
    enum Route {
        case splash, auth, otp(email: String, expected: String?), main
    }
    @Published var route: Route = .splash
    @Published var token: String? {
        didSet { KeychainService.shared.token = token }
    }
    @Published var currentUser: Client?

    func start() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { // 3s splash
            self.route = .auth
        }
        self.token = KeychainService.shared.token
    }

    func goToMain() {
        DispatchQueue.main.async { self.route = .main }
    }

    func requireOTP(email: String, expected: String?) {
        DispatchQueue.main.async { self.route = .otp(email: email, expected: expected) }
    }
}

struct Client: Codable, Identifiable {
    var id: Int?
    var email: String?
    var full_name: String?
    var username: String?
    var is_active: Bool?
}
