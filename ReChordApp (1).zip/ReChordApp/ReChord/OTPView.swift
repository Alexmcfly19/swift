import SwiftUI

struct OTPView: View {
    @EnvironmentObject var session: AppSession
    var email: String
    var expectedServerOTP: String?
    @State private var digits: [String] = Array(repeating: "", count: 6)
    @State private var error: String?
    @State private var loading = false
    @FocusState private var focusIndex: Int?

    var body: some View {
        ZStack {
            Image("EarthBackground").resizable().scaledToFill().ignoresSafeArea()
            VStack(spacing: 24) {
                Image("ReChordLogo").resizable().scaledToFit().frame(width: 150)
                Text("Please enter 6 digit number we sent to you")
                    .foregroundStyle(.white).padding(.horizontal)
                HStack(spacing: 12) {
                    ForEach(0..<6, id: \.self) { i in
                        OTPDigitField(text: $digits[i])
                            .focused($focusIndex, equals: i)
                            .onChange(of: digits[i]) { value in
                                if value.count == 1 { focusIndex = min(i+1, 5) }
                            }
                    }
                }
                Button(action: verify) {
                    Text(loading ? "..." : "Continue").font(.headline).frame(maxWidth: .infinity)
                        .padding().background(Color.blue).foregroundColor(.white).cornerRadius(12)
                }.padding(.horizontal, 24).disabled(loading)
                Button("Didn't get the code? resend it") { resend() }.foregroundStyle(.white.opacity(0.9))
                if let expectedServerOTP {
                    Text("DEBUG (server OTP): \(expectedServerOTP)").font(.footnote).foregroundStyle(.white.opacity(0.6))
                }
                Spacer()
            }.padding(.top, 60)
        }
        .onAppear { focusIndex = 0 }
        .alert("Error", isPresented: Binding(get: { error != nil }, set: { _ in error = nil })) {
            Button("OK", role: .cancel) { }
        } message: { Text(error ?? "") }
    }

    func verify() {
        let code = digits.joined()
        guard code.count == 6 else { error = "Please enter the 6 digit code."; return }
        loading = true
        Task {
            do {
                // If server sent OTP and it does not match, keep user here
                if let expected = expectedServerOTP, expected != code {
                    throw NSError(domain: "rechord", code: 0, userInfo: [NSLocalizedDescriptionKey: "Incorrect code."])
                }
                try await APIClient.shared.activate(email: email)
                session.goToMain()
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }

    func resend() {
        Task {
            do {
                let newOtp = try await APIClient.shared.resendActivation(email: email)
                // Ideally you'd show a toast; we tack it on the screen for now
                print("Resent OTP: \(newOtp ?? "-")")
            } catch { self.error = error.localizedDescription }
        }
    }
}

struct OTPDigitField: View {
    @Binding var text: String
    var body: some View {
        TextField("", text: $text)
            .keyboardType(.numberPad)
            .frame(width: 44, height: 44)
            .multilineTextAlignment(.center)
            .background(.white)
            .cornerRadius(8)
            .onChange(of: text) { newValue in
                text = String(newValue.prefix(1))
            }
    }
}
