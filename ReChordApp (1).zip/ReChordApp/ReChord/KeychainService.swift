import Foundation

class KeychainService {
    static let shared = KeychainService()
    private let tokenKey = "rechord.token"
    var token: String? {
        get { UserDefaults.standard.string(forKey: tokenKey) }
        set {
            if let v = newValue { UserDefaults.standard.set(v, forKey: tokenKey) }
            else { UserDefaults.standard.removeObject(forKey: tokenKey) }
        }
    }
}
