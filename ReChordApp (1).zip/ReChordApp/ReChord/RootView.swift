import SwiftUI

struct RootView: View {
    @EnvironmentObject var session: AppSession
    var body: some View {
        Group {
            switch session.route {
            case .splash:
                SplashView()
            case .auth:
                AuthSwitcher()
            case .otp(let email, let expected):
                OTPView(email: email, expectedServerOTP: expected)
            case .main:
                HomeView()
            }
        }
        .onAppear { session.start() }
    }
}

struct AuthSwitcher: View {
    @State private var showRegister = false
    var body: some View {
        if showRegister {
            RegisterView(onDone: { showRegister = false })
        } else {
            LoginView(onRegisterTap: { showRegister = true })
        }
    }
}
