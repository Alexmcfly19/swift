import SwiftUI

struct RegisterView: View {
    @EnvironmentObject var session: AppSession
    let onDone: () -> Void
    @State private var email = ""
    @State private var password = ""
    @State private var fullName = ""
    @State private var username = ""
    @State private var error: String?
    @State private var loading = false

    var body: some View {
        ZStack {
            Image("EarthBackground").resizable().scaledToFill().ignoresSafeArea()
            VStack(spacing: 16) {
                Spacer()
                Image("ReChordLogo").resizable().scaledToFit().frame(width: 160)
                Text("welcome").font(.title).foregroundStyle(.white.opacity(0.9))
                VStack(spacing: 10) {
                    RoundedTextField("Please Enter Your Email", text: $email)
                    RoundedTextField("Enter your Password", text: $password, isSecure: true)
                    RoundedTextField("Full Name", text: $fullName)
                    RoundedTextField("Choose a Username for Yourself", text: $username)
                }.padding(.horizontal, 24)
                Button(action: register) {
                    Text(loading ? "..." : "Continue").font(.headline).frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white).cornerRadius(12)
                }.padding(.horizontal, 24).disabled(loading)
                Button("Back to login", action: onDone).foregroundStyle(.white.opacity(0.9))
                Spacer(minLength: 20)
            }
        }
        .alert("Error", isPresented: Binding(get: { error != nil }, set: { _ in error = nil })) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(error ?? "")
        }
    }

    func register() {
        loading = true
        Task {
            do {
                let (email, otp) = try await APIClient.shared.register(email: email, password: password, fullName: fullName, username: username)
                // pass both email & otp to OTP page as requested
                session.requireOTP(email: email, expected: otp)
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }
}
