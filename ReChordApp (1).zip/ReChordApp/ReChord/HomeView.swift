import SwiftUI
import AVFoundation
import PhotosUI

struct HomeView: View {
    @State private var selectedTab = 2
    var body: some View {
        TabView(selection: $selectedTab) {
            Text("Feed").tabItem { Label("Feed", systemImage: "globe") }.tag(0)
            RecorderView().tabItem { Label("Record", systemImage: "dot.circle") }.tag(1)
            ProfileView().tabItem { Label("Profile", systemImage: "person.crop.circle") }.tag(2)
        }
    }
}

struct ProfileView: View {
    @EnvironmentObject var session: AppSession
    @State private var fullName: String = ""
    @State private var username: String = ""
    @State private var phone: String = ""
    @State private var isPrivate: Bool = false
    @State private var imageData: Data?
    @State private var showPicker = false
    @State private var error: String?
    @State private var saving = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // Avatar
                Button {
                    showPicker = true
                } label: {
                    if let imageData, let ui = UIImage(data: imageData) {
                        Image(uiImage: ui).resizable().scaledToFill().frame(width: 96, height: 96).clipShape(Circle())
                    } else {
                        Image("ProfilePlaceholder").resizable().scaledToFill().frame(width: 96, height: 96).clipShape(Circle())
                    }
                }.padding(.top, 20)

                Group {
                    ProfileField(title: "Full name", value: $fullName, system: "person")
                    ProfileField(title: "Username", value: $username, system: "at")
                    ProfileField(title: "Phone", value: $phone, system: "phone")
                }.padding(.horizontal)

                Toggle(isOn: $isPrivate) {
                    Text("Private Account")
                }.padding(.horizontal)

                HStack(spacing: 12) {
                    Button(action: saveProfile) {
                        Text(saving ? "Saving..." : "Save Profile").frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white).cornerRadius(12)
                    }
                    Button(action: uploadAvatar) {
                        Text("Upload Avatar").frame(maxWidth: .infinity).padding().background(Color.gray.opacity(0.3)).cornerRadius(12)
                    }
                }.padding(.horizontal)

                Divider().padding(.vertical, 12)
                VoiceUploader()

                Spacer()
            }
        }
        .photosPicker(isPresented: $showPicker, selection: Binding(get: { nil }, set: { _ in }), matching: .images)
        .onChange(of: showPicker) { _ in } // placeholder to keep PhotosUI imported
        .sheet(isPresented: $showPicker) {
            ImagePicker(data: $imageData)
        }
        .alert("Error", isPresented: Binding(get: { error != nil }, set: { _ in error = nil })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
    }

    func saveProfile() {
        guard let token = session.token, let id = session.currentUser?.id else { error = "Not logged in."; return }
        saving = true
        Task {
            do {
                var fields: [String:String] = [:]
                if !fullName.isEmpty { fields["full_name"] = fullName }
                if !username.isEmpty { fields["username"] = username }
                if !phone.isEmpty { fields["phone"] = phone }
                fields["is_private"] = isPrivate ? "1" : "0"
                try await APIClient.shared.updateClient(id: id, fields: fields, token: token)
            } catch { error = error.localizedDescription }
            saving = false
        }
    }

    func uploadAvatar() {
        guard let token = session.token, let id = session.currentUser?.id else { error = "Not logged in."; return }
        guard let data = imageData else { error = "Pick an image first."; return }
        Task {
            do {
                try await APIClient.shared.uploadAvatar(clientId: id, imageData: data, token: token)
            } catch { error = error.localizedDescription }
        }
    }
}

struct ProfileField: View {
    let title: String
    @Binding var value: String
    let system: String
    var body: some View {
        HStack {
            Image(systemName: system).frame(width: 24)
            TextField(title, text: $value).textInputAutocapitalization(.never)
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
    }
}

struct RecorderView: View {
    @EnvironmentObject var session: AppSession
    @State private var recorder: AVAudioRecorder?
    @State private var url: URL?
    @State private var isRecording = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            Button {
                isRecording ? stop() : record()
            } label: {
                ZStack {
                    Circle().fill(isRecording ? .red : .gray).frame(width: 84, height: 84)
                    Image(systemName: isRecording ? "stop.fill" : "circle.fill").font(.system(size: 32)).foregroundStyle(.white)
                }
            }
            if let url { Text(url.lastPathComponent).font(.footnote) }
            Button("Upload Voice") { upload() }.disabled(url == nil)
            Spacer()
        }
        .alert("Error", isPresented: Binding(get: { error != nil }, set: { _ in error = nil })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
        .padding()
    }
    func record() {
        do {
            let sess = AVAudioSession.sharedInstance()
            try sess.setCategory(.playAndRecord, mode: .default)
            try sess.setActive(true)
            let dir = FileManager.default.temporaryDirectory
            let url = dir.appendingPathComponent("voice_\(UUID().uuidString).m4a")
            let settings: [String:Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 12000,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            recorder = try AVAudioRecorder(url: url, settings: settings)
            recorder?.record()
            self.url = url
            isRecording = true
        } catch { self.error = error.localizedDescription }
    }
    func stop() {
        recorder?.stop()
        isRecording = false
    }
    func upload() {
        guard let token = session.token else { error = "Not logged in."; return }
        guard let url = url, let data = try? Data(contentsOf: url) else { error = "No file."; return }
        Task {
            do {
                try await APIClient.shared.uploadVoice(audioData: data, token: token)
            } catch { error = error.localizedDescription }
        }
    }
}

# UIKit image picker wrapper
struct ImagePicker: UIViewControllerRepresentable {
    @Environment(\.dismiss) var dismiss
    @Binding var data: Data?
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let c = UIImagePickerController()
        c.allowsEditing = true
        c.delegate = context.coordinator
        return c
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker
        init(_ p: ImagePicker) { self.parent = p }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let image = (info[.editedImage] ?? info[.originalImage]) as? UIImage
            self.parent.data = image?.jpegData(compressionQuality: 0.85)
            self.parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}
