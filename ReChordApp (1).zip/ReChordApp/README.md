# ReChord (SwiftUI iOS)

A minimal SwiftUI implementation matching your flows:

- 3s splash then Login
- Registration (`/clients`) -> OTP screen prefilled with returned `otp`
- If a user logs in but `is_active` is false, we call `/clients/activation` and navigate to OTP
- OTP screen compares user entry to server value (if present), then calls `/clients/activate`
- Home has a bottom tab bar; Profile supports avatar upload (`/avatar`) and updating fields (`/clients/{id}`).
- Recorder tab records and uploads using `/voiceupload`.

## Configure
Nothing to configure; endpoints are hard-coded to `https://be.rechord.life/public/api`.

## Build
1. Open `ReChordApp/ReChord.xcodeproj` in Xcode 15+
2. Select an iOS Simulator and **Run**.

> If any endpoints require different payload keys, adjust `APIClient.swift`.

## Notes
- Tokens are stored in `UserDefaults` (swap with Keychain as needed).
- All network calls are `multipart/form-data` to match the Postman examples.
- Placeholder assets are included for missing background/logo.

