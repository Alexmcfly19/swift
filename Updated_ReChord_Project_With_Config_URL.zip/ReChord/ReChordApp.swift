
import SwiftUI

@main
struct ReChordApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                NotificationView()
                    .tabItem {
                        Label("Notifications", systemImage: "bell.fill")
                    }

                MyReChordsView() // Assuming you already have this view
                    .tabItem {
                        Label("My ReChords", systemImage: "mic.fill")
                    }
            }
        }
    }
}
