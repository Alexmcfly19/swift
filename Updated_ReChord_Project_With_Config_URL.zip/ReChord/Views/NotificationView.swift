
import SwiftUI

struct NotificationView: View {
    @State private var notifications: [Notification] = []
    @State private var isLoading = false

    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    ProgressView("Loading...")
                        .progressViewStyle(CircularProgressViewStyle())
                        .padding()
                } else {
                    List(notifications) { notification in
                        VStack(alignment: .leading) {
                            Text(notification.content)
                                .font(.body)
                                .foregroundColor(.primary)
                            Text("Date: \(notification.date)")
                                .font(.footnote)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .onAppear {
                loadNotifications()
            }
            .navigationTitle("Notifications")
        }
    }

    func loadNotifications() {
        guard let userId = UserDefaults.standard.string(forKey: "userId") else {
            return
        }

        isLoading = true
        let urlString = "https://be.rechord.life/public/api/clients/\(userId)/notifications"

        guard let url = URL(string: urlString) else {
            isLoading = false
            return
        }

        var request = URLRequest(url: url)
        request.addValue("application/json", forHTTPHeaderField: "Accept")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error loading notifications: \(error.localizedDescription)")
                isLoading = false
                return
            }

            guard let data = data else {
                isLoading = false
                return
            }

            do {
                let decodedNotifications = try JSONDecoder().decode([Notification].self, from: data)
                DispatchQueue.main.async {
                    notifications = decodedNotifications
                    isLoading = false
                }
            } catch {
                print("Error decoding notifications: \(error.localizedDescription)")
                isLoading = false
            }
        }

        task.resume()
    }
}

struct Notification: Identifiable, Codable {
    let id: Int
    let content: String
    let date: String
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
