
import Foundation

class APIClient {
    static let shared = APIClient()

    private init() {}

    // Function to fetch notifications for a specific user
    func getNotifications(forUser userId: String, completion: @escaping (Result<[Notification], Error>) -> Void) {
        let urlString = "\(APIConfig.baseURL)/clients/\(userId)/notifications"

        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "InvalidURL", code: 400, userInfo: nil)))
            return
        }

        var request = URLRequest(url: url)
        request.addValue("application/json", forHTTPHeaderField: "Accept")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "NoData", code: 404, userInfo: nil)))
                return
            }

            do {
                let notifications = try JSONDecoder().decode([Notification].self, from: data)
                completion(.success(notifications))
            } catch {
                completion(.failure(error))
            }
        }

        task.resume()
    }

    // Function to fetch user's ReChords (posts)
    func getReChords(forUser userId: String, completion: @escaping (Result<[ReChord], Error>) -> Void) {
        let urlString = "\(APIConfig.baseURL)/voices"

        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "InvalidURL", code: 400, userInfo: nil)))
            return
        }

        var request = URLRequest(url: url)
        request.addValue("application/json", forHTTPHeaderField: "Accept")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "NoData", code: 404, userInfo: nil)))
                return
            }

            do {
                let reChords = try JSONDecoder().decode([ReChord].self, from: data)
                completion(.success(reChords))
            } catch {
                completion(.failure(error))
            }
        }

        task.resume()
    }
}

struct Notification: Identifiable, Codable {
    let id: Int
    let content: String
    let date: String
}

struct ReChord: Identifiable, Codable {
    let id: Int
    let title: String
    let playbackCount: Int
    let likesCount: Int
}
