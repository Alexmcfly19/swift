import Foundation
import UIKit

enum APIError: Error, LocalizedError {
    case badURL, badResponse, server(String), decoding, unauthorized, missingToken
    
    var errorDescription: String? {
        switch self {
        case .server(let msg): return msg
        case .unauthorized: return "Unauthorized"
        case .badResponse: return "Bad response"
        case .decoding: return "Decoding error"
        case .badURL: return "Bad URL"
        case .missingToken: return "Missing token"
        }
    }
}

struct LoginResult {
    var token: String?
    var isActive: Bool?
    var userId: Int?
    var email:String?
}

final class APIClient {
    static let shared = APIClient()
    private init() {}
    
    // MARK: - Generic request helpers
    
    private func makeRequest(path: String, method: String = "POST", headers: [String:String] = [:]) -> URLRequest {
        let url = APIConfig.baseURL.appendingPathComponent(path)
        var req = URLRequest(url: url)
        req.httpMethod = method
        headers.forEach { req.addValue($0.value, forHTTPHeaderField: $0.key) }
        return req
    }
    
    private func decodeToDictionary(_ data: Data) throws -> [String: Any] {
        if let dict = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
            return dict
        }
        throw APIError.decoding
    }
    
    private func valueAt(_ dict: [String: Any], keys: [String]) -> Any? {
        for key in keys {
            if let v = dict[key] { return v }
        }
        return nil
    }
    
    // Helper to extract bool-ish flags
    private func extractBool(_ any: Any?) -> Bool? {
        if let b = any as? Bool { return b }
        if let i = any as? Int { return i != 0 }
        if let s = any as? String { return (s == "1" || s.lowercased() == "true" || s.lowercased() == "yes") }
        return nil
    }
    
    // Helper to extract int
    private func extractInt(_ any: Any?) -> Int? {
        if let i = any as? Int { return i }
        if let s = any as? String { return Int(s) }
        return nil
    }
    
    // MARK: - Endpoints
    
    // Register → returns an OTP (server response contains it per spec)
    func register(email: String, password: String, fullName: String, username: String) async throws -> String? {
        var req = makeRequest(path: "clients")
        let mp = MultipartBuilder()
        req.addValue("application/json", forHTTPHeaderField: "Accept")
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        let body = mp.build(parameters: [
            "email": email,
            "password": password,
            "full_name": fullName,
            "username": username
        ], files: [])
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: data, encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
        let dict = try decodeToDictionary(data)
        // Try common keys for otp
        let otp = valueAt(dict, keys: ["otp","code","activation_code"]) as? String
        return otp
    }
    
    // Login → returns token, activation state, id, email
    func login(email: String, password: String) async throws -> LoginResult {
        var req = makeRequest(path: "/clients/login")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        let body = mp.build(parameters: ["email": email, "password": password], files: [])
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw APIError.badResponse }
        let dict = try decodeToDictionary(data)
        
        if http.statusCode == 401 { throw APIError.unauthorized }
        if !(200..<300).contains(http.statusCode) {
            let msg = (dict["message"] as? String) ?? "Server error"
            throw APIError.server(msg)
        }
        
        var result = LoginResult()
        result.token = (dict["token"] as? String) ?? (dict["access_token"] as? String)
        result.email = email
        
        // Try to find activation & id in common places (root or nested "user"/"client")
        let user = (dict["user"] as? [String:Any]) ?? (dict["client"] as? [String:Any]) ?? dict
        
        result.isActive = extractBool(dict["status"] ?? user["activated"] ?? user["active"])
        result.userId = extractInt(dict["id"] ?? user["client_id"] ?? user["user_id"])
        return result
    }
    
    // Request activation → returns OTP string for the given email
    func requestActivation(email: String) async throws -> String? {
        var req = makeRequest(path: "clients/activation")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        let body = mp.build(parameters: ["email": email], files: [])
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: data, encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
        let dict = try decodeToDictionary(data)
        return (dict["otp"] as? String) ?? (dict["code"] as? String) ?? (dict["activation_code"] as? String)
    }
    
    // Activate account (by email)
    func activate(email: String) async throws {
        var req = makeRequest(path: "clients/activate")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        let body = mp.build(parameters: ["email": email], files: [])
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: data,encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
    }
    
    // Update client fields (name, username, etc.)
    func updateClient(id: Int, fields: [String: String], token: String) async throws {
        var req = makeRequest(path: "clients/\(id)")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.addValue("application/json", forHTTPHeaderField: "Accept")
        let body = mp.build(parameters: fields, files: [])
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: data, encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
    }
    
    // Upload avatar
    func uploadAvatar(image: UIImage, clientId: Int, token: String) async throws {
        guard let data = image.jpegData(compressionQuality: 0.9) else { throw APIError.badResponse }
        var req = makeRequest(path: "avatar")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let files = [MultipartFile(data: data, name: "avatar", filename: "avatar.jpg", mimeType: "image/jpeg")]
        let body = mp.build(parameters: ["client_id": String(clientId)], files: files)
        req.httpBody = body
        
        let (dt, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: dt, encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
    }
    
    // Upload voice
    func uploadVoice(voiceData: Data, token: String) async throws {
        var req = makeRequest(path: "voiceupload")
        let mp = MultipartBuilder()
        req.addValue(mp.contentType, forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let files = [MultipartFile(data: voiceData, name: "voice", filename: "voice.m4a", mimeType: "audio/m4a")]
        let body = mp.build(parameters: [:], files: files)
        req.httpBody = body
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            let msg = String(data: data, encoding: .utf8) ?? "Server error"
            throw APIError.server(msg)
        }
    }
    // Fetch client profile by id (POST /clients/show/{id})
    struct ClientProfile {
        var name: String?
        var username: String?
        var email: String?
        var phone: String?
        var website: String?
        var isPrivate: Bool?
        var locationPermission: Bool?
        var languages: [String]?
    }
    
    func showClientById(id: Int, token: String) async throws -> ClientProfile {
        var req = makeRequest(path: "clients/show/\(id)")
        req.addValue("application/json", forHTTPHeaderField: "Accept")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw APIError.badResponse }
        let dict = try decodeToDictionary(data)
        if http.statusCode == 401 { throw APIError.unauthorized }
        if !(200..<300).contains(http.statusCode) {
            let msg = (dict["message"] as? String) ?? "Server error"
            throw APIError.server(msg)
        }
        
        // Common nesting: root, "client", "data", or "user"
        let user = (dict["client"] as? [String:Any]) ?? (dict["data"] as? [String:Any]) ?? (dict["user"] as? [String:Any]) ?? dict
        
        var profile = ClientProfile()
        profile.name = (user["name"] as? String) ?? (user["full_name"] as? String) ?? (user["fullname"] as? String)
        profile.username = (user["username"] as? String) ?? (user["handle"] as? String)
        profile.email = (user["email"] as? String)
        profile.phone = (user["phone"] as? String) ?? (user["mobile"] as? String)
        profile.website = (user["website"] as? String) ?? (user["link"] as? String) ?? (user["url"] as? String)
        profile.isPrivate = extractBool(user["is_private"] ?? user["private"] ?? user["isPrivate"])
        profile.locationPermission = extractBool(user["location_permission"] ?? user["locationPerm"] ?? user["share_location"])
        
        if let langs = user["languages"] as? [String] {
            profile.languages = langs
        } else if let l = user["languages"] as? String {
            profile.languages = l.split(separator: ",").map{ $0.trimmingCharacters(in: .whitespaces) }
        }
        return profile
    }
}
