import Foundation
import SwiftUI
import AVFoundation
import MapKit

/// A shared manager responsible for handling voice recording, playback,
/// metadata entry and uploading. This class centralises the state and
/// behaviours necessary to record a voice, attach additional information
/// (title, privacy flags, location and cover image) and send the result to
/// the backend. It is intended to be provided as an ``EnvironmentObject``
/// so that multiple views can observe and mutate recording state without
/// duplicating logic.
@MainActor
final class RecorderManager: ObservableObject {
    /// The high level recording state that determines which action to
    /// perform when the user interacts with the record button.
    enum RecordingState {
        case idle    // No recording has been started yet
        case recording  // Currently capturing audio
        case recorded   // A recording exists and can be sent
    }

    // MARK: - Published properties

    /// Current recording state. When changed the UI can update the
    /// appearance of the record button accordingly.
    @Published var recordingState: RecordingState = .idle
    /// URL of the recorded audio file on disk. Becomes non‐nil when
    /// ``recordingState`` transitions to `.recorded`. Reset back to nil
    /// upon sending or deleting the recording.
    @Published var voiceURL: URL? = nil
    /// The audio player used for playback within the metadata view.
    @Published var player: AVPlayer? = nil
    /// Flag indicating whether the player is currently playing. Bound
    /// to the play/pause button in the metadata view.
    @Published var isPlaying: Bool = false
    /// The temporary filename where the recorded audio is stored. Used
    /// internally to clean up after deletion.
    private var audioFilename: URL? = nil

    /// User entered description or title of the voice. When empty the
    /// upload will use a default title.
    @Published var descriptionText: String = ""
    /// Optional place name entered by the user.
    @Published var placeName: String = ""
    /// Indicates whether the user wants the voice to be private. When
    /// `true` the precise location will not be shared with others.
    @Published var isPrivate: Bool = false
    /// Indicates whether the location should be stored precisely. This
    /// value is ignored if ``isPrivate`` is `true`.
    @Published var isPrecise: Bool = true
    /// Optional cover image selected by the user. If provided this
    /// picture will be uploaded alongside the voice recording and
    /// included in the final voice metadata.
    @Published var coverImage: UIImage? = nil
    /// The current geographic location used when sending the voice. This
    /// should be updated by the presenting view (e.g. the metadata view)
    /// whenever the device's location changes. If `nil` the location
    /// defaults to (0,0).
    @Published var currentLocation: CLLocationCoordinate2D? = nil

    // MARK: - Private properties
    /// The audio session used to capture microphone input. This is
    /// configured when starting a recording and deactivated when
    /// recording finishes.
    private var audioSession: AVAudioSession? = nil
    /// The underlying audio recorder. Non‑nil only whilst a recording
    /// session is in progress. Automatically cleaned up when stopped.
    private var audioRecorder: AVAudioRecorder? = nil

    // MARK: - Recording controls

    /// Begin capturing audio from the microphone. This method sets up
    /// the audio session and starts recording into a temporary file. If a
    /// recording is already in progress the call is ignored. Errors are
    /// printed to the console; the UI does not currently surface them.
    func startRecording() {
        guard recordingState == .idle else { return }
        do {
            // Configure the shared audio session for play and record so
            // playback can route through the speaker whilst recording.
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try session.setActive(true)
            audioSession = session
            // Create a unique filename in the temporary directory.
            let filename = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".m4a")
            // Standard settings for AAC encoded audio.
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 12000,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            // Initialise the recorder and start recording.
            audioRecorder = try AVAudioRecorder(url: filename, settings: settings)
            audioRecorder?.record()
            audioFilename = filename
            // Update state to reflect that recording has begun.
            recordingState = .recording
        } catch {
            print("Failed to start recording: \(error)")
        }
    }

    /// Stop the current recording session. If no recording is in
    /// progress this call is ignored. When a recording is successfully
    /// captured the recorded file is promoted to ``voiceURL`` and an
    /// ``AVPlayer`` is created for playback.
    func stopRecording() {
        guard recordingState == .recording else { return }
        audioRecorder?.stop()
        audioRecorder = nil
        if let url = audioFilename {
            voiceURL = url
            player = AVPlayer(url: url)
            recordingState = .recorded
        } else {
            recordingState = .idle
        }
    }

    /// Delete the current recording, resetting the manager back to the
    /// idle state. This will remove the file from disk if it exists and
    /// clear out any associated audio state.
    func deleteRecording() {
        // Stop playback if needed.
        player?.pause()
        player = nil
        isPlaying = false
        // Remove the recorded file.
        if let url = audioFilename {
            try? FileManager.default.removeItem(at: url)
            audioFilename = nil
        }
        voiceURL = nil
        recordingState = .idle
    }

    /// Toggle playback of the recorded audio. When called the
    /// ``player`` is started or paused. If no player exists (because
    /// there is no recorded audio) the call does nothing.
    func togglePlay() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
        } else {
            player.play()
        }
        isPlaying.toggle()
    }

    /// Compute the current playback progress as a fraction between 0 and
    /// 1. When there is no player or the duration is unknown this
    /// property returns 0.
    var progress: Double {
        guard let player = player,
              let item = player.currentItem,
              item.duration.seconds.isFinite,
              item.duration.seconds > 0 else { return 0 }
        return player.currentTime().seconds / item.duration.seconds
    }

    // MARK: - Uploading

    /// Upload the current voice and optional cover image and then send
    /// metadata to the server. Upon successful completion the manager
    /// resets back to the idle state. This call must be executed on
    /// the main actor because ``APIClient`` uses `URLSession` which
    /// dispatches callbacks back onto the main thread by default.
    ///
    /// - Parameter app: The shared ``AppState`` used to retrieve the
    ///   current authentication token and user identifier. If either is
    ///   missing the upload is aborted.
    func sendVoice(app: AppState) async {
        // Ensure we have a recording to send.
        guard recordingState == .recorded, let url = voiceURL else { return }
        guard let token = app.token, let ownerId = app.currentUserId else {
            print("Missing token or user ID")
            return
        }
        do {
            // Read the audio data from disk.
            let data = try Data(contentsOf: url)
            // First upload the audio and retrieve a link or id.
            let voiceLink = try await APIClient.shared.uploadVoiceReturningLink(voiceData: data, token: token)
            var pictureLink: String? = nil
            // If a cover image exists, upload it.
            if let img = coverImage {
                pictureLink = try await APIClient.shared.uploadImageReturningLink(image: img, token: token)
            }
            // Determine the title. Fall back to "Voice" when blank.
            let title = descriptionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Voice" : descriptionText
            // Compute whether to send the precise location. If the user
            // has marked the voice as private then we forcibly set
            // precise to false.
            let precise = isPrecise && !isPrivate
            // Use the last known location, defaulting to 0/0 when nil.
            let coordinate = currentLocation ?? CLLocationCoordinate2D(latitude: 0, longitude: 0)
            let x = coordinate.latitude
            let y = coordinate.longitude
            // Issue the final voice creation request.
            try await APIClient.shared.sendNewVoice(ownerId: ownerId, title: title, preciseLocation: precise, positionX: x, positionY: y, voiceLink: voiceLink, pictureLink: pictureLink, token: token)
            // Reset state after successful upload.
            reset()
        } catch {
            print("Error sending voice: \(error)")
        }
    }

    /// Reset all user‑modifiable state to its initial values. This is
    /// called after a voice has been successfully uploaded. Note that
    /// description, place name and picture are also cleared so the next
    /// recording starts fresh.
    private func reset() {
        deleteRecording()
        descriptionText = ""
        placeName = ""
        isPrivate = false
        isPrecise = true
        coverImage = nil
        currentLocation = nil
    }
}