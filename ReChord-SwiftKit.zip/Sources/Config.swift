import Foundation

enum APIConfig {
    static let baseURL = URL(string: "https://be.rechord.life/public/api")!
}