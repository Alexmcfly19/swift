import SwiftUI

struct PrimaryButtonLabel: View {
    let title: String
    init(_ t: String) { self.title = t }
    var body: some View {
        Text(title)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.blue)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct ReField: View {
    @Binding var text: String
    var placeholder: String
    var body: some View {
        TextField(placeholder, text: $text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .padding(.horizontal, 16)
            .frame(height: 52)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .foregroundStyle(.primary)
    }
}

struct SecureReField: View {
    @Binding var text: String
    var placeholder: String
    var body: some View {
        SecureField(placeholder, text: $text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .padding(.horizontal, 16)
            .frame(height: 52)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .foregroundStyle(.primary)
    }
}

struct ToastView: View {
    let text: String
    var body: some View {
        VStack {
            Spacer()
            Text(text)
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.bottom, 40)
        }.animation(.easeInOut, value: text)
    }
}