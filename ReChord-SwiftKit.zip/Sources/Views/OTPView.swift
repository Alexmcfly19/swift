import SwiftUI

enum OTPMode { case registration, activation }

struct OTPView: View {
    @EnvironmentObject var app: AppState
    @Environment(\.__designTimeSelection(nil, placeholder: "dismiss")) private var dismiss
    
    let mode: OTPMode
    @State private var code: String = ""
    @State private var error: String?
    @State private var info: String = ""
    
    var body: some View {
        VStack(spacing: 24) {
            Spacer().frame(height: 32)
            Image("placeholder-logo").resizable().frame(width: 100, height: 100).clipShape(RoundedRectangle(cornerRadius: 24))
            Text("ReChord").font(.system(size: 34, weight: .bold))
            Text("Please enter 6 digit number we sent to you")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal)
            
            OTPBoxes(code: $code)
                .padding(.horizontal, 32)
            
            Button { Task { await verify() } } label: { PrimaryButtonLabel("Continue") }
                .disabled(code.count < 4)
                .padding(.horizontal, 28)
            
            Button("Didn’t get the code, we can resend it again") {
                Task { await resend() }
            }
            .font(.footnote)
            .padding(.top, 8)
            
            if let e = error { Text(e).foregroundStyle(.red).font(.footnote) }
            if !info.isEmpty { Text(info).foregroundStyle(.secondary).font(.footnote) }
            Spacer()
        }
        .padding(.bottom, 24)
    }
    
    private func verify() async {
        // Client-side OTP check per spec
        guard let expected = app.pendingOTP?.trimmingCharacters(in: .whitespacesAndNewlines), !expected.isEmpty else {
            self.error = "No OTP available. Tap resend."
            return
        }
        guard code == expected else {
            self.error = "Invalid code"
            return
        }
        do {
            try await APIClient.shared.activate(email: app.currentEmail)
            app.isAuthenticated = true
            dismissAction()
        } catch {
            self.error = error.localizedDescription
        }
    }
    
    private func resend() async {
        do {
            if let otp = try await APIClient.shared.requestActivation(email: app.currentEmail) {
                app.pendingOTP = otp
                info = "New code sent."
            } else {
                info = "Code requested."
            }
        } catch {
            self.error = error.localizedDescription
        }
    }
    
    private func dismissAction() {
        UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: AnyView(HomeView().environmentObject(app)))
    }
}

// Six boxes UI backed by a single TextField
struct OTPBoxes: View {
    @Binding var code: String
    @FocusState private var focus: Bool
    var body: some View {
        ZStack {
            HStack(spacing: 12) {
                ForEach(0..<6, id: \.self) { i in
                    ZStack {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color(UIColor.secondarySystemBackground))
                            .frame(height: 54)
                        Text(char(at: i)).font(.title2).monospacedDigit()
                    }
                }
            }
            TextField("", text: Binding(
                get: { self.code },
                set: { self.code = String($0.prefix(6)).filter { $0.isNumber } }
            ))
            .keyboardType(.numberPad)
            .textContentType(.oneTimeCode)
            .frame(width: 0, height: 0).opacity(0.01)
            .focused($focus)
        }
        .onAppear { focus = true }
        .onTapGesture { focus = true }
    }
    private func char(at index: Int) -> String {
        guard index < code.count else { return "" }
        let i = code.index(code.startIndex, offsetBy: index)
        return String(code[i])
    }
}