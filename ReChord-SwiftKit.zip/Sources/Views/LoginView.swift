import SwiftUI

struct LoginView: View {
    @EnvironmentObject var app: AppState
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isLoading = false
    @State private var error: String?
    @State private var showRegister = false
    
    var body: some View {
        ZStack {
            Image("placeholder-bg").resizable().scaledToFill().ignoresSafeArea()
            
            VStack(spacing: 24) {
                Spacer().frame(height: 60)
                Image("placeholder-logo")
                    .resizable()
                    .frame(width: 120, height: 120)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                Text("ReChord").font(.system(size: 40, weight: .bold)).foregroundStyle(.white)
                
                VStack(spacing: 14) {
                    ReField(text: $email, placeholder: "Enter your email or phone number")
                        .keyboardType(.emailAddress)
                    SecureReField(text: $password, placeholder: "Please enter your Password")
                }.padding(.horizontal, 28)
                
                Button {
                    Task { await login() }
                } label: {
                    PrimaryButtonLabel("Continue")
                }.disabled(isLoading)
                .padding(.horizontal, 28)
                
                Button("Forget your password?") { }
                    .foregroundStyle(.white.opacity(0.9))
                    .font(.footnote)
                    .padding(.top, 8)
                
                Spacer()
                HStack(spacing: 4) {
                    Text("Don’t have an account,")
                    Button("sing up") { showRegister = true }
                }
                .foregroundStyle(.white.opacity(0.9))
                .font(.footnote)
                .padding(.bottom, 24)
            }
            
            if let e = error {
                ToastView(text: e)
            }
        }
        .sheet(isPresented: $showRegister) {
            RegisterView()
        }
    }
    
    private func login() async {
        isLoading = true; defer { isLoading = false }
        do {
            let result = try await APIClient.shared.login(email: email, password: password)
            app.currentEmail = email
            if let token = result.token { app.token = token }
            app.currentUserId = result.userId
            
            if let active = result.isActive, active == false {
                // Needs activation → request OTP and show OTP screen
                app.needsActivation = true
                if let otp = try? await APIClient.shared.requestActivation(email: email) {
                    app.pendingOTP = otp
                }
                presentOTP(mode: .activation)
            } else {
                app.isAuthenticated = true
                presentHome()
            }
        } catch {
            self.error = error.localizedDescription
        }
    }
    
    private func presentOTP(mode: OTPMode) {
        let vc = UIHostingController(rootView: OTPView(mode: mode))
        UIApplication.shared.windows.first?.rootViewController?.present(vc, animated: true)
    }
    
    private func presentHome() {
        UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: AnyView(HomeView().environmentObject(app)))
    }
}