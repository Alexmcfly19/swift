import SwiftUI
import PhotosUI

struct ProfileView: View {
    @EnvironmentObject var app: AppState
    @State private var fullName: String = ""
    @State private var username: String = ""
    @State private var phone: String = ""
    @State private var email: String = ""
    @State private var isPrivate: Bool = true
    @State private var locationPerm: Bool = false
    @State private var avatar: UIImage? = nil
    @State private var pickerPresented = false
    @State private var error: String?
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 16) {
                    Button {
                        pickerPresented = true
                    } label: {
                        Group {
                            if let img = avatar {
                                Image(uiImage: img).resizable()
                            } else {
                                Image("placeholder-avatar").resizable()
                            }
                        }
                        .frame(width: 76, height: 76)
                        .clipShape(Circle())
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        ReField(text: $fullName, placeholder: "Philipa Rout")
                        ReField(text: $username, placeholder: "@ Philirout")
                    }
                }.padding(.horizontal)
                
                GroupBox("About me") {
                    HStack {
                        Image(systemName: "play.circle.fill").font(.title2)
                        RoundedRectangle(cornerRadius: 8).fill(Color(UIColor.secondarySystemBackground))
                            .frame(height: 44).overlay(Text(" •••••••••••••• "))
                        Image(systemName: "record.circle.fill").font(.title2)
                    }
                }.padding(.horizontal)
                
                GroupBox("Contact Options") {
                    VStack(spacing: 12) {
                        ReField(text: $phone, placeholder: "+44 234 11 2455")
                        ReField(text: $email, placeholder: "p.rout@gmail.com")
                        ReField(text: .constant("rout.philipa"), placeholder: "rout.philipa")
                    }
                }.padding(.horizontal)
                
                GroupBox("Language Preference") {
                    HStack {
                        Text("English").padding(.horizontal, 10).padding(.vertical, 6).background(Capsule().fill(Color(UIColor.tertiarySystemFill)))
                        Text("Latin").padding(.horizontal, 10).padding(.vertical, 6).background(Capsule().fill(Color(UIColor.tertiarySystemFill)))
                    }
                }.padding(.horizontal)
                
                Toggle("Private Account", isOn: $isPrivate).padding(.horizontal)
                Toggle("Location Permission", isOn: $locationPerm).padding(.horizontal)
                
                Button {
                    Task { await save() }
                } label: { PrimaryButtonLabel("Save Profile") }
                .padding(.horizontal)
                
                Button(role: .destructive) { AppState.shared.signOut() } label: {
                    Text("Sign Out").frame(maxWidth: .infinity).padding(.vertical, 12)
                }.padding(.horizontal)
                
                if let e = error { Text(e).foregroundStyle(.red).padding(.horizontal) }
                
                Spacer().frame(height: 24)
            }
        }
        .photosPicker(isPresented: $pickerPresented, selection: .constant(nil))
        .onChange(of: pickerPresented) { _, newVal in /* placeholder */ }
        .onAppear {
            email = app.currentEmail
        }
        .onTapGesture { UIApplication.shared.endEditing() }
        .toolbarTitleDisplayMode(.inline)
    }
    
    private func save() async {
        guard let token = app.token, let id = app.currentUserId else { error = "Missing user"; return }
        var fields: [String:String] = [:]
        if !fullName.isEmpty { fields["full_name"] = fullName }
        if !username.isEmpty { fields["username"] = username }
        if !phone.isEmpty { fields["phone"] = phone }
        do {
            try await APIClient.shared.updateClient(id: id, fields: fields, token: token)
            if let img = avatar {
                try await APIClient.shared.uploadAvatar(image: img, clientId: id, token: token)
            }
        } catch { self.error = error.localizedDescription }
    }
}

private extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}