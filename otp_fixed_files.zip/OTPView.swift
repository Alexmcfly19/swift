import SwiftUI

struct OTPView: View {
    @EnvironmentObject var auth: AuthViewModel
    let email: String

    @State private var code: String = ""
    @FocusState private var isFieldFocused: Bool

    var body: some View {
        VStack(spacing: 20) {
            VStack(spacing: 6) {
                Text("Enter Verification Code").font(.title2).bold()
                Text("We sent a 6-digit code to \(email)")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }.padding(.top, 24)

            TextField("••••••", text: $code)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
                .keyboardType(.numberPad).focused($isFieldFocused)
                .multilineTextAlignment(.center)
                .font(.system(size: 28, weight: .semibold, design: .monospaced))
                .padding(.vertical, 12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(.quaternary))
                .onChange(of: code) { _, newValue in
                    let filtered = newValue.filter(\.{isNumber})
                    if filtered != newValue || filtered.count > 6 {
                        code = String(filtered.prefix(6))
                    }
                }
                .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { isFieldFocused = true } }

            Button {
                Task { await auth.submitOTP(code) }
            } label: {
                HStack {
                    if auth.isLoading { ProgressView().tint(.white) }
                    Text(auth.isLoading ? "Verifying..." : "Verify").bold()
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background((code.count == 6 && !auth.isLoading) ? Color.accentColor : Color.accentColor.opacity(0.5))
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .disabled(code.count != 6 || auth.isLoading)

            if let error = auth.error, !error.isEmpty {
                Text(error).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center).padding(.top, 4)
            }

            Spacer()

            Button("Use a different email") { auth.goToRegister() }
                .font(.footnote).padding(.bottom, 24)
        }
        .padding(.horizontal, 24)
    }
}

#if DEBUG
struct OTPView_Previews: PreviewProvider {
    static var previews: some View {
        OTPView(email: "user@example.com").environmentObject(AuthViewModel())
    }
}
#endif
