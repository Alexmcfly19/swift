import Foundation

// MARK: - API Models

struct RegisterResponse: Codable {
    let success: Bool
    let message: String
    let email: String
    let otp: String            // ← backend should return this
}

struct VerifyResponse: Codable {
    let verified: Bool
    let message: String
}
