import Foundation

// MARK: - Service Protocol

protocol AuthServicing {
    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse
    func activate(email: String) async throws -> VerifyResponse
}

// MARK: - Auth Service

final class AuthService: AuthServicing {

    private let useMock: Bool = false
    private let baseURL = URL(string: "https://your.api.example.com")!

    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse {
        if useMock {
            try await Task.sleep(nanoseconds: 500_000_000)
            return RegisterResponse(success: true, message: "Registered", email: email, otp: "123456")
        }

        struct Body: Encodable { let email: String; let password: String; let fullName: String; let username: String }
        let body = Body(email: email, password: password, fullName: fullName, username: username)
        return try await postJSON(path: "/auth/register", body: body, responseType: RegisterResponse.self)
    }

    func activate(email: String) async throws -> VerifyResponse {
        if useMock {
            try await Task.sleep(nanoseconds: 300_000_000)
            return VerifyResponse(verified: true, message: "Account activated")
        }

        struct Body: Encodable { let email: String }
        let body = Body(email: email)
        return try await postJSON(path: "/auth/activate", body: body, responseType: VerifyResponse.self)
    }

    private func postJSON<Request: Encodable, Response: Decodable>(
        path: String,
        body: Request,
        responseType: Response.Type
    ) async throws -> Response {
        var request = URLRequest(url: baseURL.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let serverMessage = String(data: data, encoding: .utf8) ?? "Unknown server error"
            throw NSError(domain: "AuthService", code: (response as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: serverMessage])
        }
        return try JSONDecoder().decode(Response.self, from: data)
    }
}
