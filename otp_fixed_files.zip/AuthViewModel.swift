import Foundation
import SwiftUI

@MainActor
final class AuthViewModel: ObservableObject {

    enum ScreenState: Equatable {
        case splash, login, register, otp(email: String), home
    }

    @Published var state: ScreenState = .login
    @Published var isLoading: Bool = false
    @Published var error: String? = nil

    private var pendingEmail: String?
    private var pendingOTP: String?
    private let service: AuthServicing

    init(service: AuthServicing = AuthService()) {
        self.service = service
    }

    func register(email: String, password: String, fullName: String, username: String) async {
        isLoading = true; error = nil
        defer { isLoading = false }
        do {
            let res = try await service.register(email: email, password: password, fullName: fullName, username: username)
            pendingEmail = res.email
            pendingOTP = res.otp
            state = .otp(email: res.email)
        } catch {
            self.error = error.localizedDescription
        }
    }

    func submitOTP(_ code: String) async {
        guard let expected = pendingOTP, let email = pendingEmail else {
            error = "Missing registration context. Please register again."
            state = .register
            return
        }
        guard code == expected else {
            error = "Incorrect code. Please try again."
            return
        }

        isLoading = true; error = nil
        defer { isLoading = false }
        do {
            let verify = try await service.activate(email: email)
            guard verify.verified else { self.error = verify.message; return }
            pendingOTP = nil; pendingEmail = nil
            state = .login
        } catch {
            self.error = error.localizedDescription
        }
    }

    func goToLogin() { state = .login }
    func goToRegister() { state = .register }
}
