# ReChord SwiftUI App (iOS 15+)

This is a minimal, production-ready SwiftUI client that implements the flow you described:

- Splash (3s) → Login / Home
- Login (`POST /clients/login`)
- Register (`POST /clients`) → OTP page
- OTP immediate + deferred activation:
  - `POST /clients/activation` to (re)send OTP
  - `POST /clients/activate` to activate (client compares OTP locally as requested)
- Home (tab bar)
- Profile:
  - Avatar upload (`POST /avatar` multipart)
  - Update client (`POST /clients/{id}`)
  - Voice upload (`POST /voiceupload` multipart)

Endpoints are taken from your Postman collection `ReChord on Host.postman_collection.json`.

> Note: For clarity, token persistence uses a tiny Keychain wrapper. Update bundle identifiers/capabilities in your own Xcode project.

## How to use

1. Create a new **App** project in Xcode (SwiftUI, iOS 15+).
2. Replace the generated files with the contents of `Sources/` in this zip, or just drop the entire folder into your project.
3. Set **Signing & Capabilities** and bundle ID.
4. Run on device/simulator.

You can also keep the file structure and drag the folder into Xcode as a group.

## Configuration

- `API.base` is set to `https://be.rechord.life/public/api`.
- If your server requires different headers/fields, adjust in `APIClient.swift`.

## Disclaimer

Comparing OTP on the client is generally insecure; this mirrors the behavior you requested and what the Postman export suggests.

