
import Foundation
import UIKit

enum APIError: Error, LocalizedError {
    case badStatus(Int)
    case invalidResponse
    case decoding
    case network(Error)
    case missingToken
    case message(String)

    var errorDescription: String? {
        switch self {
        case .badStatus(let c): return "HTTP \(c)"
        case .invalidResponse: return "Invalid server response"
        case .decoding: return "Decoding error"
        case .network(let e): return e.localizedDescription
        case .missingToken: return "Missing auth token"
        case .message(let m): return m
        }
    }
}

enum API {
    static let base = URL(string: "https://be.rechord.life/public/api")!
}

struct Envelope<T: Decodable>: Decodable {
    let status: Bool?
    let message: String?
    let data: T?
}

struct Client: Codable, Identifiable, Equatable {
    let id: Int
    let email: String
    let full_name: String?
    let username: String?
    let phone: String?
    let is_private: Int?
    let is_active: Bool?

    // permissive decoding for is_active (0/1/bool)
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        email = (try? c.decode(String.self, forKey: .email)) ?? ""
        full_name = try? c.decode(String.self, forKey: .full_name)
        username = try? c.decode(String.self, forKey: .username)
        phone = try? c.decode(String.self, forKey: .phone)
        is_private = try? c.decode(Int.self, forKey: .is_private)
        if let b = try? c.decode(Bool.self, forKey: .is_active) {
            is_active = b
        } else if let i = try? c.decode(Int.self, forKey: .is_active) {
            is_active = (i != 0)
        } else {
            is_active = nil
        }
    }
}

struct LoginResponse: Decodable {
    let token: String?
    let user: Client?
    let message: String?
}

struct RegisterResponse: Decodable {
    let user: Client?
    let otp: String?
    let message: String?
}

struct ActivationResponse: Decodable {
    let otp: String?
    let message: String?
}

final class APIClient {
    static let shared = APIClient()
    private init() {}

    private func makeRequest(path: String, method: String = "POST", form: [String: String]? = nil, token: String? = nil) async throws -> (Data, HTTPURLResponse) {
        var req = URLRequest(url: API.base.appendingPathComponent(path))
        req.httpMethod = method
        if let token = token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let form = form {
            let body = form
                .map { key, val in "\(key)=\(val.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? val)" }
                .joined(separator: "&")
                .data(using: .utf8)!
            req.httpBody = body
            req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        }
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw APIError.invalidResponse }
        guard (200...299).contains(http.statusCode) else {
            if let m = String(data: data, encoding: .utf8) { throw APIError.message(m) }
            throw APIError.badStatus(http.statusCode)
        }
        return (data, http)
    }

    // MARK: - Auth

    func login(email: String, password: String) async throws -> LoginResponse {
        let (data, _) = try await makeRequest(path: "clients/login", form: [
            "email": email, "password": password
        ])
        if let lr = try? JSONDecoder().decode(LoginResponse.self, from: data) { return lr }
        if let env = try? JSONDecoder().decode(Envelope<LoginResponse>.self, from: data), let d = env.data { return d }
        throw APIError.decoding
    }

    func register(email: String, password: String, fullName: String, username: String) async throws -> RegisterResponse {
        let (data, _) = try await makeRequest(path: "clients", form: [
            "email": email, "password": password, "full_name": fullName, "username": username
        ])
        if let rr = try? JSONDecoder().decode(RegisterResponse.self, from: data) { return rr }
        if let env = try? JSONDecoder().decode(Envelope<RegisterResponse>.self, from: data), let d = env.data { return d }
        // Fallback if server just returns OTP directly
        if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let otp = obj["otp"] as? String
            let message = obj["message"] as? String
            return RegisterResponse(user: nil, otp: otp, message: message)
        }
        throw APIError.decoding
    }

    func activation(email: String) async throws -> ActivationResponse {
        let (data, _) = try await makeRequest(path: "clients/activation", form: ["email": email])
        if let ar = try? JSONDecoder().decode(ActivationResponse.self, from: data) { return ar }
        if let env = try? JSONDecoder().decode(Envelope<ActivationResponse>.self, from: data), let d = env.data { return d }
        if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            return ActivationResponse(otp: obj["otp"] as? String, message: obj["message"] as? String)
        }
        throw APIError.decoding
    }

    func activate(email: String) async throws {
        _ = try await makeRequest(path: "clients/activate", form: ["email": email])
    }

    // MARK: - Profile

    func updateClient(id: Int, fields: [String: String], token: String) async throws -> Client {
        let (data, _) = try await makeRequest(path: "clients/\(id)", form: fields, token: token)
        if let c = try? JSONDecoder().decode(Client.self, from: data) { return c }
        if let env = try? JSONDecoder().decode(Envelope<Client>.self, from: data), let d = env.data { return d }
        throw APIError.decoding
    }

    func uploadAvatar(clientId: Int, imageData: Data, token: String) async throws {
        let boundary = "Boundary-\(UUID().uuidString)"
        var req = URLRequest(url: API.base.appendingPathComponent("avatar"))
        req.httpMethod = "POST"
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        func append(_ s: String) { body.append(s.data(using: .utf8)!) }

        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"client_id\"\r\n\r\n")
        append("\(clientId)\r\n")

        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"avatar\"; filename=\"avatar.jpg\"\r\n")
        append("Content-Type: image/jpeg\r\n\r\n")
        body.append(imageData)
        append("\r\n--\(boundary)--\r\n")

        let (data, resp) = try await URLSession.shared.upload(for: req, from: body)
        guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            if let str = String(data: data, encoding: .utf8) { throw APIError.message(str) }
            throw APIError.invalidResponse
        }
    }

    func uploadVoice(audioURL: URL, token: String) async throws {
        let boundary = "Boundary-\(UUID().uuidString)"
        var req = URLRequest(url: API.base.appendingPathComponent("voiceupload"))
        req.httpMethod = "POST"
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let fileData = try Data(contentsOf: audioURL)
        var body = Data()
        func append(_ s: String) { body.append(s.data(using: .utf8)!) }

        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"voice\"; filename=\"voice.m4a\"\r\n")
        append("Content-Type: audio/mp4\r\n\r\n")
        body.append(fileData)
        append("\r\n--\(boundary)--\r\n")

        let (data, resp) = try await URLSession.shared.upload(for: req, from: body)
        guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            if let str = String(data: data, encoding: .utf8) { throw APIError.message(str) }
            throw APIError.invalidResponse
        }
    }
}
