
import SwiftUI

@main
struct ReChordApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        switch app.route {
        case .splash:
            SplashView()
        case .login:
            LoginView()
        case .register:
            RegisterView()
        case let .otp(email, expected):
            OTPView(email: email, expectedOTP: expected)
        case .home:
            HomeTabView()
        }
    }
}
