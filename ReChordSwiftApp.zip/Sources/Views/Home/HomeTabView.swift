
import SwiftUI

struct HomeTabView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        TabView {
            FeedView()
                .tabItem { Label("Feed", systemImage: "waveform") }
            ProfileView()
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
        }
    }
}

struct FeedView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Welcome to ReChord").font(.title.bold())
                Text("This is a placeholder feed.")
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("ReChord")
        }
    }
}
