
import SwiftUI

struct OTPView: View {
    @EnvironmentObject var app: AppState
    let email: String
    let expectedOTP: String?

    @State private var code: String = ""
    @State private var expected: String?
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Text("Enter the 6‑digit code").font(.title2).bold()
            Text(email).foregroundColor(.secondary)

            TextField("••••••", text: $code)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.center)
                .font(.system(size: 28, weight: .semibold, design: .monospaced))
                .padding()
                .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))

            if let expected = expected {
                // For testing, show the server OTP unobtrusively
                Text("Server OTP (debug): \(expected)").font(.footnote).foregroundColor(.secondary)
            }

            if let error = error { Text(error).foregroundColor(.red).font(.footnote) }

            Button(action: verify) {
                if loading { ProgressView() } else { Text("Continue").bold().frame(maxWidth: .infinity) }
            }
            .disabled(loading || code.isEmpty)
            .buttonStyle(.borderedProminent).controlSize(.large)

            Button("Resend code") { Task { await resend() } }
                .padding(.top, 8)
            Spacer()
        }
        .padding()
        .task {
            expected = expectedOTP
            if expected == nil { await resend() }
        }
    }

    private func resend() async {
        loading = true
        defer { loading = false }
        do {
            let act = try await APIClient.shared.activation(email: email)
            expected = act.otp ?? expected
            app.session.expectedOTP = expected
        } catch {
            self.error = error.localizedDescription
        }
    }

    private func verify() {
        loading = true
        error = nil
        Task {
            do {
                if let exp = expected, exp == code {
                    try await APIClient.shared.activate(email: email)
                    // Auto-login if we have temp password (fresh sign-up)
                    if let pass = app.session.tempPassword {
                        let res = try await APIClient.shared.login(email: email, password: pass)
                        if let token = res.token { Keychain.shared["rechord.token"] = token }
                        app.session.user = res.user
                        app.route = .home
                    } else {
                        // Otherwise return to login so user can sign in
                        app.route = .login
                    }
                } else {
                    self.error = "Incorrect code."
                }
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }
}
