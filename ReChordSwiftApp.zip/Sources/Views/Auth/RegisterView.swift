
import SwiftUI

struct RegisterView: View {
    @EnvironmentObject var app: AppState
    @State private var email = ""
    @State private var password = ""
    @State private var fullName = ""
    @State private var username = ""
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                Text("Welcome").font(.largeTitle).bold().padding(.top, 32)

                Group {
                    TextField("Please enter your email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding().background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                    SecureField("Enter your password", text: $password)
                        .padding().background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                    TextField("Full name", text: $fullName)
                        .padding().background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                    TextField("Choose a username for yourself", text: $username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding().background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                }

                if let error = error { Text(error).foregroundColor(.red) }

                Button(action: submit) {
                    if loading { ProgressView() } else { Text("Continue").bold().frame(maxWidth: .infinity) }
                }
                .disabled(loading || email.isEmpty || password.isEmpty || username.isEmpty)
                .buttonStyle(.borderedProminent).controlSize(.large)
            }
            .padding()
        }
    }

    private func submit() {
        loading = true
        error = nil
        Task {
            do {
                let res = try await APIClient.shared.register(email: email, password: password, fullName: fullName, username: username)
                // Get OTP from register response or fetch via activation
                var otp = res.otp
                if otp == nil {
                    let act = try? await APIClient.shared.activation(email: email)
                    otp = act?.otp
                }
                app.session.emailForOTP = email
                app.session.expectedOTP = otp
                app.session.tempPassword = password
                app.route = .otp(email: email, expected: otp)
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }
}
