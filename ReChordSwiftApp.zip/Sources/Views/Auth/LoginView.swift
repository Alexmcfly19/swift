
import SwiftUI

struct LoginView: View {
    @EnvironmentObject var app: AppState
    @State private var email = ""
    @State private var password = ""
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Text("ReChord")
                .font(.system(size: 40, weight: .bold))
            VStack(spacing: 12) {
                TextField("Enter your email or phone number", text: $email)
                    .textContentType(.username)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                SecureField("Please enter your password", text: $password)
                    .textContentType(.password)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
            }
            if let error = error {
                Text(error).foregroundColor(.red).font(.footnote)
            }
            Button(action: submit) {
                if loading { ProgressView() } else { Text("Continue").bold().frame(maxWidth: .infinity) }
            }
            .disabled(loading || email.isEmpty || password.isEmpty)
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            Button("Don’t have an account? Sign up") {
                app.route = .register
            }
            .padding(.top, 8)
            Spacer()
        }
        .padding()
    }

    private func submit() {
        error = nil
        loading = true
        Task {
            do {
                let res = try await APIClient.shared.login(email: email, password: password)
                if let token = res.token, !token.isEmpty {
                    Keychain.shared["rechord.token"] = token
                }
                if let user = res.user {
                    app.session.user = user
                }
                // If user not active -> show OTP (deferred case)
                if let active = res.user?.is_active, active == false {
                    // request/resend OTP first
                    let act = try? await APIClient.shared.activation(email: email)
                    app.session.emailForOTP = email
                    app.session.expectedOTP = act?.otp
                    app.route = .otp(email: email, expected: act?.otp)
                } else {
                    app.route = .home
                }
            } catch {
                self.error = error.localizedDescription
            }
            loading = false
        }
    }
}
