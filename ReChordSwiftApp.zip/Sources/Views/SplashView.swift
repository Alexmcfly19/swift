
import SwiftUI

struct SplashView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.blue.opacity(0.7), Color.black], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 16) {
                Image(systemName: "play.rectangle.on.rectangle")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 96, height: 96)
                Text("ReChord")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundColor(.white)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            // If there's a token, go home; else login
            if let token = Keychain.shared["rechord.token"], !token.isEmpty {
                app.route = .home
            } else {
                app.route = .login
            }
        }
    }
}
