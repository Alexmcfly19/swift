
import SwiftUI
import UniformTypeIdentifiers

struct ProfileView: View {
    @EnvironmentObject var app: AppState
    @State private var fullName: String = ""
    @State private var username: String = ""
    @State private var phone: String = ""
    @State private var isPrivate: Bool = false
    @State private var uploading = false
    @State private var message: String?
    @State private var showImageImporter = false
    @State private var showAudioImporter = false
    @State private var selectedImageURL: URL?
    @State private var selectedAudioURL: URL?

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Account")) {
                    Text(app.session.user?.email ?? "")
                    TextField("Full name", text: $fullName)
                    TextField("Username", text: $username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Phone", text: $phone)
                    Toggle("Private account", isOn: $isPrivate)
                }

                Section(header: Text("Avatar")) {
                    HStack {
                        if let url = selectedImageURL, let ui = UIImage(contentsOfFile: url.path) {
                            Image(uiImage: ui).resizable().scaledToFill().frame(width: 64, height: 64).clipShape(Circle())
                        } else {
                            Image(systemName: "person.crop.circle.fill").font(.system(size: 64))
                        }
                        Spacer()
                        Button("Select Image") { showImageImporter = true }
                    }
                    Button("Upload Avatar") { Task { await uploadAvatar() } }
                        .disabled(uploading || selectedImageURL == nil)
                }

                Section(header: Text("Voice")) {
                    HStack {
                        Text(selectedAudioURL?.lastPathComponent ?? "No file selected")
                        Spacer()
                        Button("Select Audio") { showAudioImporter = true }
                    }
                    Button("Upload Voice") { Task { await uploadVoice() } }
                        .disabled(uploading || selectedAudioURL == nil)
                }

                if let msg = message {
                    Section { Text(msg).foregroundColor(.secondary) }
                }

                Section {
                    Button("Save Profile") { Task { await saveProfile() } }
                        .disabled(uploading)
                    Button("Sign out", role: .destructive) { app.signOut() }
                }
            }
            .navigationTitle("Profile")
            .onAppear {
                if let u = app.session.user {
                    fullName = u.full_name ?? ""
                    username = u.username ?? ""
                    phone = u.phone ?? ""
                    isPrivate = (u.is_private ?? 0) != 0
                }
            }
            .fileImporter(isPresented: $showImageImporter, allowedContentTypes: [.image]) { result in
                if case let .success(url) = result {
                    selectedImageURL = url
                }
            }
            .fileImporter(isPresented: $showAudioImporter, allowedContentTypes: [UTType(filenameExtension: "m4a")!, .audio]) { result in
                if case let .success(url) = result {
                    selectedAudioURL = url
                }
            }
        }
    }

    private func saveProfile() async {
        guard let token = Keychain.shared["rechord.token"], let id = app.session.user?.id else { return }
        uploading = true
        defer { uploading = false }
        do {
            let updated = try await APIClient.shared.updateClient(id: id, fields: [
                "full_name": fullName,
                "username": username,
                "phone": phone,
                "is_private": isPrivate ? "1" : "0"
            ], token: token)
            app.session.user = updated
            message = "Profile updated."
        } catch { message = error.localizedDescription }
    }

    private func uploadAvatar() async {
        guard let token = Keychain.shared["rechord.token"], let id = app.session.user?.id, let url = selectedImageURL else { return }
        uploading = true
        defer { uploading = false }
        do {
            let data = try Data(contentsOf: url)
            try await APIClient.shared.uploadAvatar(clientId: id, imageData: data, token: token)
            message = "Avatar uploaded."
        } catch { message = error.localizedDescription }
    }

    private func uploadVoice() async {
        guard let token = Keychain.shared["rechord.token"], let url = selectedAudioURL else { return }
        uploading = true
        defer { uploading = false }
        do {
            try await APIClient.shared.uploadVoice(audioURL: url, token: token)
            message = "Voice uploaded."
        } catch { message = error.localizedDescription }
    }
}
