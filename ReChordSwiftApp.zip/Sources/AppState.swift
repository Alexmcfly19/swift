
import Foundation
import SwiftUI

final class AppState: ObservableObject {
    enum Route: Equatable {
        case splash
        case login
        case register
        case otp(email: String, expected: String?)
        case home
    }
    @Published var route: Route = .splash
    @Published var session: Session = Session()

    struct Session {
        var token: String? = Keychain.shared["rechord.token"]
        var user: Client?
        var emailForOTP: String?
        var expectedOTP: String?
        var tempPassword: String? // used to auto-login right after activation
    }

    func signOut() {
        Keychain.shared["rechord.token"] = nil
        session = Session()
        route = .login
    }
}
