import SwiftUI
import AVFoundation
import PhotosUI
import UniformTypeIdentifiers

/// A single-page flow for creating a new ReChord post. Users progress through
/// a sequence of steps: selecting a voice file, entering details, selecting and
/// previewing a cover image, reviewing the final information, and then
/// submitting. Each step is rendered on the same screen with a simple progress
/// indicator at the top. The view leverages ``APIClient`` to upload the
/// voice and image, then calls the create API to publish the post.
struct PostVoiceOnePager: View {
    @EnvironmentObject var app: AppState

    // MARK: Step state
    enum Step: Int { case voice = 0, details = 1, picture = 2, review = 3 }
    @State private var step: Step = .voice

    // Voice
    @State private var voiceURL: URL?
    @State private var showVoicePicker = false
    @State private var voiceData: Data?

    // Details
    @State private var title: String = ""
    @State private var preciseLocation = false
    @State private var latitude: String = ""
    @State private var longitude: String = ""

    // Image
    @State private var selectedImage: UIImage?
    @State private var showImagePicker = false
    @State private var imageApproved = false

    // Progress / errors
    @State private var isSubmitting = false
    @State private var toast: String = ""

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                progressHeader
                Group {
                    switch step {
                    case .voice: voicePickerStep
                    case .details: detailsStep
                    case .picture: imagePickStep
                    case .review: reviewStep
                    }
                }
                .animation(.easeInOut, value: step)
            }
            .padding()
            .navigationTitle("New ReChord")
            .navigationBarTitleDisplayMode(.inline)
            .overlay(alignment: .bottom) {
                if !toast.isEmpty {
                    ToastView(text: toast)
                        .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 2) { toast = "" } }
                }
            }
        }
        .fileImporter(isPresented: $showVoicePicker, allowedContentTypes: [.audio]) { result in
            if case .success(let url) = result {
                do {
                    let data = try Data(contentsOf: url)
                    self.voiceURL = url
                    self.voiceData = data
                    self.toast = "Voice selected"
                    self.step = .details
                } catch {
                    self.toast = "Failed to read voice file"
                }
            }
        }
        .photosPicker(isPresented: $showImagePicker, selection: .constant(nil))
    }

    // MARK: Views

    /// Progress indicator across the top. Shows four dots with labels and a connecting line.
    var progressHeader: some View {
        HStack(spacing: 8) {
            stepDot(index: 0, label: "Voice")
            Rectangle().frame(height: 2).opacity(0.2)
            stepDot(index: 1, label: "Details")
            Rectangle().frame(height: 2).opacity(0.2)
            stepDot(index: 2, label: "Picture")
            Rectangle().frame(height: 2).opacity(0.2)
            stepDot(index: 3, label: "Review")
        }
    }

    func stepDot(index: Int, label: String) -> some View {
        let active = step.rawValue >= index
        return VStack {
            Circle().fill(active ? Color.accentColor : Color.gray.opacity(0.25))
                .frame(width: 10, height: 10)
            Text(label).font(.caption2)
        }
    }

    // Step 1: Pick or record a voice file
    var voicePickerStep: some View {
        VStack(spacing: 16) {
            if let url = voiceURL {
                VStack {
                    Text(url.lastPathComponent)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    PrimaryButton(title: "Choose another voice") {
                        showVoicePicker = true
                    }
                }
            } else {
                Image(systemName: "waveform").font(.system(size: 40))
                Text("Pick a voice file to upload").foregroundStyle(.secondary)
                PrimaryButton(title: "Pick voice") { showVoicePicker = true }
            }
            Spacer()
            HStack {
                Spacer()
                PrimaryButton(title: "Next", disabled: voiceData == nil) {
                    step = .details
                }
            }
        }
    }

    // Step 2: Enter title and optional location
    var detailsStep: some View {
        VStack(spacing: 12) {
            // Title field
            TextField("Title", text: $title)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .padding(.horizontal, 16)
                .frame(height: 48)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
            // Precise location toggle
            Toggle("Precise Location", isOn: $preciseLocation)
            // Latitude/Longitude fields
            HStack {
                TextField("Latitude", text: $latitude)
                    .keyboardType(.numbersAndPunctuation)
                    .padding(.horizontal, 16)
                    .frame(height: 48)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                TextField("Longitude", text: $longitude)
                    .keyboardType(.numbersAndPunctuation)
                    .padding(.horizontal, 16)
                    .frame(height: 48)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
            }
            .opacity(preciseLocation ? 1 : 0.35)
            .disabled(!preciseLocation)
            Spacer()
            HStack {
                SecondaryButton(title: "Back") { step = .voice }
                Spacer()
                PrimaryButton(title: "Next", disabled: title.isEmpty) { step = .picture }
            }
        }
    }

    // Step 3: Pick image and preview with Approve / Retry / Cancel
    var imagePickStep: some View {
        VStack(spacing: 12) {
            if let img = selectedImage {
                VStack(spacing: 10) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 240)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    HStack {
                        SecondaryButton(title: "Cancel") {
                            selectedImage = nil
                            imageApproved = false
                        }
                        SecondaryButton(title: "Retry") {
                            showImagePicker = true
                            imageApproved = false
                        }
                        PrimaryButton(title: imageApproved ? "Approved" : "Approve", disabled: imageApproved) {
                            imageApproved = true
                        }
                    }
                }
            } else {
                Image(systemName: "photo.on.rectangle").font(.system(size: 40))
                Text("Pick a cover picture (optional)").foregroundStyle(.secondary)
                PrimaryButton(title: "Pick picture") { presentPHPicker() }
            }
            Spacer()
            HStack {
                SecondaryButton(title: "Back") { step = .details }
                Spacer()
                PrimaryButton(title: "Next", disabled: selectedImage == nil || !imageApproved) { step = .review }
            }
        }
    }

    // Step 4: Review and submit
    var reviewStep: some View {
        VStack(alignment: .leading, spacing: 16) {
            GroupBox {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Title: \(title)")
                    if preciseLocation {
                        Text("Location: \(latitude), \(longitude)")
                    } else {
                        Text("Location: Not precise")
                    }
                    if let url = voiceURL {
                        Text("Voice: \(url.lastPathComponent)")
                    }
                }
            }
            if let img = selectedImage {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            Spacer()
            HStack {
                SecondaryButton(title: "Back") { step = .picture }
                Spacer()
                PrimaryButton(title: isSubmitting ? "Submitting..." : "Submit", disabled: isSubmitting) {
                    Task { await submit() }
                }
            }
        }
    }

    // MARK: Helpers

    private func presentPHPicker() {
        #if canImport(PhotosUI)
        showImagePicker = true
        #endif
    }

    private func submit() async {
        guard let token = app.token else {
            toast = "Missing token"
            return
        }
        guard let voiceData else {
            toast = "No voice selected"
            return
        }
        isSubmitting = true
        defer { isSubmitting = false }
        do {
            // Upload voice and image
            let voiceLink = try await APIClient.shared.uploadVoice(voiceData: voiceData, token: token)
            var pictureLink: String = "0"
            if imageApproved, let img = selectedImage, let jpeg = img.jpegData(compressionQuality: 0.9) {
                pictureLink = try await APIClient.shared.uploadImage(imageData: jpeg, token: token)
            }
            // Determine owner ID. Attempt to use the currentUserId stored in AppState, fallback to 0.
            let ownerId = app.currentUserId ?? 0
            let posX = Double(latitude) ?? 0
            let posY = Double(longitude) ?? 0
            let precise = preciseLocation ? "1" : "0"
            try await APIClient.shared.createVoice(ownerId: ownerId,
                                                   title: title,
                                                   preciseLocation: precise,
                                                   positionX: posX,
                                                   positionY: posY,
                                                   voiceLink: voiceLink,
                                                   pictureLink: pictureLink,
                                                   token: token)
            toast = "Posted!"
            // Reset state
            step = .voice
            voiceURL = nil
            voiceData = nil
            title = ""
            selectedImage = nil
            imageApproved = false
        } catch {
            toast = error.localizedDescription
        }
    }
}

// MARK: - Button helpers

fileprivate struct PrimaryButton: View {
    var title: String
    var disabled: Bool = false
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
        }
        .buttonStyle(.borderedProminent)
        .disabled(disabled)
    }
}

fileprivate struct SecondaryButton: View {
    var title: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
        }
        .buttonStyle(.bordered)
    }
}
