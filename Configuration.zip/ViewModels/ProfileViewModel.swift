
import Foundation
import UIKit
import AVFoundation

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var user: User?
    @Published var fullName: String = ""
    @Published var username: String = ""
    @Published var phone: String = ""
    @Published var website: String = ""
    @Published var isPrivate: Bool = false
    @Published var allowLocation: Bool = false
    @Published var languages: [String] = ["English"]
    
    @Published var isLoading = false
    @Published var error: String?
    @Published var success: String?
    
    func loadMe() async {
        isLoading = true; defer { isLoading = false }
        do {
            let u = try await APIClient.shared.send(Endpoints.me())
            user = u
            fullName = u.fullName
            username = u.username
            phone = u.phone ?? ""
            website = u.website ?? ""
            isPrivate = u.isPrivate ?? false
            allowLocation = u.allowLocation ?? false
            languages = u.languages ?? ["English"]
        } catch {
            self.error = "Failed to load profile."
        }
    }
    
    func save() async {
        isLoading = true; defer { isLoading = false }
        do {
            let req = UpdateProfileRequest(
                full_name: fullName,
                username: username,
                phone: phone.isEmpty ? nil : phone,
                website: website.isEmpty ? nil : website,
                is_private: isPrivate,
                allow_location: allowLocation,
                languages: languages
            )
            let u = try await APIClient.shared.send(Endpoints.updateProfile(req))
            user = u
            success = "Profile updated"
        } catch {
            self.error = "Failed to update. \(error.localizedDescription)"
        }
    }
    
    func uploadAvatar(image: UIImage) async {
        isLoading = true; defer { isLoading = false }
        do {
            guard let data = image.jpegData(compressionQuality: 0.85) else {
                self.error = "Could not read image data"; return
            }
            let req = Endpoints.uploadAvatar(data: data)
            let res = try await APIClient.shared.upload(request: req)
            if res.success { success = "Avatar uploaded" } else { error = res.message ?? "Avatar upload failed" }
        } catch {
            self.error = "Avatar upload error. \(error.localizedDescription)"
        }
    }
    
    func uploadVoice(fileURL: URL) async {
        isLoading = true; defer { isLoading = false }
        do {
            let data = try Data(contentsOf: fileURL)
            let req = Endpoints.uploadVoice(data: data, filename: fileURL.lastPathComponent)
            let res = try await APIClient.shared.upload(request: req)
            if res.success { success = "Voice uploaded" } else { error = res.message ?? "Voice upload failed" }
        } catch {
            self.error = "Voice upload error. \(error.localizedDescription)"
        }
    }
}
