
import Foundation

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var fullName: String = ""
    @Published var username: String = ""
    @Published var isLoading: Bool = false
    @Published var error: String?
    @Published var otpCode: String = ""
    
    // persistence
    @Published var isActivated: Bool = UserDefaults.standard.bool(forKey: "isActivated") {
        didSet { UserDefaults.standard.set(isActivated, forKey: "isActivated") }
    }
    @Published var pendingEmail: String? = UserDefaults.standard.string(forKey: "pendingEmail") {
        didSet { UserDefaults.standard.set(pendingEmail, forKey: "pendingEmail") }
    }
    
    func login() async -> Bool {
        error = nil; isLoading = true
        defer { isLoading = false }
        do {
            let res = try await APIClient.shared.send(Endpoints.login(email: email, password: password))
            APIClient.shared.accessToken = res.accessToken
            isActivated = res.isActivated
            pendingEmail = res.email
            return true
        } catch {
            self.error = "Login failed. \(error.localizedDescription)"
            return false
        }
    }
    
    func register() async -> Bool {
        error = nil; isLoading = true
        defer { isLoading = false }
        do {
            let req = RegisterRequest(email: email, password: password, username: username, full_name: fullName)
            let res = try await APIClient.shared.send(Endpoints.register(req: req))
            // Server returns OTP (usually via email/SMS). Save email for OTP step.
            pendingEmail = res.email
            return true
        } catch {
            self.error = "Registration failed. \(error.localizedDescription)"
            return false
        }
    }
    
    func verifyOTPAndActivate(email: String, otp: String) async -> Bool {
        error = nil; isLoading = true
        defer { isLoading = false }
        do {
            // First verify OTP
            let verify = try await APIClient.shared.send(Endpoints.verifyOTP(email: email, otp: otp))
            guard verify.success else {
                self.error = verify.message ?? "Invalid OTP"
                return false
            }
            // Then activate (email only)
            let activated = try await APIClient.shared.send(Endpoints.activate(email: email))
            if activated.success {
                isActivated = true
                return true
            } else {
                self.error = activated.message ?? "Activation failed"
                return false
            }
        } catch {
            self.error = "OTP/Activation failed. \(error.localizedDescription)"
            return false
        }
    }
    
    func logout() {
        APIClient.shared.accessToken = nil
        isActivated = false
        pendingEmail = nil
        email = ""; password = ""; fullName = ""; username = ""
    }
}
