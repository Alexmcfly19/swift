
import Foundation

enum Route: Equatable {
    case splash
    case login
    case register
    case otp(email: String)
    case home
}

@MainActor
final class AppState: ObservableObject {
    @Published var route: Route = .splash
    
    func decideInitialRoute(isLoggedIn: Bool, isActivated: Bool, pendingEmail: String?) {
        if !isLoggedIn {
            self.route = .login
        } else if !isActivated, let email = pendingEmail {
            self.route = .otp(email: email)
        } else {
            self.route = .home
        }
    }
}
