
import Foundation

struct User: Codable, Identifiable, Equatable {
    var id: String
    var email: String
    var username: String
    var fullName: String
    var phone: String?
    var website: String?
    var isPrivate: Bool?
    var allowLocation: Bool?
    var languages: [String]?
    var aboutVoiceURL: URL?
    var avatarURL: URL?
    
    enum CodingKeys: String, CodingKey {
        case id, email, username
        case fullName = "full_name"
        case phone, website
        case isPrivate = "is_private"
        case allowLocation = "allow_location"
        case languages
        case aboutVoiceURL = "about_voice_url"
        case avatarURL = "avatar_url"
    }
}

struct AuthToken: Codable {
    let accessToken: String
    let isActivated: Bool
    let email: String
}

struct RegisterRequest: Codable {
    let email: String
    let password: String
    let username: String
    let full_name: String
}

struct RegisterResponse: Codable {
    let otpToken: String?   // optional (if server sends token/nonce with OTP)
    let email: String
    let message: String?
}

struct LoginResponse: Codable {
    let accessToken: String
    let isActivated: Bool
    let email: String
}

struct OTPVerifyRequest: Codable {
    let email: String
    let otp: String
}

struct ActivationResponse: Codable {
    let success: Bool
    let message: String?
}

struct UpdateProfileRequest: Codable {
    var full_name: String
    var username: String
    var phone: String?
    var website: String?
    var is_private: Bool?
    var allow_location: Bool?
    var languages: [String]?
}
