
import Foundation

enum API {
    static let baseURL = URL(string: "https://YOUR_API_BASE")!  // <- change me
    static let timeout: TimeInterval = 20
    static let debug: Bool = true
    
    enum Path {
        static let login = "/auth/login"
        static let register = "/auth/register"
        static let verifyOTP = "/auth/verify-otp"
        static let activate = "/auth/activate"           // accepts { "email": String }
        static let updateProfile = "/user/update"
        static let uploadAvatar = "/user/avatar"          // multipart/form-data
        static let uploadVoice = "/user/voice"            // multipart/form-data
        static let me = "/user/me"
    }
}

enum Constants {
    static let appDisplayName = "ReChord"
    static let otpDigits = 6
    static let splashDurationSec: UInt64 = 3
}
