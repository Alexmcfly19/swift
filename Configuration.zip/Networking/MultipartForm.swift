
import Foundation

struct MultipartForm {
    struct Part {
        let name: String
        let filename: String?
        let mime: String?
        let data: Data
    }
    
    private let boundary = "Boundary-\(UUID().uuidString)"
    private var parts: [Part] = []
    
    mutating func add(name: String, value: String) {
        parts.append(Part(name: name, filename: nil, mime: nil, data: Data(value.utf8)))
    }
    
    mutating func addFile(name: String, filename: String, mime: String, data: Data) {
        parts.append(Part(name: name, filename: filename, mime: mime, data: data))
    }
    
    func encode() -> (Data, String) {
        var body = Data()
        for p in parts {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            if let filename = p.filename, let mime = p.mime {
                body.append("Content-Disposition: form-data; name=\"\(p.name)\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
                body.append("Content-Type: \(mime)\r\n\r\n".data(using: .utf8)!)
                body.append(p.data)
                body.append("\r\n".data(using: .utf8)!)
            } else {
                body.append("Content-Disposition: form-data; name=\"\(p.name)\"\r\n\r\n".data(using: .utf8)!)
                body.append(p.data)
                body.append("\r\n".data(using: .utf8)!)
            }
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        return (body, "multipart/form-data; boundary=\(boundary)")
    }
}
