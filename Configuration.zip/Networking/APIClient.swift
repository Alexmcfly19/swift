
import Foundation

struct Endpoint<T: Decodable> {
    let path: String
    var method: String = "GET"
    var headers: [String: String] = ["Content-Type": "application/json"]
    var body: Data? = nil
    var requiresAuth: Bool = false
    var decode: (Data) throws -> T = { data in
        try JSONDecoder().decode(T.self, from: data)
    }
}

enum Endpoints {
    static func login(email: String, password: String) throws -> Endpoint<LoginResponse> {
        let body = try JSONSerialization.data(withJSONObject: ["email": email, "password": password])
        return Endpoint(path: API.Path.login, method: "POST", body: body)
    }
    
    static func register(req: RegisterRequest) throws -> Endpoint<RegisterResponse> {
        let body = try JSONEncoder().encode(req)
        return Endpoint(path: API.Path.register, method: "POST", body: body)
    }
    
    static func verifyOTP(email: String, otp: String) throws -> Endpoint<ActivationResponse> {
        let body = try JSONEncoder().encode(OTPVerifyRequest(email: email, otp: otp))
        return Endpoint(path: API.Path.verifyOTP, method: "POST", body: body)
    }
    
    static func activate(email: String) throws -> Endpoint<ActivationResponse> {
        let body = try JSONSerialization.data(withJSONObject: ["email": email])
        return Endpoint(path: API.Path.activate, method: "POST", body: body)
    }
    
    static func me() -> Endpoint<User> {
        Endpoint(path: API.Path.me, method: "GET", requiresAuth: true)
    }
    
    static func updateProfile(_ req: UpdateProfileRequest) throws -> Endpoint<User> {
        let body = try JSONEncoder().encode(req)
        return Endpoint(path: API.Path.updateProfile, method: "POST", body: body, requiresAuth: true)
    }
    
    static func uploadAvatar(data: Data, filename: String = "avatar.jpg") -> URLRequest {
        var form = MultipartForm()
        form.addFile(name: "file", filename: filename, mime: "image/jpeg", data: data)
        let (body, contentType) = form.encode()
        var url = API.baseURL
        url.appendPathComponent(API.Path.uploadAvatar)
        var req = URLRequest(url: url, timeoutInterval: API.timeout)
        req.httpMethod = "POST"
        req.addValue(contentType, forHTTPHeaderField: "Content-Type")
        if let token = APIClient.shared.accessToken {
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        req.httpBody = body
        return req
    }
    
    static func uploadVoice(data: Data, filename: String = "voice.m4a") -> URLRequest {
        var form = MultipartForm()
        form.addFile(name: "file", filename: filename, mime: "audio/m4a", data: data)
        let (body, contentType) = form.encode()
        var url = API.baseURL
        url.appendPathComponent(API.Path.uploadVoice)
        var req = URLRequest(url: url, timeoutInterval: API.timeout)
        req.httpMethod = "POST"
        req.addValue(contentType, forHTTPHeaderField: "Content-Type")
        if let token = APIClient.shared.accessToken {
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        req.httpBody = body
        return req
    }
}

final class APIClient {
    static let shared = APIClient()
    private init() {}
    
    var accessToken: String? {
        get {
            if let data = Keychain.get(SecureStoreKey.accessToken) {
                return String(data: data, encoding: .utf8)
            }
            return nil
        }
        set {
            if let newValue = newValue {
                Keychain.set(Data(newValue.utf8), for: SecureStoreKey.accessToken)
            } else {
                Keychain.remove(SecureStoreKey.accessToken)
            }
        }
    }
    
    func send<T: Decodable>(_ endpoint: Endpoint<T>) async throws -> T {
        var url = API.baseURL
        url.appendPathComponent(endpoint.path)
        var req = URLRequest(url: url, timeoutInterval: API.timeout)
        req.httpMethod = endpoint.method
        endpoint.headers.forEach { k, v in req.addValue(v, forHTTPHeaderField: k) }
        if endpoint.requiresAuth, let token = accessToken {
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        req.httpBody = endpoint.body
        
        if API.debug {
            print("➡️ \(req.httpMethod ?? "GET") \(req.url!.absoluteString)")
            if let headers = req.allHTTPHeaderFields { print("Headers:", headers) }
            if let body = req.httpBody, let s = String(data: body, encoding: .utf8) { print("Body:", s) }
        }
        
        let (data, resp) = try await URLSession.shared.data(for: req)
        
        if API.debug {
            if let r = resp as? HTTPURLResponse { print("⬅️ Status:", r.statusCode) }
            if let s = String(data: data, encoding: .utf8) {
                print("Response:", s)
            }
        }
        
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return try endpoint.decode(data)
    }
    
    func upload(request: URLRequest) async throws -> ActivationResponse {
        let (data, resp) = try await URLSession.shared.data(for: request)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(ActivationResponse.self, from: data)
    }
}
