
import SwiftUI

struct RegisterView: View {
    @EnvironmentObject var app: AppState
    @EnvironmentObject var auth: AuthViewModel
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("Welcome").font(.largeTitle.bold())
                TextField("Please Enter Your Email", text: $auth.email)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                SecureField("Enter your Password", text: $auth.password)
                    .textContentType(.newPassword)
                    .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                TextField("Full Name", text: $auth.fullName)
                    .textContentType(.name)
                    .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                TextField("Choose a Username for Yourself", text: $auth.username)
                    .textInputAutocapitalization(.never)
                    .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                
                if let err = auth.error { Text(err).foregroundColor(.red) }
                
                Button {
                    Task {
                        if await auth.register() {
                            if let email = auth.pendingEmail {
                                app.route = .otp(email: email)
                            }
                        }
                    }
                } label: {
                    Text(auth.isLoading ? "Please wait…" : "Continue")
                        .frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }.disabled(auth.isLoading)
            }
            .padding()
        }
    }
}
