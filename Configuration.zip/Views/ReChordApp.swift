
import SwiftUI

@main
struct ReChordApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var auth = AuthViewModel()
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(auth)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var app: AppState
    @EnvironmentObject var auth: AuthViewModel
    
    var body: some View {
        Group {
            switch app.route {
            case .splash: SplashView()
            case .login: LoginView()
            case .register: RegisterView()
            case .otp(let email): OTPView(email: email)
            case .home: MainTabView()
            }
        }
        .task(id: app.route) {
            // noop
        }
        .onAppear {
            Task {
                try? await Task.sleep(nanoseconds: Constants.splashDurationSec * 1_000_000_000)
                let loggedIn = APIClient.shared.accessToken != nil
                app.decideInitialRoute(isLoggedIn: loggedIn, isActivated: auth.isActivated, pendingEmail: auth.pendingEmail)
            }
        }
    }
}
