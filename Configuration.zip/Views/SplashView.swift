
import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color.blue.opacity(0.7)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 20) {
                Image(systemName: "waveform.circle.fill").font(.system(size: 72))
                Text("ReChord").font(.largeTitle.bold()).foregroundColor(.white)
            }
        }
        .accessibilityIdentifier("SplashView")
    }
}
