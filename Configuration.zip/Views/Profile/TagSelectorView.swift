
import SwiftUI

struct TagSelectorView: View {
    @Binding var tags: [String]
    @State private var newTag: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(tags, id: \.self) { tag in
                        HStack(spacing: 6) {
                            Text(tag)
                            Image(systemName: "xmark.circle.fill")
                                .onTapGesture { tags.removeAll { $0 == tag } }
                        }
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color(.systemGray6))
                        .clipShape(Capsule())
                    }
                }
            }
            HStack {
                TextField("Add language…", text: $newTag)
                Button("Add") {
                    let trimmed = newTag.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !trimmed.isEmpty else { return }
                    if !tags.contains(trimmed) { tags.append(trimmed) }
                    newTag = ""
                }
            }
        }
    }
}
