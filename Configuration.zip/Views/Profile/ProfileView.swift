
import SwiftUI

struct ProfileView: View {
    @StateObject private var vm = ProfileViewModel()
    @State private var showImagePicker = false
    @State private var pickedImage: UIImage?
    @StateObject private var recorder = AudioRecorder()
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 18) {
                    // Avatar & handles
                    HStack(spacing: 16) {
                        Button {
                            showImagePicker = true
                        } label: {
                            Group {
                                if let img = pickedImage {
                                    Image(uiImage: img).resizable().scaledToFill()
                                } else {
                                    Image(systemName: "person.crop.circle.fill").resizable().scaledToFit()
                                }
                            }
                            .frame(width: 72, height: 72)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(lineWidth: 1).foregroundColor(.secondary))
                        }
                        VStack(alignment: .leading, spacing: 8) {
                            TextField("Full name", text: $vm.fullName).font(.headline)
                            TextField("@username", text: $vm.username)
                                .textInputAutocapitalization(.never)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    
                    // About me voice
                    VStack(alignment: .leading, spacing: 12) {
                        Text("About me").font(.headline)
                        HStack(spacing: 16) {
                            Button(recorder.isRecording ? "Stop" : "Record") {
                                if recorder.isRecording { recorder.stopRecording() }
                                else { try? recorder.startRecording() }
                            }.buttonStyle(.borderedProminent)
                            
                            Button(recorder.isPlaying ? "Stop" : "Play") {
                                if recorder.isPlaying { recorder.stop() }
                                else { try? recorder.play() }
                            }.buttonStyle(.bordered)
                            .disabled(recorder.recordedURL == nil)
                            
                            Spacer()
                            if let url = recorder.recordedURL {
                                Button("Upload") {
                                    Task { await vm.uploadVoice(fileURL: url) }
                                }.disabled(vm.isLoading)
                            }
                        }
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    
                    // Contact options
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Contact Options").font(.headline)
                        TextField("Phone", text: $vm.phone)
                            .keyboardType(.phonePad)
                            .padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 12))
                        TextField("Email (read-only)", text: .constant(vm.user?.email ?? ""))
                            .disabled(true)
                            .padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 12))
                        TextField("Website", text: $vm.website)
                            .keyboardType(.URL).textInputAutocapitalization(.never)
                            .padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    
                    // Language preference & toggles
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Language Preference").font(.headline)
                        TagSelectorView(tags: $vm.languages)
                        Toggle("Private Account", isOn: $vm.isPrivate)
                        Toggle("Location Permission", isOn: $vm.allowLocation)
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    
                    // Save + avatar upload
                    HStack(spacing: 12) {
                        Button("Save Profile") {
                            Task { await vm.save() }
                        }.buttonStyle(.borderedProminent).disabled(vm.isLoading)
                        
                        if let img = pickedImage {
                            Button("Upload Avatar") {
                                Task { await vm.uploadAvatar(image: img) }
                            }.buttonStyle(.bordered)
                        }
                    }
                    
                    if vm.isLoading { ProgressView().padding(.top, 8) }
                    if let s = vm.success { Text(s).foregroundColor(.green) }
                    if let e = vm.error { Text(e).foregroundColor(.red) }
                }
                .padding()
            }
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Reload") { Task { await vm.loadMe() } }
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: $pickedImage)
            }
            .task { await vm.loadMe() }
        }
    }
}
