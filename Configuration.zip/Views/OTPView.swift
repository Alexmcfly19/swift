
import SwiftUI

struct OTPView: View {
    @EnvironmentObject var app: AppState
    @EnvironmentObject var auth: AuthViewModel
    let email: String
    
    @State private var codes: [String] = Array(repeating: "", count: Constants.otpDigits)
    @FocusState private var focusedIndex: Int?
    
    var otpJoined: String { codes.joined() }
    
    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Text("Enter the code we sent to").font(.headline)
            Text(email).font(.subheadline).foregroundColor(.secondary)
            HStack(spacing: 8) {
                ForEach(0..<Constants.otpDigits, id: \.self) { idx in
                    TextField("", text: $codes[idx])
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.center)
                        .frame(width: 44, height: 52)
                        .background(Color(.systemGray6))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .focused($focusedIndex, equals: idx)
                        .onChange(of: codes[idx]) { _, new in
                            if new.count > 1 { codes[idx] = String(new.last!) }
                            if !new.isEmpty && idx < Constants.otpDigits-1 {
                                focusedIndex = idx+1
                            }
                        }
                }
            }
            if let err = auth.error { Text(err).foregroundColor(.red) }
            Button {
                Task {
                    if await auth.verifyOTPAndActivate(email: email, otp: otpJoined) {
                        app.route = .home
                    }
                }
            } label: {
                Text(auth.isLoading ? "Checking…" : "Continue")
                    .frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }.disabled(auth.isLoading || otpJoined.count != Constants.otpDigits)
            
            Button("Resend it") {
                Task {
                    // Simply call activate again with email (per your flow)
                    _ = try? await APIClient.shared.send(Endpoints.activate(email: email))
                }
            }
            Spacer()
        }.padding()
        .onAppear { focusedIndex = 0 }
    }
}
