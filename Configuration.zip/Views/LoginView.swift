
import SwiftUI

struct LoginView: View {
    @EnvironmentObject var app: AppState
    @EnvironmentObject var auth: AuthViewModel
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Spacer()
                Text("ReChord").font(.largeTitle.bold())
                
                VStack(spacing: 12) {
                    TextField("Enter your email or phone number", text: $auth.email)
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .padding()
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                    
                    SecureField("Please enter your Password", text: $auth.password)
                        .textContentType(.password)
                        .padding()
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
                
                if let err = auth.error {
                    Text(err).foregroundColor(.red).font(.footnote)
                }
                
                Button {
                    Task {
                        if await auth.login() {
                            if auth.isActivated {
                                app.route = .home
                            } else if let email = auth.pendingEmail {
                                app.route = .otp(email: email)
                            }
                        }
                    }
                } label: {
                    Text(auth.isLoading ? "Please wait…" : "Continue")
                        .frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }.disabled(auth.isLoading)
                
                Button("Don't have an account? Sign up") {
                    app.route = .register
                }.padding(.top, 8)
                Spacer()
            }
            .padding()
        }
    }
}
