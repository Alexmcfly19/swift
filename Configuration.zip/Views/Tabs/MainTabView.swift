
import SwiftUI

struct MainTabView: View {
    @State private var selected = 0
    @State private var showRecorder = false
    
    var body: some View {
        ZStack {
            TabView(selection: $selected) {
                HomeView().tabItem { Label("Home", systemImage: "house") }.tag(0)
                MentionsView().tabItem { Label("Mentions", systemImage: "at") }.tag(1)
                ProfileView().tabItem { Label("Profile", systemImage: "person.circle") }.tag(2)
            }
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button {
                        showRecorder.toggle()
                    } label: {
                        Image(systemName: "record.circle.fill")
                            .font(.system(size: 64))
                            .shadow(radius: 6)
                    }
                    .padding(.bottom, 20)
                    .sheet(isPresented: $showRecorder) {
                        RecorderSheet()
                    }
                    Spacer()
                }
            }.allowsHitTesting(false) // display-only, record button on each screen present via toolbar
        }
    }
}

struct HomeView: View {
    var body: some View {
        NavigationView {
            List {
                Text("Welcome to ReChord!")
                Text("This is your home feed.")
            }.navigationTitle("Home")
        }
    }
}

struct MentionsView: View {
    var body: some View {
        NavigationView {
            List { Text("@mentions will appear here.") }
                .navigationTitle("Mentions")
        }
    }
}

struct RecorderSheet: View {
    @StateObject var rec = AudioRecorder()
    var body: some View {
        VStack(spacing: 16) {
            Text("Quick Recorder").font(.headline)
            HStack(spacing: 24) {
                Button(rec.isRecording ? "Stop" : "Record") {
                    if rec.isRecording {
                        rec.stopRecording()
                    } else {
                        try? rec.startRecording()
                    }
                }.buttonStyle(.borderedProminent)
                
                Button(rec.isPlaying ? "Stop" : "Play") {
                    if rec.isPlaying { rec.stop() } else { try? rec.play() }
                }.buttonStyle(.bordered)
                .disabled(rec.recordedURL == nil)
            }
            if let url = rec.recordedURL {
                Text("Saved: \(url.lastPathComponent)").font(.footnote).foregroundColor(.secondary)
            }
            Spacer()
        }.padding()
    }
}
