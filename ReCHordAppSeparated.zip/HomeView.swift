import SwiftUI

struct HomeView: View {
    var body: some View {
        TabView {
            Text("Home Page")
                .tabItem {
                    Label("Home", systemImage: "house")
                }
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.circle")
                }
        }
    }
}