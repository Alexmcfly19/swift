import Foundation

struct OTPAPI {
    static func verify(code: String, completion: @escaping (Bool, String?) -> Void) {
        guard let url = URL(string: "https://yourapi.com/verify-otp") else {
            completion(false, "Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = ["otp": code]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(false, error.localizedDescription)
                return
            }
            
            guard let data = data else {
                completion(false, "No data received")
                return
            }
            
            // TODO: Parse your real API response here
            let responseString = String(data: data, encoding: .utf8) ?? ""
            print("OTP API Response: \(responseString)")
            
            if responseString.contains("success") {
                completion(true, nil)
            } else {
                completion(false, "Invalid OTP")
            }
        }.resume()
    }
}