import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .foregroundColor(.blue)
            
            Text("User Profile")
                .font(.title)
                .fontWeight(.bold)
            
            Spacer()
        }
        .padding()
    }
}