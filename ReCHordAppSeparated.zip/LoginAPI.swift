import Foundation

struct LoginAPI {
    static func login(email: String, password: String, completion: @escaping (Bool, Bool, String?) -> Void) {
        guard let url = URL(string: "https://yourapi.com/login") else {
            completion(false, false, "Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = ["email": email, "password": password]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(false, false, error.localizedDescription)
                return
            }
            
            guard let data = data else {
                completion(false, false, "No data received")
                return
            }
            
            // TODO: Parse your real API response here
            let responseString = String(data: data, encoding: .utf8) ?? ""
            print("Login API Response: \(responseString)")
            
            // Example logic (replace with real API handling)
            if responseString.contains("otp_required") {
                completion(true, true, nil)
            } else if responseString.contains("success") {
                completion(true, false, nil)
            } else {
                completion(false, false, "Invalid credentials")
            }
        }.resume()
    }
}