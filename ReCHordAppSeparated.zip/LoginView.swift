import SwiftUI

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var showRegister = false
    @State private var showHome = false
    @State private var showOTP = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Login")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
            
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            Button("Login") {
                LoginAPI.login(email: email, password: password) { success, requiresOTP, error in
                    if let error = error {
                        errorMessage = error
                        return
                    }
                    if success {
                        if requiresOTP {
                            showOTP = true
                        } else {
                            showHome = true
                        }
                    }
                }
            }
            .padding()
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
            }
            
            Button("Register") {
                showRegister = true
            }
            .padding(.top, 20)
        }
        .padding()
        .fullScreenCover(isPresented: $showRegister) {
            RegisterView()
        }
        .fullScreenCover(isPresented: $showOTP) {
            OTPView()
        }
        .fullScreenCover(isPresented: $showHome) {
            HomeView()
        }
    }
}