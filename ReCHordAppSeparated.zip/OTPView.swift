import SwiftUI

struct OTPView: View {
    @State private var code = ""
    @State private var showLogin = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Enter OTP")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("OTP Code", text: $code)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
            
            Button("Verify") {
                OTPAPI.verify(code: code) { success, error in
                    if let error = error {
                        errorMessage = error
                        return
                    }
                    if success {
                        showLogin = true
                    }
                }
            }
            .padding()
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
            }
        }
        .padding()
        .fullScreenCover(isPresented: $showLogin) {
            LoginView()
        }
    }
}