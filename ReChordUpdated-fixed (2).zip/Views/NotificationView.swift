import SwiftUI

/// A view that presents user notifications and their own published ReChords in a two‑tab interface.
///
/// The first tab shows likes and comments on the user's ReChords by consuming the
/// `/clients/{id}/notifications` endpoint. The second tab lists the user's own
/// ReChords by calling the `/voices/{id}/{page}/ShowUserVoices` endpoint.
///
/// This view relies on ``AppState`` to obtain the current user's identifier and
/// authentication token. On first appearance it will automatically fetch
/// notifications and ReChords in parallel. If either request fails the error
/// message is displayed at the bottom of the list. You can pull down to
/// refresh either tab.
struct NotificationView: View {
    @EnvironmentObject private var app: AppState
    @State private var selectedTab: Int = 0
    @State private var notifications: [[String: Any]] = []
    @State private var myVoices: [[String: Any]] = []
    @State private var isLoading: Bool = false
    @State private var error: String?
    
    private enum Tab: Int, CaseIterable {
        case notifications = 0
        case voices = 1
        
        var title: String {
            switch self {
            case .notifications: return "Notifications"
            case .voices: return "My ReChords"
            }
        }
    }
    
    var body: some View {
        ZStack {
            // Background imagery to match the rest of the app
            Image("bg-earth-2")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.25))
            
            VStack(spacing: 16) {
                // Title
                Text("ReChord")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .shadow(radius: 6)
                    .padding(.top, 8)
                
                // Segmented control for tabs
                Picker(selection: $selectedTab) {
                    // Iterate over tabs by their case; use `.self` for id since
                    // `Tab` conforms to `Hashable` via `CaseIterable`.
                    ForEach(Tab.allCases, id: \.self) { tab in
                        Text(tab.title).tag(tab.rawValue)
                    }
                } label: {
                    EmptyView()
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .onChange(of: selectedTab) { _ in
                    Task { await refreshCurrentTab() }
                }
                
                // List contents
                if selectedTab == Tab.notifications.rawValue {
                    notificationList
                } else {
                    voiceList
                }
                
                // Error / loading indicator
                if isLoading {
                    ProgressView().padding()
                }
                if let error = error {
                    Text(error)
                        .foregroundStyle(.red)
                        .font(.footnote)
                        .padding(.horizontal)
                }
            }
        }
        .onAppear {
            // Only load once when the view appears
            if notifications.isEmpty && myVoices.isEmpty {
                Task { await refreshAll() }
            }
        }
    }
    
    // MARK: - Subviews
    private var notificationList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(notifications.indices, id: \.self) { index in
                    let item = notifications[index]
                    NotificationRow(item: item)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
    }
    
    private var voiceList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(myVoices.indices, id: \.self) { index in
                    let voice = myVoices[index]
                    VoiceRow(item: voice)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
    }
    
    // MARK: - Networking
    /// Reload both tabs simultaneously
    private func refreshAll() async {
        isLoading = true
        error = nil
        async let n = fetchNotifications()
        async let v = fetchVoices()
        do {
            notifications = try await n
            myVoices = try await v
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }
    
    /// Reload only the currently visible tab
    private func refreshCurrentTab() async {
        isLoading = true
        error = nil
        switch Tab(rawValue: selectedTab) {
        case .notifications:
            do { notifications = try await fetchNotifications() } catch { self.error = error.localizedDescription }
        case .voices:
            do { myVoices = try await fetchVoices() } catch { self.error = error.localizedDescription }
        case .none:
            break
        }
        isLoading = false
    }
    
    private func fetchNotifications() async throws -> [[String: Any]] {
        guard let token = app.token else { throw APIError.missingToken }
        guard let id = app.currentUserId else { return [] }
        return try await APIClient.shared.fetchNotifications(clientId: id, token: token)
    }
    
    private func fetchVoices() async throws -> [[String: Any]] {
        guard let token = app.token else { throw APIError.missingToken }
        guard let id = app.currentUserId else { return [] }
        return try await APIClient.shared.fetchUserVoices(clientId: id, page: 1, token: token)
    }
}

// MARK: - Row Views


private struct NotificationRow: View {
    var item: [String: Any]
    
    private var primaryText: String {
        
        if let message = item["message"] as? String {
            return message
        }
        if let text = item["text"] as? String {
            return text
        }
        if let title = item["title"] as? String {
            return title
        }
        // Fallback: construct a descriptive string from arbitrary keys
        return item.map { "\($0.key): \($0.value)" }.joined(separator: ", ")
    }
    
    private var subtitleText: String? {
        // For comments and likes, there may be a sender or voice title
        if let sender = item["sender"] as? String {
            return sender
        }
        if let author = item["author"] as? String {
            return author
        }
        return nil
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Placeholder avatar; if the API supplies an avatar URL you could
            // replace this with AsyncImage to fetch it from the network
            Circle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 42, height: 42)
                .overlay(
                    Text(initials(from: subtitleText ?? primaryText))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(primaryText)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                if let subtitle = subtitleText {
                    Text(subtitle)
                        .font(.system(size: 13))
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            Spacer()
        }
        .padding()
        .background(.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

/// A single row representing one of the user's ReChords. Displays a
/// thumbnail (if provided), a title or description, and accessory icons.
private struct VoiceRow: View {
    var item: [String: Any]
    
    private var titleText: String {
        if let t = item["Title"] as? String { return t }
        if let desc = item["description"] as? String { return desc }
        if let name = item["name"] as? String { return name }
        return "Untitled ReChord"
    }
    
    private var locationEnabled: Bool {
        
        if item["latitude"] != nil || item["lat"] != nil { return true }
        return false
    }

    /// Attempt to read the number of likes from various possible keys. Returns 0 if absent.
    private var likeCount: Int {
        if let c = item["likes"] as? Int { return c }
        if let c = item["LikesCount"] as? Int { return c }
        if let c = item["like_count"] as? Int { return c }
        if let s = item["likes"] as? String, let i = Int(s) { return i }
        if let s = item["like_count"] as? String, let i = Int(s) { return i }
        if let s = item["LikesCount"] as? String, let i = Int(s) { return i }
        return 0
    }

    /// Attempt to read the number of playbacks from various possible keys. Returns 0 if absent.
    private var playbackCount: Int {
        if let c = item["playback"] as? Int { return c }
        if let c = item["Number_Of_Playbacks"] as? Int { return c }
        if let c = item["play_count"] as? Int { return c }
        if let c = item["playback_count"] as? Int { return c }
        if let s = item["playback"] as? String, let i = Int(s) { return i }
        if let s = item["playbacks"] as? String, let i = Int(s) { return i }
        if let s = item["play_count"] as? String, let i = Int(s) { return i }
        if let s = item["Number_Of_Playbacks"] as? String, let i = Int(s) { return i }
        return 0
    }
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                // Thumbnail placeholder; if the API supplies an image URL you
                // could replace this with AsyncImage to fetch it from the network
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 70, height: 70)
                Image(systemName: "play.circle.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text(titleText)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                // Row with location and metrics
                HStack(spacing: 12) {
                    if locationEnabled {
                        Image(systemName: "mappin.and.ellipse")
                            .foregroundColor(.white.opacity(0.8))
                    }
                    // Likes count
                    HStack(spacing: 4) {
                        Image(systemName: "heart")
                        Text(String(likeCount))
                    }
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.8))
                    // Playbacks count
                    HStack(spacing: 4) {
                        Image(systemName: "play.fill")
                        Text(String(playbackCount))
                    }
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.8))
                }
            }
            Spacer()
            Image(systemName: "ellipsis")
                .rotationEffect(.degrees(90))
                .foregroundColor(.white.opacity(0.8))
        }
        .padding()
        .background(.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - Helpers
/// Extract the initials from a string for use in placeholder avatars.
private func initials(from string: String) -> String {
    let comps = string.split(separator: " ").map { String($0) }
    let initials = comps.prefix(2).compactMap { $0.first }.map { String($0) }.joined()
    return initials.isEmpty ? "?" : initials
}
