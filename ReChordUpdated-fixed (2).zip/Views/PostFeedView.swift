import SwiftUI
import AVFoundation

/// A vertically paging feed of ReChord voices modelled after the post
/// screen in the provided screenshot. Each page displays a single voice
/// with its associated image, title, owner, like/comment counts and an
/// audio player. Swipe horizontally to browse through voices. The
/// background of the feed is blurred from the currently visible
/// post's picture. New posts are loaded from the same API used by
/// ``MapExploreView`` and ``FeedView``.
struct PostFeedView: View {
    @EnvironmentObject private var app: AppState
    @StateObject private var locationManager = LocationManager()
    @State private var voices: [Voice] = []
    @State private var selectedIndex: Int = 0
    @State private var isLoading: Bool = false
    @State private var error: String?

    var body: some View {
        ZStack(alignment: .bottom) {
            // Blurred background derived from the current voice's image.
            Group {
                if voices.indices.contains(selectedIndex),
                   let url = voices[selectedIndex].pictureURL {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure(_):
                            Image("placeholder-bg").resizable().scaledToFill()
                        case .empty:
                            Image("placeholder-bg").resizable().scaledToFill()
                        @unknown default:
                            Image("placeholder-bg").resizable().scaledToFill()
                        }
                    }
                } else {
                    Image("placeholder-bg").resizable().scaledToFill()
                }
            }
            .ignoresSafeArea()
            .blur(radius: 20)
            // Semi‑transparent overlay to improve contrast
            Color.black.opacity(0.3).ignoresSafeArea()
            VStack {
                // Top title
                HStack {
                    Text("ReChord")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .shadow(radius: 6)
                    Spacer()
                }
                .padding([.top, .horizontal], 16)
                Spacer()
                // Loading or error indicators
                if isLoading {
                    ProgressView()
                        .padding(.bottom, 160)
                } else if let error = error {
                    Text(error)
                        .foregroundStyle(.white)
                        .padding(.bottom, 160)
                } else if voices.isEmpty {
                    Text("No posts")
                        .foregroundStyle(.white)
                        .padding(.bottom, 160)
                } else {
                    TabView(selection: $selectedIndex) {
                        ForEach(Array(voices.enumerated()), id: \ .offset) { index, voice in
                            PostCardView(voice: voice)
                                .tag(index)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .padding(.bottom, 60)
                }
            }
        }
        .onAppear {
            // Fetch posts once when the view appears
            if voices.isEmpty {
                Task { await fetchVoices() }
            }
        }
    }

    /// Fetch voices using the same API call as ``MapExploreView``. The
    /// voices are sorted as returned by the server. Errors are
    /// surfaced in the ``error`` state and a loading spinner is
    /// displayed while the request is outstanding.
    private func fetchVoices() async {
        isLoading = true
        error = nil
        guard let token = app.token else {
            error = "Please sign in to load posts"
            isLoading = false
            return
        }
        let lat = locationManager.region.center.latitude
        let lon = locationManager.region.center.longitude
        let latitude = lat == 0 ? 40.7128 : lat
        let longitude = lon == 0 ? -74.0060 : lon
        let userId = app.currentUserId ?? 0
        do {
            let url = APIConfig.baseURL.appendingPathComponent("voices/\(latitude)/\(longitude)/\(userId)/Show")
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.addValue("application/json", forHTTPHeaderField: "Accept")
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
            if http.statusCode == 401 { throw APIError.unauthorized }
            // Parse the response into an array of dictionaries
            let json = try JSONSerialization.jsonObject(with: data)
            var items: [[String: Any]] = []
            if let arr = json as? [[String: Any]] {
                items = arr
            } else if let dict = json as? [String: Any] {
                if let arr = dict["data"] as? [[String: Any]] {
                    items = arr
                } else if let arr = dict["voices"] as? [[String: Any]] {
                    items = arr
                } else {
                    for value in dict.values {
                        if let arr = value as? [[String: Any]] {
                            items = arr
                            break
                        }
                    }
                }
            }
            var loaded: [Voice] = []
            loaded.reserveCapacity(items.count)
            func toDouble(_ value: Any?) -> Double? {
                if let d = value as? Double { return d }
                if let n = value as? NSNumber { return n.doubleValue }
                if let s = value as? String { return Double(s) }
                return nil
            }
            for item in items {
                let id = (item["id"] as? Int)
                    ?? (item["Voice_Id"] as? Int)
                    ?? (item["voice_id"] as? Int)
                    ?? (item["Voice_id"] as? Int)
                    ?? Int((item["id"] as? String) ?? "")
                guard let vid = id else { continue }
                let title = (item["title"] as? String)
                    ?? (item["Title"] as? String)
                    ?? "Untitled"
                var latVal: Any? = item["Position_X"] ?? item["position_x"] ?? item["latitude"] ?? item["lat"] ?? item["x"]
                var lonVal: Any? = item["Position_Y"] ?? item["position_y"] ?? item["longitude"] ?? item["lon"] ?? item["y"]
                if latVal == nil || lonVal == nil, let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
                    latVal = geo[0]
                    lonVal = geo[1]
                }
                guard let la = toDouble(latVal), let lo = toDouble(lonVal) else { continue }
                let picString = (item["Picture_Link"] as? String)
                    ?? (item["picture_link"] as? String)
                    ?? (item["image"] as? String)
                let pictureURL = picString.flatMap { URL(string: $0) }
                let voiceString = (item["Voice_Link"] as? String)
                    ?? (item["voice_link"] as? String)
                    ?? (item["voice"] as? String)
                let voiceURL = voiceString.flatMap { URL(string: $0) }
                let likesValue: Int? = {
                    if let v = item["LikesCount"] as? Int { return v }
                    if let v = item["likes"] as? Int { return v }
                    if let s = item["LikesCount"] as? String { return Int(s) }
                    if let s = item["likes"] as? String { return Int(s) }
                    return nil
                }()
                let name = (item["Owner"] as? String)
                    ?? (item["owner"] as? String)
                    ?? (item["owner_name"] as? String)
                    ?? (item["client_name"] as? String)
                    ?? (item["full_name"] as? String)
                    ?? (item["username"] as? String)
                let comments: Int? = {
                    if let v = item["comments_count"] as? Int { return v }
                    if let s = item["comments_count"] as? String { return Int(s) }
                    return nil
                }()
                let ownerIdValue: Int? = {
                    if let v = item["client_id"] as? Int { return v }
                    if let v = item["user_id"] as? Int { return v }
                    if let v = item["owner_id"] as? Int { return v }
                    if let s = item["client_id"] as? String { return Int(s) }
                    if let s = item["user_id"] as? String { return Int(s) }
                    if let s = item["owner_id"] as? String { return Int(s) }
                    return nil
                }()
                loaded.append(Voice(
                    id: vid,
                    title: title,
                    latitude: la,
                    longitude: lo,
                    pictureURL: pictureURL,
                    voiceURL: voiceURL,
                    likes: likesValue,
                    ownerName: name,
                    commentsCount: comments,
                    ownerId: ownerIdValue
                ))
            }
            DispatchQueue.main.async {
                self.voices = loaded
                self.isLoading = false
            }
        } catch {
            DispatchQueue.main.async {
                self.error = error.localizedDescription
                self.isLoading = false
            }
        }
    }
}

/// A single post card that displays the details of a voice. The layout
/// mirrors the provided screenshot: an image fills the card, overlaid
/// with the voice title, owner information, like/comment/share buttons,
/// a location indicator and an audio player with a play button and a
/// record icon. Likes are toggled locally and synced with the server
/// when possible.
struct PostCardView: View {
    var voice: Voice
    @EnvironmentObject private var app: AppState
    @State private var isLiked: Bool = false
    @State private var likeCount: Int

    init(voice: Voice) {
        self.voice = voice
        _likeCount = State(initialValue: voice.likes ?? 0)
    }

    var body: some View {
        ZStack {
            // Background image or placeholder
            Group {
                if let url = voice.pictureURL {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure(_):
                            Color.gray.opacity(0.3)
                        case .empty:
                            Color.gray.opacity(0.3)
                        @unknown default:
                            Color.gray.opacity(0.3)
                        }
                    }
                } else {
                    Color.gray.opacity(0.3)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .clipped()
            // Fade gradient at the bottom for readability
            LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.8)]),
                startPoint: .center,
                endPoint: .bottom
            )
            // Top-left owner and title
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    Image("placeholder-avatar")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text(voice.title)
                            .font(.subheadline)
                            .bold()
                        if let name = voice.ownerName {
                            Text(name)
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.8))
                        }
                    }
                    .foregroundStyle(.white)
                    Spacer()
                }
            }
            .padding([.top, .leading], 16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            // Bottom overlays: location, vertical buttons, audio bar
            VStack(spacing: 0) {
                Spacer()
                HStack(alignment: .bottom) {
                    // Location on the left: show coordinates for now
                    if voice.latitude != 0 || voice.longitude != 0 {
                        HStack(spacing: 4) {
                            Image(systemName: "mappin.and.ellipse")
                                .foregroundColor(.white)
                            Text(String(format: "%.4f, %.4f", voice.latitude, voice.longitude))
                                .foregroundColor(.white)
                                .font(.caption)
                        }
                    }
                    Spacer()
                    // Vertical buttons on the right
                    VStack(spacing: 20) {
                        // Like button
                        Button(action: toggleLike) {
                            VStack(spacing: 4) {
                                Image(systemName: isLiked ? "heart.fill" : "heart")
                                    .foregroundColor(isLiked ? .red : .white)
                                    .font(.title2)
                                Text("\(likeCount)")
                                    .foregroundColor(.white)
                                    .font(.footnote)
                            }
                        }
                        // Comments display (read‑only)
                        VStack(spacing: 4) {
                            Image(systemName: "bubble.left")
                                .foregroundColor(.white)
                                .font(.title2)
                            Text("\(voice.commentsCount ?? 0)")
                                .foregroundColor(.white)
                                .font(.footnote)
                        }
                        // Share button (no action)
                        VStack(spacing: 4) {
                            Image(systemName: "arrowshape.turn.up.forward")
                                .foregroundColor(.white)
                                .font(.title2)
                            Text("Share")
                                .foregroundColor(.white)
                                .font(.footnote)
                        }
                    }
                }
                .padding([.horizontal, .bottom], 16)
                // Audio bar
                if voice.voiceURL != nil {
                    PostAudioBar(url: voice.voiceURL)
                        .padding([.horizontal, .bottom], 16)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    /// Toggle the like state for this post. When liking or unliking the
    /// voice the local count updates instantly and the API request is
    /// dispatched asynchronously. If no user is authenticated the like
    /// toggles locally without contacting the server.
    private func toggleLike() {
        guard let token = app.token, let clientId = app.currentUserId else {
            // Update local state only
            if isLiked {
                likeCount = max(0, likeCount - 1)
            } else {
                likeCount += 1
            }
            isLiked.toggle()
            return
        }
        if isLiked {
            likeCount = max(0, likeCount - 1)
            isLiked = false
            Task {
                try? await APIClient.shared.unlikeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        } else {
            likeCount += 1
            isLiked = true
            Task {
                try? await APIClient.shared.likeVoice(voiceId: voice.id, clientId: clientId, token: token)
            }
        }
    }
}

/// A custom audio bar with play/pause and a stylised waveform along with
/// a record icon. The waveform is represented by a series of capsules
/// whose colour fills as playback progresses. Tapping the play icon
/// toggles audio playback. The record icon is present for visual
/// fidelity but does not perform any action.
struct PostAudioBar: View {
    let url: URL?
    @State private var player: AVPlayer?
    @State private var isPlaying: Bool = false
    @State private var currentTime: Double = 0
    @State private var duration: Double = 1
    // Update twice per second
    private let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    private let barCount: Int = 30

    // Compute playback progress between 0 and 1
    private var progress: Double {
        guard duration > 0 else { return 0 }
        return min(max(currentTime / duration, 0), 1)
    }

    var body: some View {
        HStack(spacing: 12) {
            Button(action: toggle) {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.blue)
            }
            HStack(spacing: 2) {
                ForEach(0..<barCount, id: \ .self) { index in
                    Capsule()
                        .fill(Double(index) / Double(barCount) < progress ? Color.blue : Color.white.opacity(0.6))
                        .frame(width: 3, height: heightForIndex(index))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: 24)
            // Mic button for decorative purposes
            Button(action: {}) {
                Image(systemName: "mic.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.red)
            }
        }
        .onAppear {
            if let url = url {
                player = AVPlayer(url: url)
                if let item = player?.currentItem {
                    let d = item.asset.duration.seconds
                    if d.isFinite && d > 0 {
                        duration = d
                    }
                }
            }
        }
        .onReceive(timer) { _ in
            guard let player = player,
                  let currentItem = player.currentItem else { return }
            if currentItem.duration.seconds.isFinite && currentItem.duration.seconds > 0 {
                duration = currentItem.duration.seconds
                currentTime = player.currentTime().seconds
            }
        }
    }

    /// Toggle playback for the underlying AVPlayer. When playing the
    /// waveform animates as progress increases.
    private func toggle() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    /// Compute a pseudo‑waveform height for the given index. This uses a
    /// sinusoidal function to vary the heights, giving a pleasing
    /// alternation reminiscent of a waveform.
    private func heightForIndex(_ index: Int) -> CGFloat {
        // Produce values between 6 and 24 points
        let amplitude: Double = 9
        let base: Double = 15
        let value = sin(Double(index) / Double(barCount) * .pi) * amplitude + base
        return CGFloat(value)
    }
}