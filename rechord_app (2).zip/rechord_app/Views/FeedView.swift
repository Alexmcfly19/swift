import SwiftUI
import MapTilerSDK
import CoreLocation

/// Displays a map with voice markers and a segmented control to
/// optionally filter voices to those created by the current user. The
/// map uses a custom tile overlay powered by MapTiler (see
/// ``APIConfig.mapTilerKey``) and shows each voice as a circular
/// annotation. Selecting the second segment filters the list to only
/// voices whose `ownerId` matches the logged‑in user.
struct FeedView: View {
    @EnvironmentObject private var app: AppState
    @StateObject private var locationManager = LocationManager()
    @State private var voices: [Voice] = []
    @State private var isLoading: Bool = false
    @State private var error: String? = nil
    @State private var filterIndex: Int = 0

    // MapTiler's `MTMapView` handles camera positioning internally. A
    // helper like `updateMapRegion` is no longer needed because the
    // MapTiler map automatically flies to a central coordinate on
    // appearance (see `VoiceMapWithAnnotationsView`).

    /// Filter the loaded voices based on the selected segment. When
    /// `filterIndex` is 1 the current user's voices are returned. For any
    /// other value all voices are returned.
    private var filteredVoices: [Voice] {
        if filterIndex == 1, let currentId = app.currentUserId {
            return voices.filter { voice in
                if let ownerId = voice.ownerId { return ownerId == currentId }
                return false
            }
        }
        return voices
    }

    var body: some View {
        ZStack(alignment: .top) {
            // Map view using MapTiler SDK and voice markers. The
            // `VoiceMapWithAnnotationsView` handles centering on the
            // provided voices internally.
            VoiceMapWithAnnotationsView(voices: filteredVoices)
                .edgesIgnoringSafeArea(.all)
            VStack(spacing: 8) {
                // App title
                Text("ReChord")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .shadow(radius: 6)
                    .padding(.top, 8)
                // Segmented control: 0 = all voices, 1 = my voices
                Picker(selection: $filterIndex, label: EmptyView()) {
                    Image(systemName: "mappin.and.ellipse").tag(0)
                    Image(systemName: "person.circle").tag(1)
                }
                .pickerStyle(.segmented)
                .frame(width: 200)
                .padding(.horizontal)
                // Loading or error indicators
                if isLoading {
                    ProgressView().padding(.top, 16)
                } else if let err = error {
                    Text(err)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .padding(.top, 16)
                }
            }
            .padding(.horizontal)
        }
        .onAppear {
            // Only fetch once when the view appears
            if voices.isEmpty {
                Task { await fetchVoices() }
            }
        }
    }

    /// Fetch voices within a radius of the user's current location. The
    /// implementation mirrors ``MapExploreView`` but is duplicated here to
    /// keep the map page self‑contained. Upon success the voices array
    /// and map region are updated on the main thread.
    private func fetchVoices() async {
        isLoading = true
        error = nil
        guard let token = app.token else {
            error = "Please sign in to load voices"
            isLoading = false
            return
        }
        let lat = locationManager.region.center.latitude
        let lon = locationManager.region.center.longitude
        let latitude = lat == 0 ? 40.7128 : lat
        let longitude = lon == 0 ? -74.0060 : lon
        let userId = app.currentUserId ?? 0
        do {
            let url = APIConfig.baseURL.appendingPathComponent("voices/\(latitude)/\(longitude)/\(userId)/Show")
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.addValue("application/json", forHTTPHeaderField: "Accept")
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
            if http.statusCode == 401 { throw APIError.unauthorized }
            let json = try JSONSerialization.jsonObject(with: data)
            var items: [[String: Any]] = []
            if let arr = json as? [[String: Any]] {
                items = arr
            } else if let dict = json as? [String: Any] {
                if let arr = dict["data"] as? [[String: Any]] {
                    items = arr
                } else if let arr = dict["voices"] as? [[String: Any]] {
                    items = arr
                } else {
                    for value in dict.values {
                        if let arr = value as? [[String: Any]] {
                            items = arr
                            break
                        }
                    }
                }
            }
            var loaded: [Voice] = []
            loaded.reserveCapacity(items.count)
            func toDouble(_ value: Any?) -> Double? {
                if let d = value as? Double { return d }
                if let n = value as? NSNumber { return n.doubleValue }
                if let s = value as? String { return Double(s) }
                return nil
            }
            for item in items {
                let id = (item["id"] as? Int)
                    ?? (item["Voice_Id"] as? Int)
                    ?? (item["voice_id"] as? Int)
                    ?? (item["Voice_id"] as? Int)
                    ?? Int((item["id"] as? String) ?? "")
                guard let vid = id else { continue }
                let title = (item["title"] as? String)
                    ?? (item["Title"] as? String)
                    ?? "Untitled"
                var latVal: Any? = item["Position_X"] ?? item["position_x"] ?? item["latitude"] ?? item["lat"] ?? item["x"]
                var lonVal: Any? = item["Position_Y"] ?? item["position_y"] ?? item["longitude"] ?? item["lon"] ?? item["y"]
                if latVal == nil || lonVal == nil, let geo = item["GeoCode"] as? [Any], geo.count >= 2 {
                    latVal = geo[0]
                    lonVal = geo[1]
                }
                guard let la = toDouble(latVal), let lo = toDouble(lonVal) else { continue }
                let picString = (item["Picture_Link"] as? String)
                    ?? (item["picture_link"] as? String)
                    ?? (item["image"] as? String)
                let pictureURL = picString.flatMap { URL(string: $0) }
                let voiceString = (item["Voice_Link"] as? String)
                    ?? (item["voice_link"] as? String)
                    ?? (item["voice"] as? String)
                let voiceURL = voiceString.flatMap { URL(string: $0) }
                let likesValue: Int? = {
                    if let v = item["LikesCount"] as? Int { return v }
                    if let v = item["likes"] as? Int { return v }
                    if let s = item["LikesCount"] as? String { return Int(s) }
                    if let s = item["likes"] as? String { return Int(s) }
                    return nil
                }()
                let name = (item["Owner"] as? String)
                    ?? (item["owner"] as? String)
                    ?? (item["owner_name"] as? String)
                    ?? (item["client_name"] as? String)
                    ?? (item["full_name"] as? String)
                    ?? (item["username"] as? String)
                let comments: Int? = {
                    if let v = item["comments_count"] as? Int { return v }
                    if let s = item["comments_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract dislikes count using a variety of expected keys
                let dislikesValue: Int? = {
                    if let v = item["DislikesCount"] as? Int { return v }
                    if let v = item["dislikes"] as? Int { return v }
                    if let v = item["dislike_count"] as? Int { return v }
                    if let v = item["dislikes_count"] as? Int { return v }
                    if let s = item["DislikesCount"] as? String { return Int(s) }
                    if let s = item["dislikes"] as? String { return Int(s) }
                    if let s = item["dislike_count"] as? String { return Int(s) }
                    if let s = item["dislikes_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract shares count using common naming conventions
                let sharesValue: Int? = {
                    if let v = item["SharesCount"] as? Int { return v }
                    if let v = item["shares"] as? Int { return v }
                    if let v = item["share_count"] as? Int { return v }
                    if let v = item["shares_count"] as? Int { return v }
                    if let s = item["SharesCount"] as? String { return Int(s) }
                    if let s = item["shares"] as? String { return Int(s) }
                    if let s = item["share_count"] as? String { return Int(s) }
                    if let s = item["shares_count"] as? String { return Int(s) }
                    return nil
                }()
                // Extract playback count using multiple potential key names
                let playsValue: Int? = {
                    if let v = item["PlaybacksCount"] as? Int { return v }
                    if let v = item["playbacks"] as? Int { return v }
                    if let v = item["play_count"] as? Int { return v }
                    if let v = item["plays"] as? Int { return v }
                    if let v = item["views"] as? Int { return v }
                    if let v = item["playbacks_count"] as? Int { return v }
                    if let s = item["PlaybacksCount"] as? String { return Int(s) }
                    if let s = item["playbacks"] as? String { return Int(s) }
                    if let s = item["play_count"] as? String { return Int(s) }
                    if let s = item["plays"] as? String { return Int(s) }
                    if let s = item["views"] as? String { return Int(s) }
                    if let s = item["playbacks_count"] as? String { return Int(s) }
                    return nil
                }()
                let ownerIdValue: Int? = {
                    if let v = item["client_id"] as? Int { return v }
                    if let v = item["user_id"] as? Int { return v }
                    if let v = item["owner_id"] as? Int { return v }
                    if let s = item["client_id"] as? String { return Int(s) }
                    if let s = item["user_id"] as? String { return Int(s) }
                    if let s = item["owner_id"] as? String { return Int(s) }
                    return nil
                }()
                loaded.append(
                    Voice(
                        id: vid,
                        title: title,
                        latitude: la,
                        longitude: lo,
                        pictureURL: pictureURL,
                        voiceURL: voiceURL,
                        likes: likesValue,
                        dislikes: dislikesValue,
                        shares: sharesValue,
                        playCount: playsValue,
                        ownerName: name,
                        commentsCount: comments,
                        ownerId: ownerIdValue
                    )
                )
            }
            DispatchQueue.main.async {
                self.voices = loaded
                self.isLoading = false
                // No need to explicitly update a map region because
                // the MapTiler map view will automatically fly to a
                // sensible centre when voices change (see
                // `VoiceMapWithAnnotationsView`).
            }
        } catch {
            DispatchQueue.main.async {
                self.error = error.localizedDescription
                self.isLoading = false
            }
        }
    }
}