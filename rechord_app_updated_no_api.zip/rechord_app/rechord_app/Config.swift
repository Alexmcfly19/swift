import Foundation

enum APIConfig {
    static let baseURL = URL(string: "https://be.rechord.life/public/api")!

    /// API key for MapTiler tile overlays. Set this to your MapTiler
    /// project key to enable custom map styles in the app. If left
    /// empty the app falls back to OpenStreetMap tiles.
    static let mapTilerKey: String = ""
}
