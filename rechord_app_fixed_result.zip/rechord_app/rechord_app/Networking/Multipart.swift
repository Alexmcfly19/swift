import Foundation

struct MultipartFile {
    let data: Data
    let name: String
    let filename: String
    let mimeType: String
}

struct MultipartBuilder {
    private let boundary = "Boundary-\(UUID().uuidString)"
    var contentType: String { "multipart/form-data; boundary=\(boundary)" }
    
    func build(parameters: [String: String], files: [MultipartFile]) -> Data {
        var body = Data()
        func append(_ string: String) { body.append(string.data(using: .utf8)!) }
        
        for (k,v) in parameters {
            append("--\(boundary)\r\n")
            append("Content-Disposition: form-data; name=\"\(k)\"\r\n\r\n")
            append("\(v)\r\n")
        }
        for file in files {
            append("--\(boundary)\r\n")
            append("Content-Disposition: form-data; name=\"\(file.name)\"; filename=\"\(file.filename)\"\r\n")
            append("Content-Type: \(file.mimeType)\r\n\r\n")
            body.append(file.data)
            append("\r\n")
        }
        append("--\(boundary)--\r\n")
        return body
    }
}