import SwiftUI
import MapTilerSDK
import CoreLocation

/// Displays a collection of `Voice` locations on a MapTiler map. This
/// view uses the `MapTilerSDK` to render an interactive map and
/// overlays markers for each voice at its latitude/longitude
/// coordinates. When the voices array changes the markers update
/// automatically. The map style can be customised via the
/// `referenceStyle` and `styleVariant` state properties.
struct VoiceMapWithAnnotationsView: View {
    /// The voices to display on the map. Each voice will appear as a
    /// marker at its associated coordinates.
    var voices: [Voice]

    /// The underlying MapTiler map view. Stored as a state property
    /// so that SwiftUI manages its lifecycle.
    @State private var map = MTMapView(options: MTMapOptions(zoom: 2.0))
    /// The reference style controls which base map is rendered (e.g.
    /// streets, satellite). Defaults to streets.
    @State private var referenceStyle: MTMapReferenceStyle = .streets
    /// Optional variant to select a different colour palette for the
    /// chosen style. Defaults to the default variant.
    // Use the pastel variant for a softer palette that better matches
    // the provided design. See MapTiler SDK docs for available
    // variants such as `.defaultVariant`, `.light`, `.dark`, `.pastel` and
    // others.  The pastel style reduces contrast and brightens the
    // map which helps avatar markers stand out.
    @State private var styleVariant: MTMapStyleVariant? = .pastel

    var body: some View {
        // Wrap the MapTiler view in a GeometryReader to force it to
        // adopt the full size of its parent. Without an explicit
        // frame the map may collapse to zero height when embedded in
        // containers like `TabView` or `ZStack`.  GeometryReader
        // provides access to the available width and height so we can
        // assign them directly to the map view.
        GeometryReader { geometry in
            // Construct markers for each voice.  We avoid using
            // `ForEach` here because the `@MTMapContentBuilder` API
            // expects an array of `MTMapViewContent`.  Using
            // `voices.map` ensures each marker is returned directly.
            MTMapViewContainer(map: map) {
                voices.map { voice in
                    MTMarker(coordinates: CLLocationCoordinate2D(
                        latitude: voice.latitude,
                        longitude: voice.longitude
                    ))
                }
            }
            .referenceStyle(referenceStyle)
            .styleVariant(styleVariant)
            // Expand the map to fill the available space defined by
            // the geometry. Without this explicit frame the
            // `MTMapViewContainer` can collapse under certain SwiftUI
            // layouts (e.g. inside a `TabView`) causing the map to
            // appear in a very small or hidden area.  Setting both
            // dimensions here resolves that issue by matching the
            // container's frame to its parent's dimensions.
            .frame(width: geometry.size.width, height: geometry.size.height)
            // When the view appears, fly the map camera to a sensible
            // centre point based on the voices. If there are no voices
            // this step is skipped and the map retains its default zoom.
            .onAppear {
                guard !voices.isEmpty else { return }
                // Compute the average coordinate of all voices to use as
                // a central target for the flyTo animation.
                let totalLat = voices.map { $0.latitude }.reduce(0, +)
                let totalLon = voices.map { $0.longitude }.reduce(0, +)
                let centre = CLLocationCoordinate2D(
                    latitude: totalLat / Double(voices.count),
                    longitude: totalLon / Double(voices.count)
                )
                map.flyTo(centre, options: nil, animationOptions: nil)
            }
        }
        // Ensure the map extends behind the safe areas such as the
        // status bar and tab bar so it truly fills the screen.  This
        // modifier must be placed outside the GeometryReader in order
        // to affect the entire view hierarchy rather than just the
        // contents of the geometry closure.
        .ignoresSafeArea()
    }
}