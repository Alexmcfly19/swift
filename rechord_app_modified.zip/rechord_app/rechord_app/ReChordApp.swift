//
//  ReChordApp.swift
//  ReChord
//
//  Created by Macvps on 9/1/25.
//

import SwiftUI
import MapKit

@main
struct ReChordApp: App {
    /// Initialise the app and configure the MapTiler SDK. The API key
    /// must be set before any map views are created. We call it in an
    /// asynchronous task to avoid blocking the main thread.
    init() {
        // No API key configuration is necessary because MapKit is bundled
        // with iOS. If you previously set a MapTiler key it is no longer
        // required. The initialiser remains to allow future configuration.
    }
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(AppState.shared)
        }
    }
}
