
import SwiftUI

struct NotificationView: View {
    @State private var notifications: [Notification] = []

    var body: some View {
        NavigationView {
            List(notifications) { notification in
                HStack {
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                    VStack(alignment: .leading) {
                        Text(notification.userName)
                            .fontWeight(.bold)
                        Text(notification.message)
                            .font(.subheadline)
                    }
                    Spacer()
                    if notification.type == "like" {
                        Image(systemName: "heart.fill")
                            .foregroundColor(.red)
                    }
                    else {
                        Image(systemName: "bubble.right.fill")
                            .foregroundColor(.blue)
                    }
                }
                .padding()
            }
            .navigationBarTitle("Notifications")
            .onAppear {
                fetchNotifications()
            }
        }
    }

    // API call to fetch notifications
    func fetchNotifications() {
        guard let url = URL(string: "https://be.rechord.life/public/api/clients/62/notifications") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("Bearer YOUR_TOKEN_HERE", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                let decoder = JSONDecoder()
                if let notifications = try? decoder.decode([Notification].self, from: data) {
                    DispatchQueue.main.async {
                        self.notifications = notifications
                    }
                }
            }
        }.resume()
    }
}

struct Notification: Identifiable, Decodable {
    var id: Int
    var userName: String
    var message: String
    var type: String // "like" or "comment"
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
