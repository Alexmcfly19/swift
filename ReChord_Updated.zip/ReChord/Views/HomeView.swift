import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

struct HomeView: View {
    @EnvironmentObject var app: AppState
    @State private var tab = 2 // center record by default
    
    var body: some View {
        
    TabView(selection: $tab) {
        NotificationView().tabItem { Label("Notifications", systemImage: "bell") }.tag(3)
    
            ExploreView().tabItem { Label("Explore", systemImage: "globe") }.tag(0)
            FeedView().tabItem { Label("Feed", systemImage: "list.bullet") }.tag(1)
            RecorderView().tabItem { Label("Record", systemImage: "mic.circle.fill") }.tag(2)
            MentionsView().tabItem { Label("@", systemImage: "at") }.tag(3)
            ProfileView().tabItem { Label("Profile", systemImage: "person.crop.circle") }.tag(4)
        }
    }
}

struct ExploreView: View { var body: some View { Color.clear.overlay(Text("Explore")) } }
struct FeedView: View { var body: some View { Color.clear.overlay(Text("Feed")) } }
struct MentionsView: View { var body: some View { Color.clear.overlay(Text("Mentions")) } }

struct RecorderView: View {
    @EnvironmentObject var app: AppState
    @State private var showPicker = false
    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Button {
                showPicker = true
            } label: {
                Image(systemName: "record.circle.fill").font(.system(size: 96))
            }
            Text("Tap to pick a voice file to upload").foregroundStyle(.secondary)
            Spacer()
        }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [.audio]) { result in
            switch result {
            case .success(let url):
                if let data = try? Data(contentsOf: url), let token = app.token {
                    Task {
                        try? await APIClient.shared.uploadVoice(voiceData: data, token: token)
                    }
                }
            case .failure:
                break
            }
        }
    }
}
